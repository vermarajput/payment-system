# Digital Documents Service

JSON-API based REST service for generating quotes. Backed by MongoDB.

## Prerequisites

### Development

|Artifact|Description|Notes|
|---|---|---|
|Java JDK 1.8.0_131 or later|Used for compilation/running the application.|Either OpenJDK or Oracle JDK can be used. Follow installation instructions for [OpenJDK](http://openjdk.java.net/install/) or [Oracle JDK](https://docs.oracle.com/javase/8/docs/technotes/guides/install/install_overview.html).|
|Intellij IDEA 2017|Recommended IDE.|Any other Java IDE or text editor can be used.|
|Maven 3|Used for building the application.|The version embedded inside of Intellij is fine, or a separate version can be installed from [Maven](https://maven.apache.org/download.cgi).|
|MongoDB Community/Enterprise Server 3.4.7|Used to hold the quotes data. Is required for acceptance testing during development.|Can be installed by following the instructions from [MongoDB](https://www.mongodb.com/download-center?jmp=nav#community).| 

### Production

|Artifact|Description|Notes|
|---|---|---|
|Java JDK 1.8.0_131 or later|Used for compilation/running the application.|Either OpenJDK or Oracle JDK can be used. Follow installation instructions for [OpenJDK](http://openjdk.java.net/install/) or [Oracle JDK](https://docs.oracle.com/javase/8/docs/technotes/guides/install/install_overview.html).|
|MongoDB Community/Enterprise Server 3.4.7|Used to hold the quotes data.|Can be installed by following the instructions from [MongoDB](https://www.mongodb.com/download-center?jmp=nav#community).|

## Build and acceptance testing

This project is automatically build and tested using BitBucket Pipelines and the results published as a JAR file and Docker image.

Build results are available in [Pipelines](https://bitbucket.org/gbstbsd/digital-documents/addon/pipelines/home#!/).

The latest acceptance test results are available in HTML format from the [cucumber reports site](http://gbst-dev-cucumber-reports.s3-website-ap-southeast-2.amazonaws.com/digital-documents/develop/).

JAR files for the application are published to the [GBST Nexus Portal](https://nexus-portal.gbst.com) and Docker images are published to the [GBST Docker Trusted Registry](https://dtr.gbst.com/repositories/composer/digital-documents/details).

## Starting the server

The server can be started directly from the JAR file:

`java -jar digital-documents-<version>.jar`

The server will start on port 8080 by default and expects a MongoDB instance to be listening on it's default `27017` port on `localhost` by default.

A Docker image containing this server is available in the [GBST Docker Trusted Registry](https://dtr.gbst.com/repositories/composer/digital-documents/details).

## API documentation

The API is documented using Swagger V2. The Swagger file is available at `/api-docs/swagger.json`. Swagger UI is also available at `/docs/index.html`.

## Configuration and Properties

### Setting the Right Profile
For production use 'prod' and for development use 'dev' as the profile 

This should be done in application.properties via property:

```
spring.profiles.active=prod
```

## Client-specific Configuration
### Vitality
The profile for Vitality must be set to

```properties
spring.profiles.active=vitality
```

The following property is mandatory for this profile/client:
```properties

# Fields that need to be excluded when generating illustration document
gbst.digital.illustration.fields.dfm-charge=Off
gbst.digital.illustration.fields.fxd-comm-charge=Off
```

### Setting up storage and datasource
The following properties are required to be configured:

#### To override this value it can be provided as VM argument:

 The default dev and prod properties are configured to use a local mongo database at localhost on port 27017 using database name digital_documents.
`-Ddigital.documents.mongo.hostname=localhost`
`-Ddigital.documents.mongo.port=27017`
`-Ddigital.documents.mongo.database.name=digital_documents`
 The default dev and prod properties are configured for file storage to generate documents based on the template location for windward documents, document parent folder to save documents and root path.
`-Ddigital.documents.filesystem.root.path.prefix=/home`
`-Ddigital.documents.filesystem.documentParentfolder=dig-document-client-services`
`-Ddigital.documents.generation.templateLocation=template`
The default dev and prod properties are configured for document storage. The document storage URL differs in each environment - http://[server_name]:[port]/internal/document-storage/files/dms-upload. 
This is the sample URL from DIT - http://aws-jt-tt-17.ec2.gbst.net:1519/internal/document-storage/files/dms-upload.
`-Dgbst.digital.documents.scheduler-fixed-rate-seconds=300`
`-Ddev.connections.document.storage.url=<document storage url>`

Override default page limit size
`-Dgbst.jsonapi.default-page-limit-size=10`

Override maximum page limit size
`-Dgbst.jsonapi.max-page-limit-size=2000`


#### To override values via the Docker image it can be provided as an environment variable:

`docker run -P -e DIGITAL_DOCUMENTS_MONGO_HOSTNAME=mongohost 
-e DIGITAL_DOCUMENTS_MONGO_PORT=27017 
-e DIGITAL_DOCUMENTS_MONGO_DATABASE_NAME=digital_documents 
-e DIGITAL_DOCUMENTS_FILESYSTEM_ROOT_PATH_PREFIX=/home 
-e DIGITAL_DOCUMENTS_FILESYSTEM_DOCUMENTPARENTFOLDER=dig-document-client-services 
-e DIGITAL_DOCUMENTS_GENERATION_TEMPLATELOCATION=template 
-e GBST.DIGITAL.DOCUMENTS.schedulerFixedRateSeconds=300 
-e INTERNAL_CONNNECTIONS_DOCUMENT_STORAGE_URL=<document storage url> dtr.gbst.com/composer/digital-documents`

Page limit can be overridden when running via the Docker image using
`docker run -P -e DIGITAL_DOCUMENTS_MONGO_HOSTNAME=mongohost 
-e DIGITAL_DOCUMENTS_MONGO_PORT=27017 
-e DIGITAL_DOCUMENTS_MONGO_DATABASE_NAME=digital_documents 
-e DIGITAL_DOCUMENTS_FILESYSTEM_ROOT_PATH_PREFIX=/home 
-e DIGITAL_DOCUMENTS_FILESYSTEM_DOCUMENTPARENTFOLDER=dig-document-client-services 
-e DIGITAL_DOCUMENTS_GENERATION_TEMPLATELOCATION=template 
-e GBST.DIGITAL.DOCUMENTS.schedulerFixedRateSeconds=300 
-e GBST_JSONAPI_DEFAULT_PAGE_LIMIT_SIZE=10
-e GBST_JSONAPI_MAX_PAGE_LIMIT_SIZE=2000
-e INTERNAL_CONNNECTIONS_DOCUMENT_STORAGE_URL=<document storage url> dtr.gbst.com/composer/digital-documents`


See the [Spring Boot documentation](https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html) for other ways of configuring the properties.

To install a local mongoDB instance follow instructions at https://docs.mongodb.com/manual/administration/install-community/

If running via Docker, the standard MongoDB docker image can be used without modification.

### Setting up Logging

The default dev and prod properties are configured to specify the logging.path and logging.file.

dev : 
`logging.path=${java.io.tmpdir}`
`logging.file=${logging.path}/digital-documents.log`

prod:
`logging.path=${java.io.tmpdir:-/tmp}`
`logging.file=${logging.path}/digital-documents.log`

To override this value it can be provided as VM argument:

`-Dlogging.path==D:/logs`

or if running via the Docker image it can be provided as an environment variable:

`docker run -P -e -Dlogging.path=<value> -Dlogging.file=D:/logs/digital-documents123.log`  

### CBIS Connection
For illustration document generation, a CBIS instance is required. To connect to CBIS the following property should be configured:

`-Dgbst.connections.cbis.url=http://[server_name]:[port]/cbis-war-generic-uk-[cbis_version]/webservices`

### Composer API Connection
For illustration document generation, a Composer API instance is required. To connect to Composer API the following property should be configured:
`-Dgbst.connections.composer.url=http://[server_name]:[port]/api`

### Setting up Java settings
Default values set for Documents are:
* JAVA_HEAP_OPTS -Xmx512m

Following parameters can be overridden when running via Docker image:
| Parameter             | Description | 
| JAVA_HEAP_OPTS        | caters to -Xmx and -Xms Settings |
| JAVA_METASPACE_OPTS   | caters to -XX:MetaspaceSize -XX:MaxMetaspaceSize -XX:MinMetaspaceFreeRatio and -XX:MaxMetaspaceFreeRatio Settings |
| JAVA_OTHER_OPTS       | caters to settings other than above JavaHeapOpts and JavaMetaspaceOpts |

`docker run -P -d -e JAVA_HEAP_OPTS="-Xmx3g -Xms1g" -e JAVA_METASPACE_OPTS="-XX:MaxMetaspaceSize=1g"  dtr.gbst.com/composer/digital-documents`

## Monitoring
The server status and mongo status will be available at http://server:port/manage/health

## Development tips
To run the acceptance tests without having to restart the server:

1. Start the server.
2. Comment out the following two lines in `BaseDefs`:

```
//@SpringBootTest(classes = DocumentsApplication.class, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
//@ContextConfiguration
```

3. Run the `CucumberTest` class directly as a JUnit test via IDEA or other mechanisms.