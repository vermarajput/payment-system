package com.gbst.digital.documents.generator;

import com.fasterxml.jackson.databind.JsonNode;
import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.PayloadFormatEnum;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */
public class DocumentPayload {
    private final Object convertedPayload;
    private PayloadFormatEnum format;
    private String source;
    private DocumentForConfig documentForConfig;

    DocumentPayload(PayloadFormatEnum format, String source, Object convertedPayload) {
        this.format = format;
        this.source = source;
        this.convertedPayload = convertedPayload;
    }

    public void setDocumentForConfig(DocumentForConfig documentForConfig) {
        this.documentForConfig = documentForConfig;
    }

    public DocumentForConfig getDocumentForConfig() {
        return documentForConfig;
    }

    public boolean isJson() {
        return format.equals(PayloadFormatEnum.JSON);
    }

    public JsonNode getPayloadAsJsonNode() {
        if(isJson()) {
            return (JsonNode) convertedPayload;
        }

        throw new UnsupportedOperationException("Payload is not in JSON format");
    }

    public JsonMessage getPayloadAsJsonMessage() {
        if(isJson()) {
            return new JsonMessage((JsonNode) convertedPayload);
        }

        throw new UnsupportedOperationException("Payload is not in JSON format");
    }

    public boolean isXml() {
        return format.equals(PayloadFormatEnum.XML);
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    /*
    NOTE: This comment here is to show how we will be dealing with formats other than JSON.
    We need to add as many method as we support for each format.

    Practically it will only be a handful of these methods as there are limited number of formats

    public JAXBElement getPayloadAsJaxbElement() {
        if(isXml()) {
            return (JAXBElement) convertedPayload;
        }

        throw new UnsupportedOperationException("Payload is not in XML format");
    }

    */

}
