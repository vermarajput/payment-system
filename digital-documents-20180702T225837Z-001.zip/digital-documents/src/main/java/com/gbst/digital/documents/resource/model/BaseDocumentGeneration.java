package com.gbst.digital.documents.resource.model;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 15/03/2018
 */
public abstract class BaseDocumentGeneration<T extends Document> {
    // below will serve as input
    protected String processType;
    protected String processTypeId;
    protected String role;
    protected String processStage;

    protected String documentAttributes; // Payload
    protected PayloadFormatEnum documentAttributesFormat;

    public abstract List<T> getDocuments();

    public abstract void setDocuments(List<T> documents);

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public String getProcessTypeId() {
        return processTypeId;
    }

    public void setProcessTypeId(String processTypeId) {
        this.processTypeId = processTypeId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getProcessStage() {
        return processStage;
    }

    public void setProcessStage(String processStage) {
        this.processStage = processStage;
    }

    public String getDocumentAttributes() {
        return documentAttributes;
    }

    public void setDocumentAttributes(String documentAttributes) {
        this.documentAttributes = documentAttributes;
    }

    public PayloadFormatEnum getDocumentAttributesFormat() {
        return documentAttributesFormat;
    }

    public void setDocumentAttributesFormat(PayloadFormatEnum documentAttributesFormat) {
        this.documentAttributesFormat = documentAttributesFormat;
    }
}
