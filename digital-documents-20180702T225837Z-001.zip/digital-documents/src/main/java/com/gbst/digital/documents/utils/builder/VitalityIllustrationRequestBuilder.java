package com.gbst.digital.documents.utils.builder;

import com.gbst.common.jsonapi.JsonApiException;
import com.gbst.digital.documents.resource.model.document.CustomField;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.utils.IllustrationSelectorEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.*;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

/**
 * All components profiled with client's name should be annotated with @Primary so that @{@link DefaultClientSpecificIllustrationRequestBuilder} won't be autowired.
 *
 * Created by Aman Verma on 1/03/2018.
 */
@Profile("vitality")
@Component
@Primary
//All components profiled with client's name should be annotated with Primary so that DefaultClientSpecificIllustrationRequestBuilder won't be autowired
public class VitalityIllustrationRequestBuilder implements ClientSpecificRequestBuilder {

    private ObjectFactory requestObjectFactory = new ObjectFactory();
    /**
     * Enriches illustration Request with Client specific data fields
     *
     * @param req
     * @param document
     * @param productType
     * @param processType
     * @param illustrationSelectorEnum
     * @param isISA
     */
    @Override
    public void enrichRequest(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType productType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        setCustomFields(req, document, productType, processType, illustrationSelectorEnum, isISA);
    }

    /**
     * Sets values Custom fields if present in to following fields
     * <p>accumulationBoostVersionId</p>
     * <p>incomeBoostVersionId</p>
     * <p>healthStatus</p>
     * <p>qualifyingPolicy</p>
     * <p>plusPolicy</p>
     *
     * @param req
     * @param document
     * @param productType
     * @param processType
     * @param illustrationSelectorEnum
     */
    private void setCustomFields(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType productType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(document.getCustomFields() == null) {
            return;
        }
        if(req.getIllustrationPayload().getAdditionalClientData() == null) {
            req.getIllustrationPayload().setAdditionalClientData(requestObjectFactory.createAdditionalClientDataType()); //Should be set before setting CustomFields or
        }
        //As QualifyingOpeningBalances cannot be Null as per CBIS so created an outer object. //TODO quotes mapping not known
        req.getIllustrationPayload().getAdditionalClientData().setQualifyingOpeningBalances(requestObjectFactory.createAdditionalClientDataTypeQualifyingOpeningBalances());

        if (document.getApplyBoostFlag() != null || document.getExistingPolicyFlag() != null) {
            boolean plusPolicy = Boolean.TRUE.equals(document.getApplyBoostFlag()) || Boolean.TRUE.equals(document.getExistingPolicyFlag());
            req.getIllustrationPayload().getAdditionalClientData().setPlusPolicy(plusPolicy ? "Y" : "N");
        }
        
        String productFlag = productType.getDetails().getProductFlag();
        for (CustomField field : document.getCustomFields()) {
            if ("accumulationBoostVersionId".equals(field.getKey()) && isAccumulationBoostVersionIdApplicable(document, processType, illustrationSelectorEnum, productFlag, isISA)) {
                req.getIllustrationPayload().getAdditionalClientData().setAccumulationBoostVersionId(new BigDecimal(field.getValue()));
            } else if ("incomeBoostVersionId".equals(field.getKey()) && isIncomeBoostVersionIdApplicable(document, processType, illustrationSelectorEnum, productFlag, isISA)) {
                req.getIllustrationPayload().getAdditionalClientData().setIncomeBoostVersionId(new BigDecimal(field.getValue()));
            } else if ("HEALTH_STATUS".equals(field.getKey())) {
                req.getIllustrationPayload().getAdditionalClientData().setHealthStatus(field.getValue());
            } else if ("QUALIFYING_POLICY".equals(field.getKey())) {
                req.getIllustrationPayload().getAdditionalClientData().setQualifyingPolicy(field.getValue());
            }
        }
    }

    private boolean isIncomeBoostVersionIdApplicable(DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, String productFlag, boolean isISA) {
        if (ProcessType.DRAWDOWN.equals(processType) && DrawdownIllustration.equals(illustrationSelectorEnum)) {
            return true;
        } else if (ProcessType.NEW_BUSINESS.equals(processType) && ("P".equalsIgnoreCase(productFlag))) {
            return true;
        }
        return false;
    }

    /**
     * Checks if the request is for Partial Drawdown and the document is for Accumulation
     *
     *
     * @param document
     * @param processType
     * @param illustrationSelectorEnum
     * @param productFlag
     * @return
     */
    private boolean isAccumulationBoostVersionIdApplicable(DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, String productFlag, boolean isISA) {
        if (ProcessType.DRAWDOWN.equals(processType) && AccumulationIllustration.equals(illustrationSelectorEnum)) {
            return true;
        } else if (ProcessType.TOPUP.equals(processType) || isISA) {
            return true;
        } else if (ProcessType.NEW_BUSINESS.equals(processType) && ("A".equalsIgnoreCase(productFlag))) {
            return true;
        }
        return false;
    }


}
