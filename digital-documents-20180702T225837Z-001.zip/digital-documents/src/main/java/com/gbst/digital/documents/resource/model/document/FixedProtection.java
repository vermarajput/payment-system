package com.gbst.digital.documents.resource.model.document;
/***
 * @author nehas
 */
public class FixedProtection {

    private String year;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
