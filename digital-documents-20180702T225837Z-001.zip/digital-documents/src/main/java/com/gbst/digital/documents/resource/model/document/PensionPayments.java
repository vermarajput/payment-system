package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/**
 * @author rekhar on 23/10/2017
 */
public class PensionPayments {

    private Boolean pensionPaymentsFlag;
    private String sourceOfIncome;
    private BigDecimal ltaPercent;
    private BigDecimal annualIncome;
    private String provider;

    public Boolean getPensionPaymentsFlag() {
        return pensionPaymentsFlag;
    }

    public void setPensionPaymentsFlag(Boolean pensionPaymentsFlag) {
        this.pensionPaymentsFlag = pensionPaymentsFlag;
    }

    public String getSourceOfIncome() {
        return sourceOfIncome;
    }

    public void setSourceOfIncome(String sourceOfIncome) {
        this.sourceOfIncome = sourceOfIncome;
    }

    public BigDecimal getLtaPercent() {
        return ltaPercent;
    }

    public void setLtaPercent(BigDecimal ltaPercent) {
        this.ltaPercent = ltaPercent;
    }

    public BigDecimal getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(BigDecimal annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }
}
