package com.gbst.digital.documents.config;

import com.gbst.digital.documents.storage.util.FileSystemStorageUtil;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;

/**
 * @author nehas
 */
@Configuration
public class StorageConfig {

    private static final Logger LOG = LoggerFactory.getLogger(StorageConfig.class);

    @Value("${gbst.digital.filesystem.root.path.prefix}")
    private String fileSystemRootPath;

    @Value("${gbst.digital.filesystem.parent.folder.name}")
    private String storageParentFolder;


    private String getFileSystemStorageRootPath() {
        String workingDirectory = System.getProperty("user.dir");
        if(!StringUtils.isEmpty(fileSystemRootPath)){
            workingDirectory = fileSystemRootPath;
        }
        return workingDirectory + File.separator + storageParentFolder;
    }

    @Bean
    public FileSystemStorageUtil fileSystemStorageUtil(){
        String documentStorageParentFolderPath = getFileSystemStorageRootPath();
        File directory = new File(documentStorageParentFolderPath);
        try {
            if(!directory.exists()) {
                FileUtils.forceMkdir(directory);
            }
        } catch (IOException e) {
            LOG.error("Failed to create parent document directory at path - " + documentStorageParentFolderPath);
        }
        FileSystemStorageUtil fileSystemStorageUtil = new FileSystemStorageUtil();
        fileSystemStorageUtil.setDocumentFolderRootPath(documentStorageParentFolderPath);
        return fileSystemStorageUtil;
    }

}

