package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/***
 * @author nehas
 */
public class OtherProtection {
    private BigDecimal ltaEnhancementFactor;

    public BigDecimal getLtaEnhancementFactor() {
        return ltaEnhancementFactor;
    }

    public void setLtaEnhancementFactor(BigDecimal ltaEnhancementFactor) {
        this.ltaEnhancementFactor = ltaEnhancementFactor;
    }
}
