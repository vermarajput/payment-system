package com.gbst.digital.documents.resource.model;

import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;

/**
 * Holds details for document listing
 *
 * @author rekhar on 19/09/2017
 * @author nehas updated on 12/10/2017 ,  07/11/2017
 * @author Aman Verma updated on 11/10/2017
 * @author Aman Verma updated on 20/11/2017
 */
public class Document {

    private String url; // url  - for static document type
    private String documentDisplayName;
    private String documentName; // document type
    private String generationStrategy; //WindWard, Illustration, Static
    private OutputTypeEnum outputType; //Defaulted to PDF, rest depends on UI

    public Document() {
    } // Default constructor

    public Document(String url, String documentName, String generationStrategy, OutputTypeEnum outputType, String documentDisplayName) {
        this.url = url;
        this.documentName = documentName;
        this.generationStrategy = generationStrategy;
        this.outputType = outputType;
        this.documentDisplayName = documentDisplayName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getGenerationStrategy() {
        return generationStrategy;
    }

    public void setGenerationStrategy(String generationStrategy) {
        this.generationStrategy = generationStrategy;
    }

    public OutputTypeEnum getOutputType() {
        return outputType;
    }

    public void setOutputType(OutputTypeEnum outputType) {
        this.outputType = outputType;
    }

    public String getDocumentDisplayName() {
        return documentDisplayName;
    }

    public void setDocumentDisplayName(String documentDisplayName) {
        this.documentDisplayName = documentDisplayName;
    }

    @Override
    public String toString() {
        return "Document{" +
                "url='" + url + '\'' +
                ", documentName='" + documentName + '\'' +
                ", generationStrategy='" + generationStrategy + '\'' +
                ", outputType=" + outputType +
                ", documentDisplayName=" + documentDisplayName +
                "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Document document = (Document) o;

        return documentName.equals(document.documentName);
    }

    @Override
    public int hashCode() {
        return documentName.hashCode();
    }
}
