package com.gbst.digital.documents.security.composer;

import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.AbstractPermissions;
import com.gbst.common.auth.perms.ConditionalOnPermissionProvider;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.PermissionProviderEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.common.party.PartyTypeEnum;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 6/02/2018
 */
@Service
@Profile("permissions")
@ConditionalOnPermissionProvider(PermissionProviderEnum.Composer)
public class DocumentGenerationPermissions extends AbstractPermissions<DocumentGeneration, OperationEnum> implements Permissions<DocumentGeneration, OperationEnum> {

    @Override
    public void check(OperationEnum type, DocumentGeneration resource) throws GbstJsonApiAccessDeniedException {
        if(type.in(OperationEnum.FindOne, OperationEnum.SaveUpdate, OperationEnum.Delete)) {
            GbstPrincipal principal = authenticationFacade.getPrincipal();
            if(!resource.getOwner().equalsIgnoreCase(principal.getGbstPartyId() + principal.getGbstPartyType())) {
                throw new GbstJsonApiAccessDeniedException("document-generations", resource.getId());
            }
        }
    }
}
