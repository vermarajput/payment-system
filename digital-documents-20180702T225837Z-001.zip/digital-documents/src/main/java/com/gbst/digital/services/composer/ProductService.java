package com.gbst.digital.services.composer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.auth.perms.ConditionalOnPermissionProvider;
import com.gbst.common.auth.perms.PermissionProviderEnum;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.common.rest.JsonUrlBuilder;
import com.gbst.digital.Services;
import com.infocomp.cbis.uk.request.GetProductDetailsType;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.response.Product;
import com.infocomp.cbis.uk.response.ProductDetailsType;
import com.infocomp.cbis.uk.response.SubFund;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.ws.client.core.WebServiceTemplate;

import javax.xml.bind.JAXBElement;
import java.io.IOException;
import java.util.Iterator;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 12/10/2017
 */
@Service
@ConditionalOnPermissionProvider(PermissionProviderEnum.Composer)
public class ProductService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);
    private static final ObjectFactory objectFactory = new ObjectFactory();

    @Autowired
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Autowired
    OAuth2RestTemplate restOperations;

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    @Autowired
    ObjectMapper mapper;

    @Cacheable("productTypes")
    public ProductTypes getProductTypes(Integer subFundId, Integer productTypeId, Integer investmentId, Boolean includeInvestments, Boolean active) {

        GetProductDetailsType req = objectFactory.createGetProductDetailsType();
        req.setSubFundId(subFundId);
        req.setProductTypeId(productTypeId);
        req.setInvestmentId(investmentId);
        if (active != null) {
            req.setActiveFlag(active ? "Y" : "N");
        }
        if (includeInvestments != null) {
            req.setIncludeInvestments(includeInvestments ? "Y" : "N");
        }
        JAXBElement<ProductDetailsType> response = (JAXBElement<ProductDetailsType>)
                webServiceTemplate.marshalSendAndReceive(multiUrlConnectionSettings.getConnections().get(Services.CBIS).getUrl(),objectFactory.createGetProductDetails(req));
        ProductTypes productTypes = new ProductTypes();

        for(SubFund sf : response.getValue().getFunds().getFund().get(0).getSubfunds().getSubfund()) {

            for(Product p : sf.getProducts().getProduct()) {

                ProductTypes.ProductType pt = new ProductTypes.ProductType(p);
                pt.setSubFundId(sf.getSubFundId());
                pt.setSubFundName(sf.getSubFundName());
                pt.setSubFundShortCode(sf.getSubFundShortCode());
                productTypes.addProductType(pt);
            }
        }

        return productTypes;
    }

    @Cacheable("productTypeById")
    public ProductTypes.ProductType getProductType(Integer productTypeId) {
        ProductTypes productTypes = getProductTypes(null, null, null, false, true);
        return productTypes.getProductType(productTypeId);
    }

    /**
     * Determines the associated idd product type id for a sipp product using the same subfund.
     * Uses current composer product type id. If current product type id of this account is not
     * accumulation exception is thrown.
     * If IDD product type is current product type then it will be returned as there should
     * only be one Pension product in product types for the same subfund.
     * @param productTypeId product type id.
     * @return associated IDD product type.
     */
    public ProductTypes.ProductType getAssociatedIDDProductType(Integer productTypeId) {
        Integer subfundId = null;

        ProductTypes productType = getProductTypes(null, null, null, null, true);

        for(ProductTypes.ProductType pt : productType.getProductTypes()) {
            if(productTypeId.equals(pt.getDetails().getProductTypeId())) {
               if(!ProductTypeFlagEnum.Accumulation.getValue().equals(pt.getDetails().getProductFlag())) {
                   LOGGER.warn("Product {} is not an accumulation product and IDD product cannot be determined!", productTypeId);
                   throw new IllegalArgumentException("Cannot determine IDD product type as the product type is not accumulation.");
               }
               subfundId = pt.getSubFundId();
               break;
            }
        }

        if(subfundId == null) {
            LOGGER.error("Could not determine the associated sub-fund for product type {}", productTypeId);
            throw new IllegalStateException("No sub-fund associated with product type '"+productTypeId+"' were found");
        }

        for(ProductTypes.ProductType pt : productType.getProductTypes()) {
            if(pt.getSubFundId() == subfundId &&
                    ProductTypeFlagEnum.Pension.getValue().equals(pt.getDetails().getProductFlag())) {
                return pt;
            }
        }

        LOGGER.warn("No IDD product type could be found associated with product type {}", productTypeId);
        throw new IllegalStateException("No IDD product type were found.");
    }

    public boolean isISA(String productTypeId) {
        JsonUrlBuilder builder = JsonUrlBuilder.fromUrl(multiUrlConnectionSettings.getConnections().get(Services.COMPOSER).getUrl(), null, "product-web-enabled");

        ResponseEntity<String> response = restOperations.getForEntity(builder.toUri(), String.class);

        if(response.getStatusCode() != HttpStatus.OK && response.getStatusCode() != HttpStatus.ACCEPTED) {
            LOGGER.error("Could not get a response from Composer API. Code: {} Body: {} ", response.getStatusCode(), response);
            throw new IllegalStateException("Could not get a response from Composer API: " + response.getStatusCode());
        }

        JsonMessage message;
        try {
            JsonNode resp = mapper.readTree(response.getBody());
            message = new JsonMessage(resp);
        } catch (IOException x) {
            LOGGER.error("Could not parse the response from Composer API. Body: {} ", response);
            throw new IllegalStateException("Could not parse the response from Composer API: " + response.getBody(), x);
        }

        Iterator<JsonNode> items = message.with("/data").getIterator();
        while(items.hasNext()) {
            JsonNode item = items.next();
            if(!productTypeId.equals(item.at("/id").asText()) ||
                    !"I".equalsIgnoreCase(item.at("/attributes/productFlag").asText())) {
                continue;
            }

            return item.at("/attributes/taxWrapperTypeCode").isArray() &&
                    item.at("/attributes/taxWrapperTypeCode").elements().hasNext();
        }
        return false;
    }
}
