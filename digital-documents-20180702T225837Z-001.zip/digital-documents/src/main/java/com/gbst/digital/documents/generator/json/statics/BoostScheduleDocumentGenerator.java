package com.gbst.digital.documents.generator.json.statics;

import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.statics.AbstractStaticDocumentGenerator;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 28/03/2018
 */
@Profile("vitality") //This is only applicable for vitality.
@ConditionalOnProperty(value = "gbst.digital.documents.types.boostScheduleDocument", havingValue = "Config")
@Service
public class BoostScheduleDocumentGenerator extends AbstractStaticDocumentGenerator implements DocumentGenerator {

    @Autowired
    ProductService productService;

    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {
        /*
        Requirement says:
        Boost Schedule: required when opening a SIPP (accumulation OR partial immediate crystallisation), ISA or JISA and Vitality assets are selected.
        Additionally, when some processes (e.g. Top-up or Switch) occur within certain products with Vitality assets selected, Boost or RIB Schedule documents must be generated.

        Translation:
        (Asset either primary or secondary is vitality asset, that is assetAttribute has 'BOOST_ALLOWED' value
        OR
        Any BuyInvestment has assetAttribute and value 'BOOST_ALLOWED')

        AND

        (ProcessTYpe is DRAWDOWN and crystalliseFullAmountFlag = false

        OR

        Primary product type is 'A' for any other process type

        OR

        product is ISA regardless of ProcessType
        
         */

        if (!payload.isJson()) {
            return false;
        }
        DocumentForConfig conf = payload.getDocumentForConfig();

        if (!GenerationStrategyEnum.STATIC.getValue().equalsIgnoreCase(conf.getGenerationStrategy())) {
            return false;
        }

        if (!DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name().equalsIgnoreCase(conf.getDocumentName())) {
            return false;
        }

        JsonMessage jm = payload.getPayloadAsJsonMessage();

        List<String> investmentAssetAttribute = jm.withJsonPath("$.investmentStrategy.investments[*].assetAttribute").ofType(String.class).getArray();
        List<String> buyInvestmentAssetAttribute = jm.withJsonPath("$.trade.buyInvestments[*].assetAttribute").ofType(String.class).getArray();

        boolean vitalityAsset = (investmentAssetAttribute != null && !investmentAssetAttribute.isEmpty() && checkBoostAllowedValue(investmentAssetAttribute))
                || (buyInvestmentAssetAttribute != null && !buyInvestmentAssetAttribute.isEmpty() && checkBoostAllowedValue(buyInvestmentAssetAttribute));

        if (!vitalityAsset) {
            return false;
        }

        if (ProcessType.DRAWDOWN.name().equalsIgnoreCase(document.getProcessType())) {
            return !jm.with("/crystallisationDetails/crystalliseFullAmountFlag").ofType(Boolean.class).whenMissingOrNull(Boolean.FALSE).getActual();
        }

        Integer productTypeId = jm.with("/productTypeId").ofType(Integer.class).getActual();

        ProductTypes.ProductType productType = productService.getProductType(productTypeId);
        if ("A".equalsIgnoreCase(productType.getDetails().getProductFlag())) {
            return true;
        }

        return productService.isISA("" + productTypeId);

    }

    private boolean checkBoostAllowedValue(List<String> assetAttributes) {
        if (assetAttributes.size() > 0) {
            for (String assetAttribute : assetAttributes) {
                if (assetAttribute.equalsIgnoreCase("BOOST_ALLOWED")) {
                    return true;
                }
            }
        }
        return false;
    }

}
