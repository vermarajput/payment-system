package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.document.types.PurchaseByEnum;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Cecily on 28/03/2018
 */
public class BuyInvestments extends BaseInvestment {

    private PurchaseByEnum purchaseBy;
    private String name;
    private BigDecimal units;
    private BigDecimal lastPrice;
    private BigDecimal estimatedValue;
    private BigDecimal purchaseAmount;
    private BigDecimal purchasePercent;
    private BigDecimal purchaseUnits;
    private BigDecimal estimatedPurchaseValue;
    private String distributionReinvestmentOption;

    public BuyInvestments() {
    }

    public PurchaseByEnum getPurchaseBy() {
        return purchaseBy;
    }

    public void setPurchaseBy(PurchaseByEnum purchaseBy) {
        this.purchaseBy = purchaseBy;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getUnits() {
        return units;
    }

    public void setUnits(BigDecimal units) {
        this.units = units;
    }

    public BigDecimal getLastPrice() {
        return lastPrice;
    }

    public void setLastPrice(BigDecimal lastPrice) {
        this.lastPrice = lastPrice;
    }

    public BigDecimal getEstimatedValue() {
        return estimatedValue;
    }

    public void setEstimatedValue(BigDecimal estimatedValue) {
        this.estimatedValue = estimatedValue;
    }

    public BigDecimal getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(BigDecimal purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    public BigDecimal getPurchasePercent() {
        return purchasePercent;
    }

    public void setPurchasePercent(BigDecimal purchasePercent) {
        this.purchasePercent = purchasePercent;
    }

    public BigDecimal getPurchaseUnits() {
        return purchaseUnits;
    }

    public void setPurchaseUnits(BigDecimal purchaseUnits) {
        this.purchaseUnits = purchaseUnits;
    }

    public BigDecimal getEstimatedPurchaseValue() {
        return estimatedPurchaseValue;
    }

    public void setEstimatedPurchaseValue(BigDecimal estimatedPurchaseValue) {
        this.estimatedPurchaseValue = estimatedPurchaseValue;
    }

    public String getDistributionReinvestmentOption() {
        return distributionReinvestmentOption;
    }

    public void setDistributionReinvestmentOption(String distributionReinvestmentOption) {
        this.distributionReinvestmentOption = distributionReinvestmentOption;
    }

    @Override
    public String toString() {
        return "BuyInvestments{" +
                "purchaseBy=" + purchaseBy +
                ", name='" + name + '\'' +
                ", units=" + units +
                ", lastPrice=" + lastPrice +
                ", estimatedValue=" + estimatedValue +
                ", purchaseAmount=" + purchaseAmount +
                ", purchasePercent=" + purchasePercent +
                ", purchaseUnits=" + purchaseUnits +
                ", estimatedPurchaseValue=" + estimatedPurchaseValue +
                ", distributionReinvestmentOption='" + distributionReinvestmentOption + '\'' +
                '}';
    }
}
