
package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

public enum TransferFullPartialTypeEnum implements GBSTEnumable<String>
{
    Full("Full"),
    Partial("Partial");

    private String value;

    TransferFullPartialTypeEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

}
