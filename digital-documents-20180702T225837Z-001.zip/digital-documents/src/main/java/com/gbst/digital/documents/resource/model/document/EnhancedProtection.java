package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/***
 * @author nehas
 */
public class EnhancedProtection {

    private BigDecimal enhancedPCLS;

    public BigDecimal getEnhancedPCLS() {
        return enhancedPCLS;
    }

    public void setEnhancedPCLS(BigDecimal enhancedPCLS) {
        this.enhancedPCLS = enhancedPCLS;
    }
}
