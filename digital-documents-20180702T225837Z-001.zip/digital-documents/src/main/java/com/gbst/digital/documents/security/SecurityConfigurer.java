package com.gbst.digital.documents.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.vote.AffirmativeBased;

import java.util.Arrays;

@Configuration
public class SecurityConfigurer {
    @Bean
    @Primary
    public AccessDecisionManager accessDecisionManager(AccessVoter accessVoter) {
        return new AffirmativeBased(Arrays.asList(accessVoter));
    }
}
