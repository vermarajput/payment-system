package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * @author rekhar on 3/10/2017
 */
public enum InvestmentMethodEnum implements GBSTEnumable<String> {

    ChequeReceipt("CHEQUE_RECEIPT"),
    CHAPS("CHAPS"),
    BACS("BACS"),
    DirectDepositIn("DIRECT_DEPOSIT_IN"),
    DebitCard("DEBITCARD");
    private String value;

    InvestmentMethodEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }
}
