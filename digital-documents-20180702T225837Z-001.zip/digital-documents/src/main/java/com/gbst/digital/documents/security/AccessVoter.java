package com.gbst.digital.documents.security;

import com.gbst.common.auth.DefaultAccessVoter;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.monitoring.metrics.MeasureMe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Objects;

/*
* Created by Aman Verma on 10/10/2017.
*/
@Component
@MeasureMe
public class AccessVoter extends DefaultAccessVoter implements AccessDecisionVoter<FilterInvocation> {

    private Logger LOG = LoggerFactory.getLogger(AccessVoter.class);

}
