package com.gbst.digital.documents.resource.model.document;

import com.gbst.digital.documents.resource.model.document.types.SippTransferTypeEnum;

import java.math.BigDecimal;

public class SippTransferIn extends TransferIn{

    private Boolean occupationalSchemeFlag;
    private Boolean definedBenefitsSchemeFlag;
    private Boolean disqualifiedPensionCreditFlag;
    private BigDecimal protectedPCLS;
    private Integer protectedAge;
    private Boolean updateRetirementAgeFlag;
    private Boolean registeredPensionSchemeFlag;
    private SippTransferTypeEnum transferType;

    public SippTransferIn(){
    }

    public SippTransferTypeEnum getTransferType() {
        return transferType;
    }

    public void setTransferType(SippTransferTypeEnum transferType) {
        this.transferType = transferType;
    }

    public Boolean isOccupationalSchemeFlag() {
        return occupationalSchemeFlag;
    }

    public void setOccupationalSchemeFlag(Boolean occupationalSchemeFlag) {
        this.occupationalSchemeFlag = occupationalSchemeFlag;
    }

    public Boolean isDefinedBenefitsSchemeFlag() {
        return definedBenefitsSchemeFlag;
    }

    public void setDefinedBenefitsSchemeFlag(Boolean definedBenefitsSchemeFlag) {
        this.definedBenefitsSchemeFlag = definedBenefitsSchemeFlag;
    }

    public Boolean isDisqualifiedPensionCreditFlag() {
        return disqualifiedPensionCreditFlag;
    }

    public void setDisqualifiedPensionCreditFlag(Boolean disqualifiedPensionCreditFlag) {
        this.disqualifiedPensionCreditFlag = disqualifiedPensionCreditFlag;
    }

    public BigDecimal getProtectedPCLS() {
        return protectedPCLS;
    }

    public void setProtectedPCLS(BigDecimal protectedPCLS) {
        this.protectedPCLS = protectedPCLS;
    }

    public Integer getProtectedAge() {
        return protectedAge;
    }

    public void setProtectedAge(Integer protectedAge) {
        this.protectedAge = protectedAge;
    }

    public Boolean isUpdateRetirementAgeFlag() {
        return updateRetirementAgeFlag;
    }

    public void setUpdateRetirementAgeFlag(Boolean updateRetirementAgeFlag) {
        this.updateRetirementAgeFlag = updateRetirementAgeFlag;
    }

    public Boolean getRegisteredPensionSchemeFlag() {
        return registeredPensionSchemeFlag;
    }

    public void setRegisteredPensionSchemeFlag(Boolean registeredPensionSchemeFlag) {
        this.registeredPensionSchemeFlag = registeredPensionSchemeFlag;
    }
}
