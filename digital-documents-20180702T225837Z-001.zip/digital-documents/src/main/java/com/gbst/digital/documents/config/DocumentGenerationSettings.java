package com.gbst.digital.documents.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 12/03/2018
 */
@ConfigurationProperties(prefix = "gbst.digital.documents")
@Validated
public class DocumentGenerationSettings {

    private Map<String, GeneratorTypeEnum> types;


    public Map<String, GeneratorTypeEnum> getTypes() {
        return types;
    }

    public void setTypes(Map<String, GeneratorTypeEnum> types) {
        this.types = types;
    }

    public GeneratorTypeEnum getProvider(String documentType) {
        return types.get(documentType);
    }

    public enum GeneratorTypeEnum {
        Windward,
        CIE,
        Config
    }
}
