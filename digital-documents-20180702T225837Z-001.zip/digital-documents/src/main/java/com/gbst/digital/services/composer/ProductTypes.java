package com.gbst.digital.services.composer;

import com.infocomp.cbis.uk.response.Product;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 12/10/2017
 */
public class ProductTypes {

	private Map<Integer, ProductType> productTypes = new HashMap<>();

	public ProductType getProductType(Integer productTypeId) {
		return productTypes.get(productTypeId);
	}

	public Collection<ProductType> getProductTypes() {
		return productTypes.values();
	}

	public void addProductType(ProductType productType) {
		productTypes.put(productType.getDetails().getProductTypeId(), productType);
	}

	public static class ProductType {
		private Product details;
		private int subFundId;
		private String subFundName;
		private String subFundShortCode;

		public ProductType(Product product) {
			this.details = product;
		}

		public Product getDetails() {
			return details;
		}

		public void setDetails(Product details) {
			this.details = details;
		}

		public void setSubFundId(int subFundId) {
			this.subFundId = subFundId;
		}

		public int getSubFundId() {
			return subFundId;
		}

		public void setSubFundName(String subFundName) {
			this.subFundName = subFundName;
		}

		public String getSubFundName() {
			return subFundName;
		}

		public void setSubFundShortCode(String subFundShortCode) {
			this.subFundShortCode = subFundShortCode;
		}

		public String getSubFundShortCode() {
			return subFundShortCode;
		}
	}
}
