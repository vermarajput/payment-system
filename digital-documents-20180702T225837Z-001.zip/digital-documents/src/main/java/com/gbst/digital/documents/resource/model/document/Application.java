package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/**
 * @author rekhar on 25/09/2017
 */
public class Application {
    private BigDecimal amount;
    private BigDecimal initialChargeAmount;
    private BigDecimal initialChargePercent;

    public Application() {
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getInitialChargeAmount() {
        return initialChargeAmount;
    }

    public void setInitialChargeAmount(BigDecimal initialChargeAmount) {
        this.initialChargeAmount = initialChargeAmount;
    }

    public BigDecimal getInitialChargePercent() {
        return initialChargePercent;
    }

    public void setInitialChargePercent(BigDecimal initialChargePercent) {
        this.initialChargePercent = initialChargePercent;
    }
}
