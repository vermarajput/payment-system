package com.gbst.digital.documents.storage;

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;

import javax.naming.OperationNotSupportedException;
import javax.xml.datatype.DatatypeConfigurationException;
import java.io.File;
import java.util.List;

/**
 * Created by Aman Verma on 11/10/2017.
 */
public interface DocumentStorage {
    DocumentWithParameter store(DocumentWithParameter documentWithParameter) throws DocumentStorageException;

    File downloadFile(String storagePath) throws DocumentStorageException;

    List<DocumentWithParameter> storeMultipleDocuments(List<DocumentWithParameter> documentWithParameters) throws DocumentStorageException;

    boolean supportsStorageType(String storageSystem);

    void removeFileFromStorage(String storagePath) throws DocumentStorageException;
}
