package com.gbst.digital.documents.storage.util;

import org.owasp.esapi.HTTPUtilities;
import org.owasp.esapi.reference.DefaultHTTPUtilities;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * Created by Aman Verma on 4/05/2018.
 *
 * Instantiates HttpUtilities
 */
@Configuration
public class HTTPUtilitiesConfigurer {
    /**
     * Returns instance of DefaultHTTPUtilities
     *
     * @return HTTPUtilities
     */
    @Bean
    public HTTPUtilities getHttpUtilities() {
        return DefaultHTTPUtilities.getInstance();
    }
}
