package com.gbst.digital.documents.resource.model;

import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import org.bson.types.ObjectId;

import java.time.Instant;

/**
 * Holds details for document generation
 *
 * @auther Aman Verma created on 20/11/2017
 */
public class DocumentForGeneration extends DocumentForConfig {

    private String documentKey;
    private Instant generatedDate;
    private GenerationStatusEnum generationStatus;
    private String statusMessage;
    private String externalId;

    /**
     * Default constructor
     */
    public DocumentForGeneration() {
        this.documentKey = new ObjectId().toHexString();
    }

    /**
     * DocumentForGeneration from DocumentForConfig
     *
     * @param docForConf
     */
    public DocumentForGeneration(DocumentForConfig docForConf) {
        super(docForConf.getUrl(), docForConf.getDocumentName(), docForConf.getGenerationStrategy(), docForConf.getOutputType(), docForConf.getTemplateFileName(), docForConf.getStorageSystem(), docForConf.getDocumentDisplayName());
        this.documentKey = new ObjectId().toHexString();
    }

    /**
     * Copy constructor
     *
     * @param docForGen
     */
    public DocumentForGeneration(DocumentForGeneration docForGen) {
        super(docForGen.getUrl(), docForGen.getDocumentName(), docForGen.getGenerationStrategy(), docForGen.getOutputType(), docForGen.getTemplateFileName(), docForGen.getStorageSystem(), docForGen.getDocumentDisplayName());
        this.documentKey = docForGen.getDocumentKey();
        this.generatedDate = docForGen.getGeneratedDate();
        this.generationStatus = docForGen.getGenerationStatus();
        this.statusMessage = docForGen.getStatusMessage();
        this.externalId = docForGen.getExternalId();
    }

    public String getDocumentKey() {
        return documentKey;
    }

    public void setDocumentKey(String documentKey) {
        this.documentKey = documentKey;
    }

    public Instant getGeneratedDate() {
        return generatedDate;
    }

    public void setGeneratedDate(Instant generatedDate) {
        this.generatedDate = generatedDate;
    }

    public GenerationStatusEnum getGenerationStatus() {
        return generationStatus;
    }

    public void setGenerationStatus(GenerationStatusEnum generationStatus) {
        this.generationStatus = generationStatus;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    @Override
    public String toString() {
        return "DocumentForGeneration{" +
                "documentKey='" + documentKey + '\'' +
                ", generatedDate=" + generatedDate +
                ", generationStatus=" + generationStatus +
                ", statusMessage='" + statusMessage + '\'' +
                ", externalId='" + externalId + '\'' +
                '}';
    }
}
