package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Cecily on 28/03/2018
 */
public class SellDetails extends BaseInvestment {

    private String name;
    private BigDecimal units;
    private BigDecimal lastPrice;
    private BigDecimal estimatedValue;
    private BigDecimal sellingAmount;
    private BigDecimal sellingPercent;
    private BigDecimal sellingUnits;
    private BigDecimal estimatedSaleValue;

    public SellDetails() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getUnits() {
        return units;
    }

    public void setUnits(BigDecimal units) {
        this.units = units;
    }

    public BigDecimal getLastPrice() {
        return lastPrice;
    }

    public void setLastPrice(BigDecimal lastPrice) {
        this.lastPrice = lastPrice;
    }

    public BigDecimal getEstimatedValue() {
        return estimatedValue;
    }

    public void setEstimatedValue(BigDecimal estimatedValue) {
        this.estimatedValue = estimatedValue;
    }

    public BigDecimal getSellingAmount() {
        return sellingAmount;
    }

    public void setSellingAmount(BigDecimal sellingAmount) {
        this.sellingAmount = sellingAmount;
    }

    public BigDecimal getSellingPercent() {
        return sellingPercent;
    }

    public void setSellingPercent(BigDecimal sellingPercent) {
        this.sellingPercent = sellingPercent;
    }

    public BigDecimal getSellingUnits() {
        return sellingUnits;
    }

    public void setSellingUnits(BigDecimal sellingUnits) {
        this.sellingUnits = sellingUnits;
    }

    public BigDecimal getEstimatedSaleValue() {
        return estimatedSaleValue;
    }

    public void setEstimatedSaleValue(BigDecimal estimatedSaleValue) {
        this.estimatedSaleValue = estimatedSaleValue;
    }

    @Override
    public String toString() {
        return "SellDetails{" +
                "name='" + name + '\'' +
                ", units=" + units +
                ", lastPrice=" + lastPrice +
                ", estimatedValue=" + estimatedValue +
                ", sellingAmount=" + sellingAmount +
                ", sellingPercent=" + sellingPercent +
                ", sellingUnits=" + sellingUnits +
                ", estimatedSaleValue=" + estimatedSaleValue +
                '}';
    }
}
