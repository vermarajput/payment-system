package com.gbst.digital.services.composer;

import com.gbst.common.data.GBSTEnumable;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 25/10/2017
 */
public enum ProductTypeFlagEnum implements GBSTEnumable<String> {
    Pension("P"),
    Accumulation("A");

    private String value;

    ProductTypeFlagEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumable.GBSTEnumableHelper.getEnumFromValue(ProductTypeFlagEnum.class, value, null);
    }

}
