package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/***
 * @author nehas
 */
public class IndividualProtection {

    private String year;
    private BigDecimal amount;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
