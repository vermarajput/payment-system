package com.gbst.digital.documents.generator.json.cie;

/**
 * Created by Aman Verma on 1/03/2018.
 */
public enum FieldConfigEnum {
    /**
     * The field will be included in the request. This is default behaviour if not configured
     */
    On,
    Off,
    Default;
}
