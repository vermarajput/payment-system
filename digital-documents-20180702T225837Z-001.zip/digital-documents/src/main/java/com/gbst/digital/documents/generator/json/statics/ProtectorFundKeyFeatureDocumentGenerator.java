package com.gbst.digital.documents.generator.json.statics;

import com.fasterxml.jackson.databind.JsonNode;
import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.statics.AbstractStaticDocumentGenerator;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.Iterator;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 28/03/2018
 */
@Profile("vitality") //This is only applicable for vitality.
@ConditionalOnProperty(value = "gbst.digital.documents.types.protectorFundKeyFeatureDocument", havingValue = "Config")
@Service
public class ProtectorFundKeyFeatureDocumentGenerator extends AbstractStaticDocumentGenerator implements DocumentGenerator {

    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {

        /*
         Requirement says:
         Protector Fund Key Features: required when an application is made for a new or existing SIPP, ISA or JISA which includes Protector Funds.

         Translation:
            Any investment (primary or secondary) has FundProtector key being set via customFields and the value should be 'Y'

            OR

            Any BuyInvestment has FundProtector key being set via customFields and the value should be 'Y'
         */
        
        if(!payload.isJson()) {
            return false;
        }

        DocumentForConfig conf = payload.getDocumentForConfig();

        if(!GenerationStrategyEnum.STATIC.getValue().equalsIgnoreCase(conf.getGenerationStrategy())) {
            return false;
        }

        if(!DocumentTypeEnum.STATIC_PROTECTOR_FUND_FEATURES.name().equalsIgnoreCase(conf.getDocumentName())) {
            return false;
        }

        boolean investmentFundProtectorFlag;
        boolean buyInvestmentFundProtectorFlag;

        JsonMessage jm = payload.getPayloadAsJsonMessage();

        Iterator<JsonNode> investmentFundProtectors = jm.withJsonPath("$..investmentStrategy.investments[*].customFields[?(@.key=='FundProtector')]").getIterator();

        Iterator<JsonNode> buyInvestmentFundProtectors = jm.withJsonPath("$.trade.buyInvestments[*].customFields[?(@.key=='FundProtector')]").getIterator();

        investmentFundProtectorFlag = getFundProtectorFlag(investmentFundProtectors);
        buyInvestmentFundProtectorFlag = getFundProtectorFlag(buyInvestmentFundProtectors);

        if(investmentFundProtectorFlag || buyInvestmentFundProtectorFlag) {
            return true;
        }

        return false;
    }

    private boolean getFundProtectorFlag(Iterator<JsonNode> fundProtectors) {
        if(fundProtectors.hasNext()) {
            JsonNode next = fundProtectors.next();
            if("FundProtector".equalsIgnoreCase(next.at("/key").asText()) && "Y".equalsIgnoreCase(next.at("/value").asText())) {
                //if there is one, true will be returned
                return true;
            }
        }
        return false;
    }

}
