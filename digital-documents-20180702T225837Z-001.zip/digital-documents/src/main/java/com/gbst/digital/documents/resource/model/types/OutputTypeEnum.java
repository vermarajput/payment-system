package com.gbst.digital.documents.resource.model.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * Stores the various document output types or extensions
 * @author nehas
 */

public enum OutputTypeEnum implements GBSTEnumable<String>
{
    PDF("pdf"),
    DOC("doc");

    private String value;

    OutputTypeEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

}