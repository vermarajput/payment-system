package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 25/10/2017
 */
public class CrystallisationDetails {

    private Boolean crystalliseFullAmountFlag = false;
    private BigDecimal amountToCrystallise;
    private BigDecimal partialAmount;
    private Boolean setToMaxFlag = false;
    private BigDecimal pclsAmount;
    private BigDecimal crystallisedValue;
    private BigDecimal uncrystallisedValue;

    public Boolean getCrystalliseFullAmountFlag() {
        return crystalliseFullAmountFlag;
    }

    public void setCrystalliseFullAmountFlag(Boolean crystalliseFullAmountFlag) {
        this.crystalliseFullAmountFlag = crystalliseFullAmountFlag;
    }

    public BigDecimal getPartialAmount() {
        return partialAmount;
    }

    public void setPartialAmount(BigDecimal partialAmount) {
        this.partialAmount = partialAmount;
    }

    public Boolean getSetToMaxFlag() {
        return setToMaxFlag;
    }

    public void setSetToMaxFlag(Boolean setToMaxFlag) {
        this.setToMaxFlag = setToMaxFlag;
    }

    public BigDecimal getPclsAmount() {
        return pclsAmount;
    }

    public void setPclsAmount(BigDecimal pclsAmount) {
        this.pclsAmount = pclsAmount;
    }

    public BigDecimal getCrystallisedValue() {
        return crystallisedValue;
    }

    public void setCrystallisedValue(BigDecimal crystallisedValue) {
        this.crystallisedValue = crystallisedValue;
    }

    public BigDecimal getUncrystallisedValue() {
        return uncrystallisedValue;
    }

    public void setUncrystallisedValue(BigDecimal uncrystallisedValue) {
        this.uncrystallisedValue = uncrystallisedValue;
    }

    public BigDecimal getAmountToCrystallise() {
        return amountToCrystallise;
    }

    public void setAmountToCrystallise(BigDecimal amountToCrystallise) {
        this.amountToCrystallise = amountToCrystallise;
    }
}
