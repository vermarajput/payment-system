package com.gbst.digital.documents.storage.util;

import com.gbst.common.party.PartyTypeSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.Metadata;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author rekhar on 9/11/2017
 */
@Component
public class MetadataHelper {

    @Autowired
    PartyTypeSettings partyTypeSettings;

    /**
     * @param documentWithParameter
     * @param documentAttributes
     * @return Metadata
     */
    public Metadata metadataForDocument(DocumentWithParameter documentWithParameter, DocumentAttributes documentAttributes) {
        Metadata metadata = new Metadata();
        metadata.setContentType((null != documentWithParameter.getDocument() && null != documentWithParameter.getDocument().getOutputType()) ? documentWithParameter.getDocument().getOutputType().getValue() : null);
        metadata.setDocumentType(documentWithParameter.getDocument().getDocumentName());
        metadata.setPayloadId(documentWithParameter.getProcessId());
        metadata.setAdviserId(null != documentAttributes.getAdviserId() ? Integer.parseInt(documentAttributes.getAdviserId()) : null);
        metadata.setPartyTypeId(null != documentAttributes.getOwnerType() ? partyTypeSettings.getValueAsInteger(Services.COMPOSER, documentAttributes.getOwnerType()) : null);
        metadata.setPartyId(null != documentAttributes.getOwnerId() ? Integer.parseInt(documentAttributes.getOwnerId()) : null);
        metadata.setCreationDate((null != documentWithParameter.getDocument() && null != documentWithParameter.getDocument().getGeneratedDate()) ? documentWithParameter.getDocument().getGeneratedDate() : null);
        metadata.setEffectiveDate((null != documentWithParameter.getDocument() && null != documentWithParameter.getDocument().getGeneratedDate()) ? documentWithParameter.getDocument().getGeneratedDate() : null);
        metadata.setFirstName(documentAttributes.getInvestorFirstName());
        metadata.setSurname(documentAttributes.getInvestorLastName());
        metadata.setNino(documentAttributes.getNationalInsuranceNumber());
        metadata.setDateOfBirth(null != documentAttributes.getInvestorDateOfBirth() ? documentAttributes.getInvestorDateOfBirth() : null);
        metadata.setInvestorId(null != documentAttributes.getInvestorId() ? Integer.parseInt(documentAttributes.getInvestorId()) : null);
        metadata.setInvestorAccountId(null != documentAttributes.getInvestorAccountId() ? Integer.parseInt(documentAttributes.getInvestorAccountId()) : null);
        metadata.setPostCode(null != documentAttributes.getInvestorActualAddress() ? documentAttributes.getInvestorActualAddress().getPostcode() : null);
        // Set documentUrl only when the GenerationStrategy is STATIC..
        metadata.setDocumentUrl((null != documentWithParameter.getDocument() && null != documentWithParameter.getDocument().getUrl() && documentWithParameter.getDocument().getGenerationStrategy().equals(GenerationStrategyEnum.STATIC.getValue())) ? documentWithParameter.getDocument().getUrl() : null);
        return metadata;
    }
}
