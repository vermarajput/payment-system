package com.gbst.digital.documents.resource.model;

import java.io.OutputStream;

/**
 * Created by Aman Verma on 1/11/2017.
 */
public class DocumentWithParameter {
    private String processType;
    private String processTypeId;
    private String role;
    private String processStage;
    private String processId;
    private String payload;
    /**
     * If not specified, the default format will be JSON
     */
    private PayloadFormatEnum payloadFormat = PayloadFormatEnum.JSON;
    private DocumentForGeneration document;
    private String owner;
    private OutputStream generatedDocumentStream;

    public DocumentWithParameter() {
    } // Default constructor

    public DocumentWithParameter(String processType, String processTypeId, String role, String processStage, String payload) {
        this.processType = processType;
        this.processTypeId = processTypeId;
        this.role = role;
        this.processStage = processStage;
        this.payload = payload;
    }

    public DocumentWithParameter(String processType, String processTypeId, String role, String processStage, String payload, DocumentForGeneration document) {
        this(processType, processTypeId, role, processStage, payload);
        this.document = document;
    }

    public DocumentWithParameter(String processType, String processTypeId, String role, String processStage, String payload, String processId, DocumentForGeneration document, String owner, OutputStream generatedDocumentStream) {
        this(processType, processTypeId, role, processStage, payload);
        this.processId = processId;
        this.owner = owner;
        this.generatedDocumentStream = generatedDocumentStream;
        this.document = document;
    }

    // Clone constructor
    public DocumentWithParameter(DocumentWithParameter orgDocWithParameter){
        this(orgDocWithParameter.getProcessType(),
                orgDocWithParameter.getProcessId(),
                orgDocWithParameter.getRole(),
                orgDocWithParameter.getProcessStage(),
                orgDocWithParameter.getPayload(),
                orgDocWithParameter.getProcessId(),
                new DocumentForGeneration(orgDocWithParameter.getDocument()),
                orgDocWithParameter.getOwner(),
                orgDocWithParameter.getGeneratedDocumentStream());
    }

    public String getProcessType() {
        return processType;
    }

    public DocumentWithParameter setProcessType(String processType) {
        this.processType = processType;
        return this;
    }

    public String getProcessTypeId() {
        return processTypeId;
    }

    public DocumentWithParameter setProcessTypeId(String processTypeId) {
        this.processTypeId = processTypeId;
        return this;
    }

    public String getRole() {
        return role;
    }

    public DocumentWithParameter setRole(String role) {
        this.role = role;
        return this;
    }

    public String getProcessStage() {
        return processStage;
    }

    public DocumentWithParameter setProcessStage(String processStage) {
        this.processStage = processStage;
        return this;
    }

    public String getProcessId() {
        return processId;
    }

    public DocumentWithParameter setProcessId(String processId) {
        this.processId = processId;
        return this;
    }

    public String getPayload() {
        return payload;
    }

    public DocumentWithParameter setPayload(String payload) {
        this.payload = payload;
        return this;
    }

    public DocumentForGeneration getDocument() {
        return document;
    }

    public DocumentWithParameter setDocument(DocumentForGeneration document) {
        this.document = document;
        return this;
    }

    public String getOwner() {
        return owner;
    }

    public DocumentWithParameter setOwner(String owner) {
        this.owner = owner;
        return this;
    }

    public OutputStream getGeneratedDocumentStream() {
        return generatedDocumentStream;
    }

    public DocumentWithParameter setGeneratedDocumentStream(OutputStream generatedDocumentStream) {
        this.generatedDocumentStream = generatedDocumentStream;
        return this;
    }

    public PayloadFormatEnum getPayloadFormat() {
        return payloadFormat;
    }

    public void setPayloadFormat(PayloadFormatEnum payloadFormat) {
        this.payloadFormat = payloadFormat;
    }

    public static DocumentWithParameter createDocumentWithParameter(final DocumentGeneration documentGenerationRequest, final DocumentForConfig docForConfig) {
        return new DocumentWithParameter(documentGenerationRequest.getProcessType(),
                documentGenerationRequest.getProcessTypeId(),
                documentGenerationRequest.getRole(),
                documentGenerationRequest.getProcessStage(),
                documentGenerationRequest.getDocumentAttributes(),
                documentGenerationRequest.getProcessId(),
                new DocumentForGeneration(docForConfig),
                documentGenerationRequest.getOwner(),
                null);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DocumentWithParameter that = (DocumentWithParameter) o;

        return document != null ? document.equals(that.document) : that.document == null;
    }

    @Override
    public int hashCode() {
        return document != null ? document.hashCode() : 0;
    }
}
