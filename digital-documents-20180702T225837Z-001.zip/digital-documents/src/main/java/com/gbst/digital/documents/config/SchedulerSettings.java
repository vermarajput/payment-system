package com.gbst.digital.documents.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

/**
 * @author rekhar on 13/03/2018
 */
@Profile("scheduler")
@Component
@ConfigurationProperties(prefix = "gbst.digital.documents")
public class SchedulerSettings {

    /**
     * Interval in which the scheduler starts
     */
    @NotNull
    private long schedulerFixedRateSeconds;

    public long getSchedulerFixedRateSeconds() {
        return schedulerFixedRateSeconds * 1000;
    }

    public void setSchedulerFixedRateSeconds(long schedulerFixedRateSeconds) {
        this.schedulerFixedRateSeconds = schedulerFixedRateSeconds;
    }
}
