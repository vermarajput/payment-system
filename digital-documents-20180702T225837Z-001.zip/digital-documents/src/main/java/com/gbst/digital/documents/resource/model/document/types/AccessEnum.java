package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * @author rekhar on 7/09/2017
 */
public enum AccessEnum implements GBSTEnumable<String> {

    Get("GET"),
    Post("POST"),
    Patch("PATCH"),
    Delete("DELETE"),
    Read("READ"),
    Write("WRITE");
    private String value;

    AccessEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }
}
