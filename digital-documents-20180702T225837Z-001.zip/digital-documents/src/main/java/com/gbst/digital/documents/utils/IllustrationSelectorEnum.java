package com.gbst.digital.documents.utils;

/**
 * Created by Aman Verma on 13/02/2018.
 */
public enum IllustrationSelectorEnum {
    /**
     * Other process types combinations
     */
    Default,
    DrawdownIllustration,
    AccumulationIllustration
}
