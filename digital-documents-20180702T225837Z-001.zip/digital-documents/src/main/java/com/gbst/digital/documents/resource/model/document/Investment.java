package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Aman Verma on 25/09/2017.
 */
public class Investment extends BaseInvestment{

    private BigDecimal investmentPercent;
    private Boolean disinvestmentPriorityFlag;

    public Investment() { }

    public BigDecimal getInvestmentPercent() {
        return investmentPercent;
    }

    public void setInvestmentPercent(BigDecimal investmentPercent) {
        this.investmentPercent = investmentPercent;
    }

    public Boolean getDisinvestmentPriorityFlag() {
        return disinvestmentPriorityFlag;
    }

    public void setDisinvestmentPriorityFlag(Boolean disinvestmentPriorityFlag) {
        this.disinvestmentPriorityFlag = disinvestmentPriorityFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Investment that = (Investment) o;

        return investmentId != null ? investmentId.equals(that.investmentId) : that.investmentId == null;
    }

    @Override
    public int hashCode() {
        return investmentId != null ? investmentId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Investment{" +
                "investmentId='" + investmentId + '\'' +
                ", investmentPercent=" + investmentPercent +
                '}';
    }
}
