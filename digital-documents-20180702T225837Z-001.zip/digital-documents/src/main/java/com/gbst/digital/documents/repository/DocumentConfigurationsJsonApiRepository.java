package com.gbst.digital.documents.repository;

import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.DefaultResourceRepository;
import com.gbst.common.jsonapi.GbstJsonApiUtils;
import com.gbst.common.jsonapi.ResourceNotFoundException;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import io.katharsis.queryParams.QueryParams;
import io.katharsis.repository.ResourceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author rekhar on 19/09/2017
 * @author Aman Verma on 17/11/2017
 * @author nehas on 21/12/2017
 */

@Component
public class DocumentConfigurationsJsonApiRepository extends DefaultResourceRepository<DocumentConfiguration, String> implements ResourceRepository<DocumentConfiguration, String> {

    private static final Logger LOG = LoggerFactory.getLogger(DocumentConfigurationsJsonApiRepository.class);

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    private RepositoryValidator repositoryValidator;

    @Autowired
    private RepositoryUtil repositoryUtil;

    @Autowired
    Permissions<DocumentConfiguration, OperationEnum> documentConfigurationPermissions;

    @Override
    public DocumentConfiguration save(DocumentConfiguration documentConfiguration) {

        documentConfigurationPermissions.check(OperationEnum.Save, documentConfiguration);

        repositoryValidator.validateDocConfig(documentConfiguration);
        mongoTemplate.save(documentConfiguration);
        return documentConfiguration;
    }

    @Override
    public DocumentConfiguration findOne(String id, QueryParams queryParams){
        DocumentConfiguration documentConfiguration = mongoTemplate.findById(id, DocumentConfiguration.class);
        if (documentConfiguration == null) {
            throw new ResourceNotFoundException(DocumentConfiguration.class, id);
        }
        return documentConfiguration;
    }

    @Override
    public Iterable<DocumentConfiguration> findAll(QueryParams documentConfigQueryParams) {
        Query query = repositoryUtil.findAllBasedOnQueryParams(documentConfigQueryParams, DocumentConfiguration.class);
        List<DocumentConfiguration> result = mongoTemplate.find(query, DocumentConfiguration.class);
        return GbstJsonApiUtils.createIterableResult(result);
    }

    @Override
    public void delete(String id){
        DocumentConfiguration documentConfiguration = findOne(id, new QueryParams());
        documentConfigurationPermissions.check(OperationEnum.Delete, documentConfiguration);
        mongoTemplate.remove(documentConfiguration);
    }
}
