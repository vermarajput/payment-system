package com.gbst.digital;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 4/10/2017
 */
public final class Services {
    public final static String DigitalQuotes = "digital-quotes";
    public final static String CBIS = "cbis";
    public final static String COMPOSER = "composer";
    public final static String STORAGE ="storage";
}
