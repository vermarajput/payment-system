package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.document.types.TradeTypeEnum;

import java.util.List;

/**
 * Created by Cecily on 28/03/2018
 */
public class Trade {

    private TradeTypeEnum tradeType;
    private String cashReservePurpose;

    private SellInvestments sellInvestments;
    private List<BuyInvestments> buyInvestments;

    public TradeTypeEnum getTradeType() {
        return tradeType;
    }

    public void setTradeType(TradeTypeEnum tradeType) {
        this.tradeType = tradeType;
    }

    public String getCashReservePurpose() {
        return cashReservePurpose;
    }

    public void setCashReservePurpose(String cashReservePurpose) {
        this.cashReservePurpose = cashReservePurpose;
    }

    @JsonFilter("serializeAll")
    public SellInvestments getSellInvestments() {
        return sellInvestments;
    }

    public void setSellInvestments(SellInvestments sellInvestments) {
        this.sellInvestments = sellInvestments;
    }

    @JsonFilter("serializeAll")
    public List<BuyInvestments> getBuyInvestments() {
        return buyInvestments;
    }

    public void setBuyInvestments(List<BuyInvestments> buyInvestments) {
        this.buyInvestments = buyInvestments;
    }
}
