package com.gbst.digital.documents.resource.model.document;

import com.gbst.digital.documents.resource.model.document.types.IsaTransferTypeEnum;

public class IsaTransferIn extends TransferIn{

    private String currentYearContributions;
    private IsaTransferTypeEnum transferType;

    public IsaTransferIn(){
    }

    public String getCurrentYearContributions() {
        return currentYearContributions;
    }

    public void setCurrentYearContributions(String currentYearContributions) {
        this.currentYearContributions = currentYearContributions;
    }

    public IsaTransferTypeEnum getTransferType() {
        return transferType;
    }

    public void setTransferType(IsaTransferTypeEnum transferType) {
        this.transferType = transferType;
    }
}
