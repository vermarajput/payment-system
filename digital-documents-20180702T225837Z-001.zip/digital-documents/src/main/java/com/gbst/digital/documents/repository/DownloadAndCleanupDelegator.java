package com.gbst.digital.documents.repository;

/**
 * @author nehas
 */

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.DocumentStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.naming.OperationNotSupportedException;
import java.io.File;
import java.util.List;

@Service
public class DownloadAndCleanupDelegator {

    @Autowired
    private List<DocumentStorage> documentStorages;

    /**
     * Method to download the file from the storage
     *
     * @param storagePath
     * @param storageSystem
     * @return
     */
    public File downloadDocumentsFromStorageSystems(String storagePath, String storageSystem) throws DocumentStorageException {
        DocumentStorage documentStorage = getDocumentStorage(storageSystem);
        return documentStorage.downloadFile(storagePath);
    }


    /**
     * Method to cleanup/delete the file from the storage
     *
     * @param storagePath
     * @param storageSystem
     * @return
     */
    public void removeDocumentsFromStorageSystems(String storagePath, String storageSystem) throws DocumentStorageException {
        DocumentStorage documentStorage = getDocumentStorage(storageSystem);
        documentStorage.removeFileFromStorage(storagePath);
    }

    /**
     * Get the document storage
     * @param storageSystem
     * @return
     * @throws DocumentStorageException
     */
    private DocumentStorage getDocumentStorage(String storageSystem) throws DocumentStorageException {
        return documentStorages.stream() // Assumption only one storage type per document per storage system
                    .filter(storage -> storage.supportsStorageType(storageSystem))
                    .findFirst()
                    .orElseThrow(() -> new DocumentStorageException("No document storage found for storage system: " + storageSystem));
    }

    public void setDocumentStorages(List<DocumentStorage> documentStorages) {
        this.documentStorages = documentStorages;
    }
}
