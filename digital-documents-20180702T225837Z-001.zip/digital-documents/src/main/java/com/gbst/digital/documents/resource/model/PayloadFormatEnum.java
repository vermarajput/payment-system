package com.gbst.digital.documents.resource.model;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */
public enum PayloadFormatEnum {
    JSON,
    XML,
    PlainText,
    CommaSeparated
}
