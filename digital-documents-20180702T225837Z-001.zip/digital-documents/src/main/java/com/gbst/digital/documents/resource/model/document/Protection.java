package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * @author nehas
 */
public class Protection {

    private PrimaryProtection primaryProtection;
    private EnhancedProtection enhancedProtection;
    private IndividualProtection individualProtection;
    private FixedProtection fixedProtection;
    private OtherProtection otherProtection;

    @JsonFilter("serializeAll")
    public PrimaryProtection getPrimaryProtection() {
        return primaryProtection;
    }

    public void setPrimaryProtection(PrimaryProtection primaryProtection) {
        this.primaryProtection = primaryProtection;
    }

    @JsonFilter("serializeAll")
    public EnhancedProtection getEnhancedProtection() {
        return enhancedProtection;
    }

    public void setEnhancedProtection(EnhancedProtection enhancedProtection) {
        this.enhancedProtection = enhancedProtection;
    }

    @JsonFilter("serializeAll")
    public IndividualProtection getIndividualProtection() {
        return individualProtection;
    }

    public void setIndividualProtection(IndividualProtection individualProtection) {
        this.individualProtection = individualProtection;
    }

    @JsonFilter("serializeAll")
    public FixedProtection getFixedProtection() {
        return fixedProtection;
    }

    public void setFixedProtection(FixedProtection fixedProtection) {
        this.fixedProtection = fixedProtection;
    }

    @JsonFilter("serializeAll")
    public OtherProtection getOtherProtection() {
        return otherProtection;
    }

    public void setOtherProtection(OtherProtection otherProtection) {
        this.otherProtection = otherProtection;
    }
}
