package com.gbst.digital.documents.repository;

/**
 * Created by Aman Verma on 31/10/2017.
 */

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.DocumentStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DocumentStorageDelegator {

    @Autowired
    private List<DocumentStorage> documentStorages;

    /**
     * @param listOfDocumentWithParameters
     * @return
     */
    public List<DocumentWithParameter> storeDocumentsInRespectiveStorageSystems(List<DocumentWithParameter> listOfDocumentWithParameters) {
        List<DocumentWithParameter> listOfDocumentWithParameterResponse = new ArrayList<>();

        if (!CollectionUtils.isEmpty(listOfDocumentWithParameters)) {
            listOfDocumentWithParameterResponse.addAll(loadStaticOrDocumentsFailedInGeneration(listOfDocumentWithParameters));
            listOfDocumentWithParameterResponse.addAll(loadNonStaticDocuments(listOfDocumentWithParameters));
        }

        return listOfDocumentWithParameterResponse;
    }

    private List<DocumentWithParameter> loadStaticOrDocumentsFailedInGeneration(List<DocumentWithParameter> listOfDocumentWithParameters) {
        return listOfDocumentWithParameters.stream()
                .filter(documentWithParameter -> documentWithParameter.getDocument().getGenerationStatus().equals(GenerationStatusEnum.GENERATION_FAILED)
                        || documentWithParameter.getDocument().getGenerationStrategy().equals(GenerationStrategyEnum.STATIC.getValue()))
                .collect(Collectors.toList());
    }

    private List<DocumentWithParameter> loadNonStaticDocuments(List<DocumentWithParameter> listOfDocumentWithParameters) {
        List<DocumentWithParameter> listOfDocumentWithParameterNoStaticDocs = new ArrayList<>();
        Map<String, List<DocumentWithParameter>> documentWithParametersPerStorageSystem = listOfDocumentWithParameters.stream()
                .filter(documentWithParameter -> documentWithParameter.getDocument().getGenerationStatus().equals(GenerationStatusEnum.GENERATED)
                        && !documentWithParameter.getDocument().getGenerationStrategy().equals(GenerationStrategyEnum.STATIC.getValue()))
                .collect(Collectors.groupingBy(documentWithParameter -> documentWithParameter.getDocument().getStorageSystem()));

        for (String storageSystem : documentWithParametersPerStorageSystem.keySet()) {
            try {
                DocumentStorage documentStorage = documentStorages.stream() // Assumption only one storage type per document per storage system
                        .filter(storage -> storage.supportsStorageType(storageSystem))
                        .findFirst()
                        .orElseThrow(() -> new DocumentStorageException("No document storage found for storage system: " + storageSystem));

                listOfDocumentWithParameterNoStaticDocs.addAll(documentStorage.storeMultipleDocuments(documentWithParametersPerStorageSystem.get(storageSystem)));

            } catch (DocumentStorageException e) {
                for (DocumentWithParameter failedStorageDocs : documentWithParametersPerStorageSystem.get(storageSystem)) {
                    failedStorageDocs.getDocument().setGeneratedDate(null);
                    failedStorageDocs.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
                    failedStorageDocs.getDocument().setStatusMessage("Storage failed to store the document");
                    listOfDocumentWithParameterNoStaticDocs.add(failedStorageDocs);
                }
            }
        }
        return listOfDocumentWithParameterNoStaticDocs;
    }
}
