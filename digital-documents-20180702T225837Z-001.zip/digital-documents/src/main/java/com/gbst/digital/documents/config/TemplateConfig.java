package com.gbst.digital.documents.config;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;

/**
 * @author rekhar on 18/10/2017
 */
@Configuration
public class TemplateConfig {

    private static final Logger LOG = LoggerFactory.getLogger(TemplateConfig.class);

    @Value("${gbst.digital.filesystem.root.path.prefix}")
    private String fileSystemRootPath;

    @Value("${gbst.digital.documents.generation.template.location}")
    private String templateLocation;

    private String getTemplateRootPath() {
        String workingDirectory = System.getProperty("user.dir");
        if (!StringUtils.isEmpty(fileSystemRootPath)) {
            workingDirectory = fileSystemRootPath;
        }
        return workingDirectory + File.separator + templateLocation;
    }

    @Bean(name = "templateLocation")
    public String getTemplateLocation() {
        String templateLocationParentFolderPath = getTemplateRootPath();
        File directory = new File(templateLocationParentFolderPath);
        try {
            if (!directory.exists()) {
                FileUtils.forceMkdir(directory);
            }
        } catch (IOException e) {
            LOG.error("Failed to create parent template directory at path - " + templateLocationParentFolderPath);
        }
        return templateLocationParentFolderPath;
    }
}
