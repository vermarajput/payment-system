package com.gbst.digital.documents.storage.util;

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import org.apache.commons.io.FileUtils;
import org.owasp.esapi.SafeFile;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.*;
import java.time.LocalDate;

/**
 * @author nehas
 */
@Component
public class FileSystemStorageUtil {

    private static final Logger LOG = LoggerFactory.getLogger(FileSystemStorageUtil.class);

    private String documentFolderRootPath;

    public String getDocumentFolderRootPath() {
        return documentFolderRootPath;
    }

    public void setDocumentFolderRootPath(String documentFolderRootPath) {
        this.documentFolderRootPath = documentFolderRootPath;
    }

    public DocumentWithParameter performDocumentUploadOperation(DocumentWithParameter documentWithParameter) throws DocumentStorageException {
        String fileStorageFullPath = "";
        if (null != documentWithParameter) {
            // validate inputs based on operation
            validateStorageOperation(documentWithParameter);

            fileStorageFullPath = computeFilePath(documentWithParameter, true);

            uploadDocumentInFileSystem(documentWithParameter, fileStorageFullPath);
        }
        documentWithParameter.getDocument().setUrl(fileStorageFullPath);
        return documentWithParameter;
    }

    public File performDocumentDownloadOperation(String filePathInFileSystem) throws DocumentStorageException {
        try {
            return  new SafeFile(filePathInFileSystem);
        } catch (ValidationException e) {
            LOG.error("Invalid file path: " + e.getMessage());
            throw new DocumentStorageException("Invalid file path: " + filePathInFileSystem);
        }
    }

    /**
     * method to compute the actual file path in the file system
     *
     * @param documentWithParameter
     * @return complete file path with name and extension
     */
    public String computeFilePath(DocumentWithParameter documentWithParameter, Boolean isFullPath) {
        StringBuilder filePath = new StringBuilder();
        if (isFullPath) {
            filePath = new StringBuilder(this.documentFolderRootPath);
        }
        if (null != documentWithParameter) {
            filePath.append(File.separator)
                    .append(LocalDate.now()).append(File.separator)
                    .append(documentWithParameter.getProcessType()).append(File.separator)
                    .append(documentWithParameter.getProcessTypeId()).append(File.separator)
                    .append(documentWithParameter.getProcessStage()).append(File.separator)
                    .append(documentWithParameter.getRole()).append(File.separator)
                    .append(documentWithParameter.getProcessId()).append(File.separator)
                    .append(documentWithParameter.getDocument().getDocumentName() + documentWithParameter.getDocument().getGeneratedDate().hashCode()).append(".")
                    .append(documentWithParameter.getDocument().getOutputType().getValue());
        }
        LOG.info("Computed file Path = " + filePath);
        return filePath.toString();
    }

    /**
     * Method to delete the file from the path
     * @param storagePath
     */
    public void removeFile(String storagePath) throws DocumentStorageException {
        try {
            File file = new SafeFile(storagePath);
            if(file.exists() && file.isFile()) {
                file.delete();
            }
        } catch (ValidationException e) {
            LOG.error("Invalid file path: " + e.getMessage());
            throw new DocumentStorageException("Invalid file path: " + storagePath);
        }
    }

    /**
     * Method to upload the file from the file system
     *
     * @param documentWithParameter
     */
    private void uploadDocumentInFileSystem(DocumentWithParameter documentWithParameter, String fileStoragePath) throws DocumentStorageException {
        try {
            ByteArrayOutputStream outputStream = (ByteArrayOutputStream) documentWithParameter.getGeneratedDocumentStream();
            InputStream initialStream = new ByteArrayInputStream(outputStream.toByteArray());
            File targetFile = new File(fileStoragePath);
            FileUtils.copyInputStreamToFile(initialStream, targetFile);
        } catch (IOException ioException) {
            throw new DocumentStorageException(ioException.getMessage());
        }
    }

    /**
     * Validation method to check various inputs based on storage Operation requested
     *
     * @param documentWithParameter
     * @throws DocumentStorageException
     */
    private void validateStorageOperation(DocumentWithParameter documentWithParameter) throws DocumentStorageException {
        StringBuilder validationErrors = new StringBuilder();

        if (null == documentWithParameter) {
            LOG.error("-Error: Document Storage request is not provided.");
            validationErrors.append("-Error: Document Storage request is not provided.");
        } else {
            // For Upload, Download and Exists file operation :  party type, party id and quote id is require to determine the path of the file in the filesytem
            if (null != documentWithParameter) {
                if (StringUtils.isEmpty(documentWithParameter.getProcessType())) {
                    LOG.error("-Error: Party type input is missing.");
                    validationErrors.append("-Error: Party type input is missing.");
                } else if (StringUtils.isEmpty(documentWithParameter.getProcessTypeId())) {
                    LOG.error("-Error: Party Id input is missing.");
                    validationErrors.append("-Error: Party Id input is missing.");
                } else if (StringUtils.isEmpty(documentWithParameter.getProcessId())) {
                    LOG.error("-Error: Quote Id input is missing");
                    validationErrors.append("-Error: Quote Id input is missing.");
                }
            }

            // For Upload, Download and Exists file operation :  title , mime type mandatory to determine the file in the filesytem
            if (StringUtils.isEmpty(documentWithParameter.getDocument().getDocumentName()) || StringUtils.isEmpty(documentWithParameter.getDocument().getOutputType())) {
                LOG.error("-Error: document title or  document type is not provided.");
                validationErrors.append("-Error: document title or document type is not provided.");
            }


            if (null == documentWithParameter.getGeneratedDocumentStream()) {
                LOG.error("-Error: Document to upload is missing.");
                validationErrors.append("-Error: Document to upload is missing.");
            }

        }
        if (!StringUtils.isEmpty(validationErrors.toString())) {
            throw new DocumentStorageException(validationErrors.toString());
        }
    }

}
