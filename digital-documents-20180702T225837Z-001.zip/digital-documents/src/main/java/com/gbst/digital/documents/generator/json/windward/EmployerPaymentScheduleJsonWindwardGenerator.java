package com.gbst.digital.documents.generator.json.windward;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.document.types.ContributorTypeEnum;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */
@ConditionalOnProperty(value = "gbst.digital.documents.types.employerPaymentSchedule", havingValue = "Windward")
@Service
public class EmployerPaymentScheduleJsonWindwardGenerator extends AbstractWindwardDocumentGenerator implements DocumentGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(EmployerPaymentScheduleJsonWindwardGenerator.class);
    private static final String CONTRIBUTOR_TYPE = "/contributorType";
    private static final String REGULAR_CONTRIBUTIONS_ATTR = "/regularContributions";
    
    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {
        if(!payload.isJson()) {
            LOG.debug("Not a JSON payload");
            return false;
        }
        DocumentForConfig config = payload.getDocumentForConfig();
        if(!GenerationStrategyEnum.WINDWARD.getValue().equals(String.valueOf(config.getGenerationStrategy()))) {
            LOG.debug("Document generation strategy [" + config.getGenerationStrategy() + "] should be WINDWARD.");
            return false;
        }

        return config.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.EMPLOYER_PAYMENT_SCHEDULE.name()) &&    //Employer Record of payments due
            isValidEmployerPaymentSchedule(payload.getPayloadAsJsonNode());
    }

    @Override
    public void validate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        //no business validation
    }

    @Override
    public List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        return super.generateFromJsonPayload(document, payload);
    }


    // if the journey jsonNodeAttributes has a regular contribution with contributor type "Employer" defined
    private boolean isValidEmployerPaymentSchedule(JsonNode jsonNodeAttributes) {
        //has a regular contribution with contributor type "Employer"
        if (jsonNodeAttributes.at(REGULAR_CONTRIBUTIONS_ATTR) != null && jsonNodeAttributes.at(REGULAR_CONTRIBUTIONS_ATTR).isArray()) {
            ArrayNode regContri = (ArrayNode) jsonNodeAttributes.at(REGULAR_CONTRIBUTIONS_ATTR);
            for (JsonNode node : regContri) {
                if (node.at(CONTRIBUTOR_TYPE) != null && node.at(CONTRIBUTOR_TYPE).asText().equalsIgnoreCase(ContributorTypeEnum.Employer.getValue())) {
                    return true;
                }
            }
        }

        return false;
    }
}
