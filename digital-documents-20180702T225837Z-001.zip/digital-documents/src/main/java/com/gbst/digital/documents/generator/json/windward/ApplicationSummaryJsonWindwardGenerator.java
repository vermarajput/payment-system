package com.gbst.digital.documents.generator.json.windward;

import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */

@ConditionalOnProperty(value = "gbst.digital.documents.types.applicationSummary", havingValue = "Windward")
@Service
public class ApplicationSummaryJsonWindwardGenerator extends AbstractWindwardDocumentGenerator implements DocumentGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(ApplicationSummaryJsonWindwardGenerator.class);

    
    @Override
    public boolean supports(BaseDocumentGeneration documentGeneration, DocumentPayload payload) {
        if(!payload.isJson()) {
            LOG.debug("Not a JSON payload");
            return false;
        }
        DocumentForConfig document = payload.getDocumentForConfig();

        if(!GenerationStrategyEnum.WINDWARD.getValue().equals(String.valueOf(document.getGenerationStrategy()))) {
            LOG.debug("Document generation strategy [" + document.getGenerationStrategy() + "] should be WINDWARD.");
            return false;
        }

        //Application Summary
        if (Arrays.asList( // Ignoring others which have already been handled by other Validators
                DocumentTypeEnum.SIPP_APPLICATION_SUMMARY.name(),
                DocumentTypeEnum.ISA_APPLICATION_SUMMARY.name(),
                DocumentTypeEnum.GIA_APPLICATION_SUMMARY.name(),
                DocumentTypeEnum.SWITCH_APPLICATION_SUMMARY.name(),
                DocumentTypeEnum.REREG_APPLICATION_SUMMARY.name()
        ).contains(document.getDocumentName())) {
            return true;
        }

        return false;
    }

    @Override
    public void validate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        //no business validation
    }

    @Override
    public List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        return super.generateFromJsonPayload(document, payload);
    }



}
