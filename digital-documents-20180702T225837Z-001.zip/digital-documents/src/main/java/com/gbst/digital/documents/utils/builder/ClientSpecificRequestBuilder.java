package com.gbst.digital.documents.utils.builder;

import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.utils.IllustrationSelectorEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.request.RequestIllustrationType;

/**
 * Created by Aman Verma on 1/03/2018.
 */

public interface ClientSpecificRequestBuilder {
    void enrichRequest(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType productType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA);
}
