package com.gbst.digital.documents.resource.model.document;


import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.document.types.SellByEnum;

import java.util.List;

/**
 * Created by Cecily on 28/03/2018
 */
public class SellInvestments {

    private SellByEnum sellBy;
    private List<SellDetails> sellDetails;

    public SellByEnum getSellBy() {
        return sellBy;
    }

    public void setSellBy(SellByEnum sellBy) {
        this.sellBy = sellBy;
    }

    @JsonFilter("serializeAll")
    public List<SellDetails> getSellDetails() {
        return sellDetails;
    }

    public void setSellDetails(List<SellDetails> sellDetails) {
        this.sellDetails = sellDetails;
    }
}
