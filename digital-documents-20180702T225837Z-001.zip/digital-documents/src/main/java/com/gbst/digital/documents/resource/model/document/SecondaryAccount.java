package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.math.BigDecimal;

/**
 * @author Jonathan Bildan and Rekha Ramachandran    25/10/2017
 */

public class SecondaryAccount {

    private BigDecimal ongoingAdviserChargeAmount;
    private BigDecimal ongoingAdviserChargePercent;
    private String ongoingAdviserChargeFrequency;
    private InvestmentStrategy investmentStrategy;
    private String productTypeId;

    public BigDecimal getOngoingAdviserChargeAmount() {
        return ongoingAdviserChargeAmount;
    }

    public void setOngoingAdviserChargeAmount(BigDecimal ongoingAdviserChargeAmount) {
        this.ongoingAdviserChargeAmount = ongoingAdviserChargeAmount;
    }

    public BigDecimal getOngoingAdviserChargePercent() {
        return ongoingAdviserChargePercent;
    }

    public void setOngoingAdviserChargePercent(BigDecimal ongoingAdviserChargePercent) {
        this.ongoingAdviserChargePercent = ongoingAdviserChargePercent;
    }

    public String getOngoingAdviserChargeFrequency() {
        return ongoingAdviserChargeFrequency;
    }

    public void setOngoingAdviserChargeFrequency(String ongoingAdviserChargeFrequency) {
        this.ongoingAdviserChargeFrequency = ongoingAdviserChargeFrequency;
    }

    public String getProductTypeId() {
        return productTypeId;
    }

    public void setProductTypeId(String productTypeId) {
        this.productTypeId = productTypeId;
    }


    @JsonFilter("serializeAll")
    public InvestmentStrategy getInvestmentStrategy() {
        return investmentStrategy;
    }

    public void setInvestmentStrategy(InvestmentStrategy investmentStrategy) {
        this.investmentStrategy = investmentStrategy;
    }
}
