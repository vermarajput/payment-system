package com.gbst.digital.documents.security.composer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.AbstractPermissions;
import com.gbst.common.auth.perms.ConditionalOnPermissionProvider;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.PermissionProviderEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.common.jsonapi.Nilable;
import com.gbst.common.party.PartyTypeEnum;
import com.gbst.common.party.PartyTypeSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.services.composer.PartyTypeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 6/02/2018
 */
@Service
@Profile("permissions")
@ConditionalOnPermissionProvider(PermissionProviderEnum.Composer)
public class DocumentAttributesPermissions extends AbstractPermissions<DocumentPayload, OperationEnum> implements Permissions<DocumentPayload, OperationEnum> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentAttributesPermissions.class);
    
    @Autowired
    ObjectMapper mapper;

    @Autowired
    PartyTypeService partyTypeService;

    @Autowired
    PartyTypeSettings partyTypeSettings;

    /**
     * <p>
     * Checks if requested (or new) document has investor id or investor account id associated with the requester.
     * If not, the requester is trying to access (or create) documents that don't belong to them.
     * </p>
     * <p>
     * If no investor id or investor account id is provided, no check is required.
     * </p>
     *
     */
    @Override
    public void check(OperationEnum type, DocumentPayload resource) throws GbstJsonApiAccessDeniedException {

        if(!resource.isJson()) {
            // We need to add other formats like xml in here in this class if we want to support it
            return;
        }

        JsonNode attr = resource.getPayloadAsJsonNode();

        JsonMessage message = new JsonMessage(attr);

        GbstPrincipal principal = authenticationFacade.getPrincipal();

        Integer partyId = Integer.parseInt(principal.getGbstPartyId());
        Integer partyTypeId = partyTypeSettings.getValueAsInteger(Services.COMPOSER, PartyTypeEnum.valueOf(principal.getGbstPartyType()));

        Nilable<String> investorAccount = message.with("/investorAccountId").ofType(String.class).get();
        Nilable<String> investorId = message.with("/investorId").ofType(String.class).get();
        String searchPartyId = investorAccount.isProvidedAndNotNull() ? investorAccount.getValue() : investorId.safeGetValue();

        // if no investor id or investor account id is provided, no check is required.
        if(searchPartyId != null) {
            Integer associatedPartyType = investorAccount.isProvidedAndNotNull()
                    ? partyTypeSettings.getValueAsInteger("composer", PartyTypeEnum.InvestorAccount)
                    : partyTypeSettings.getValueAsInteger("composer", PartyTypeEnum.Investor);
            if(!partyTypeService.isPartyAssociated(partyId, partyTypeId, associatedPartyType, searchPartyId)) {
                throw new GbstJsonApiAccessDeniedException("document-generation", principal.getGbstPartyId());
            }
        }
    }
}
