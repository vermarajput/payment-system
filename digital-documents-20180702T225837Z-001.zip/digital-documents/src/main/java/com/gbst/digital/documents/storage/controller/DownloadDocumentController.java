package com.gbst.digital.documents.storage.controller;

import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.exception.ServletRunTimeException;
import com.gbst.digital.documents.repository.DocumentGenerationJsonApiRepository;
import com.gbst.digital.documents.repository.DownloadAndCleanupDelegator;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.storage.util.FileSystemStorageUtil;
import org.owasp.esapi.HTTPUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.apache.commons.lang3.StringEscapeUtils.escapeJava;
import static org.owasp.esapi.ESAPI.encoder;

@RestController()
public class DownloadDocumentController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DownloadDocumentController.class);
    private static final String UNDERSCORE = "_";
    private static final String CONTENT_TYPE = "application/zip";
    private static final String EXT_ZIP = ".zip";
    private SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private DownloadAndCleanupDelegator downloadAndCleanupDelegator;

    @Autowired
    private FileSystemStorageUtil fileSystemStorageUtil;

    @Autowired
    private DocumentGenerationJsonApiRepository documentGenerationJsonApiRepository;

    @Autowired
    Permissions<DocumentGeneration, OperationEnum> documentGenerationPermissions;

    @Autowired
    private HTTPUtilities httpUtilities;

    @GetMapping("/files/document-download/{documentKey}")
    public void download(HttpServletRequest request,
                         HttpServletResponse response,
                         @PathVariable String documentKey) throws ServletException, IOException {

        DocumentForGeneration docResponse = validateDownloadRequest(documentKey);

        String storagePath = docResponse.getUrl();
        String storageType = docResponse.getStorageSystem();

        File downloadFile = null;
        try {
            downloadFile = downloadAndCleanupDelegator.downloadDocumentsFromStorageSystems(storagePath, storageType);
        } catch (DocumentStorageException e) {
            throw new ServletRunTimeException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to download the file from the path - " + storagePath);
        }

        if (null == downloadFile) {
            throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No file found to download from the path - " + storagePath);
        }

        try (FileInputStream inStream = new FileInputStream(downloadFile);
             OutputStream outStream = response.getOutputStream()) {

            // obtains ServletContext
            ServletContext context = request.getServletContext();

            // gets MIME type of the file
            String mimeType = context.getMimeType(storagePath);
            if (mimeType == null) {
                // set to binary type if MIME mapping not found
                mimeType = "application/octet-stream";
            }

            String headerValue = String.format("attachment; filename=%s", downloadFile.getName());
            enrichHttpHeader(mimeType, headerValue, String.valueOf(downloadFile.length()), request, response);

            byte[] buffer = new byte[4096];
            int bytesRead = -1;

            while ((bytesRead = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
            buffer = null;
        }
    }

    private DocumentForGeneration validateDownloadRequest(String docKey) throws ServletException {
        if (null == docKey) {
            throw new ServletRunTimeException(HttpStatus.PRECONDITION_FAILED, "No documentKey provided in the input to download the file.");
        }

        //fetch the document response to download the file
        DocumentGeneration documentGeneration = findOneDocGenObject(docKey);

        if (null != documentGeneration) {

            // check access
            documentGenerationPermissions.check(OperationEnum.FindOne, documentGeneration);

            // find matching document response post validations/checks
            DocumentForGeneration docResponse = findDocumentResponseByKey(documentGeneration, docKey);

            if (null != docResponse) {

                if (docResponse.getGenerationStatus().equals(GenerationStatusEnum.GENERATION_FAILED)) {
                    throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No document found to download. Document Generation was not successful.");
                }

                // for static ..will not download
                if (docResponse.getGenerationStrategy().equals(GenerationStrategyEnum.STATIC.getValue())) {
                    throw new ServletRunTimeException(HttpStatus.NOT_ACCEPTABLE, "Document download for Static documents is not allowed.");
                }

                return docResponse;

            } else {
                throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No Document found linked to the key.");
            }
        } else {
            throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No Document information found in the DB.");
        }
    }

    private DocumentForGeneration findDocumentResponseByKey(DocumentGeneration documentGeneration, String docKey) {
        if (!CollectionUtils.isEmpty(documentGeneration.getDocuments())) {
            return documentGeneration.getDocuments().stream()
                    .filter(docRes -> (docRes != null && docKey.equalsIgnoreCase(docRes.getDocumentKey())))
                    .findFirst().get();
        }
        return null;
    }

    private DocumentGeneration findOneDocGenObject(String key) {
        Criteria findDocResponseCriteria = Criteria.where("documents").elemMatch(Criteria.where("documentKey").is(key));
        BasicQuery basicQuery = new BasicQuery(findDocResponseCriteria.getCriteriaObject());
        return mongoTemplate.findOne(basicQuery, DocumentGeneration.class);
    }

    @GetMapping(value = "/files/download-zip/{documentGenerationId}")
    public void downloadZip(HttpServletRequest request, HttpServletResponse response, @PathVariable String documentGenerationId) throws ServletException, IOException {

        if (null == documentGenerationId) {
            // Throw exception when no document generation id is null..
            throw new ServletRunTimeException(HttpStatus.PRECONDITION_FAILED, "No document generation id is provided to download the file.");
        }

        // Fetch Document Generation object for the provided id..
        DocumentGeneration documentGeneration = documentGenerationJsonApiRepository.findOne(documentGenerationId, null);

        if (null != documentGeneration) {
            // check access
            documentGenerationPermissions.check(OperationEnum.FindOne, documentGeneration);

            StringBuffer zipFileName = new StringBuffer();
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
                 ZipOutputStream zip = new ZipOutputStream(bos)) {

                zipFileName.append(documentGeneration.getProcessId()).append(UNDERSCORE).append(sdf.format(new Date())).append(EXT_ZIP);

                zip.setLevel(Deflater.DEFAULT_COMPRESSION);

                if (null != documentGeneration.getDocuments() && documentGeneration.getDocuments().size() > 0) {
                    // Loop through the docs
                    for (DocumentForGeneration document : documentGeneration.getDocuments()) {

                        if (document.getGenerationStatus().equals(GenerationStatusEnum.GENERATED) && null != document.getUrl()) {
                            File downloadFile = null;
                            try {
                                downloadFile = fileSystemStorageUtil.performDocumentDownloadOperation(document.getUrl());
                            } catch (DocumentStorageException e) {
                                // If download fails, throw an exception..

                                LOGGER.error(encoder().encodeForHTML("Failed to download the file from the path: " + document.getUrl()));
                                throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "Failed to download the file from the path.");
                            }

                            if (null != downloadFile) {
                                zip.putNextEntry(new ZipEntry(document.getDocumentName() + "." + document.getOutputType()));
                                byte[] buffer = new byte[4 * 1024];
                                int len;
                                try (FileInputStream inStream = new FileInputStream(downloadFile)) {
                                    while ((len = inStream.read(buffer)) >= 0) {
                                        zip.write(buffer, 0, len);
                                    }
                                }
                                zip.closeEntry();
                                buffer = null;
                            } else {
                                LOGGER.error(encoder().encodeForHTML("No file found to download from the path - "  + document.getUrl()));
                                throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No file found to download from the path.");
                            }
                        }
                    }
                } else {
                    throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No documents were found linked to the generation id.");
                }

                // Throw exception when there are no documents downloaded..
                if (bos.size() == 0) {
                    throw new ServletRunTimeException(HttpStatus.NOT_FOUND, "No documents were downloaded.");
                }

                zip.flush();
                zip.close();

                sendZipFileToResponse(bos, zipFileName.toString(), request, response);
            }
        }
    }

    /**
     * send the zip file to the browser for download.
     *
     * @param zipBytes - the byte array zip
     * @param request
     * @param response - servlet response
     */
    private void sendZipFileToResponse(ByteArrayOutputStream zipBytes, String zipFileName, HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (zipBytes != null) {
            String headerValue = "attachment; filename=" + escapeJava(zipFileName);
            enrichHttpHeader(CONTENT_TYPE, headerValue, String.valueOf(zipBytes.size()), request, response);

            try (OutputStream out = response.getOutputStream()) {
                zipBytes.writeTo(out);
            } catch (IOException e) {
                throw new ServletRunTimeException(HttpStatus.NO_CONTENT, "Cannot create zip file");
            }
        }
    }

    /**
     * Creates safe and sanitized https headers and enriches response
     *
     * @param contentType
     * @param contentDisposition
     * @param fileLength //String value
     * @param request
     * @param response
     */
    private void enrichHttpHeader(String contentType, String contentDisposition, String fileLength, HttpServletRequest request, HttpServletResponse response) {
        httpUtilities.setCurrentHTTP(request, response);
        httpUtilities.addHeader("Content-Type", contentType);
        httpUtilities.addHeader("Content-Length", fileLength);
        httpUtilities.addHeader("Content-Disposition", contentDisposition);
    }
}
