package com.gbst.digital.documents.config;

import com.mongodb.MongoClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * @author rekhar on 19/09/2017
 */
@Configuration
public class MongoConfig {

    @Value("${mongo.client.hostname}")
    private String host;

    @Value("${mongo.client.port}")
    private int port;

    @Value("${mongo.client.database}")
    private String database;

    public @Bean(name="mongoTemplate")
    MongoTemplate mongoTemplate() throws Exception {

        MongoTemplate mongoTemplate =
                new MongoTemplate(new MongoClient(host, port),database);
        return mongoTemplate;
    }
}
