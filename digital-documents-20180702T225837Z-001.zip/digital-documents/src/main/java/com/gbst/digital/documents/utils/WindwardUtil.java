package com.gbst.digital.documents.utils;

import net.windward.datasource.DataSourceProvider;
import net.windward.datasource.json.JsonDataSource;
import net.windward.xmlreport.ProcessPdf;
import net.windward.xmlreport.ProcessReportAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.naming.OperationNotSupportedException;
import java.io.*;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 12/03/2018
 */
//@Profile("windward")
@Service
public class WindwardUtil {

    private static final Logger LOG = LoggerFactory.getLogger(WindwardUtil.class);

    @Autowired
    @Qualifier("templateLocation")
    protected String templateLocation;

    public OutputStream generate(String payload, String outputType, String payloadType, String templateName) {

        LOG.debug("Template Location ::: {}", templateLocation);
        File file = new File(templateLocation + File.separator + templateName);
        try (ByteArrayOutputStream outByte = new ByteArrayOutputStream();
             InputStream in = new ByteArrayInputStream((payload).getBytes("UTF-8"));
             FileInputStream templateStream = new FileInputStream(file)) {
            ProcessReportAPI report = null;

            // Set up the datasource...
            DataSourceProvider datasource = null;
            if (payloadType.equalsIgnoreCase("json")) {
                datasource = new JsonDataSource(in, "utf-8");
            } else {
                throw new OperationNotSupportedException("Payload format is not supported: " + payloadType);
            }

            // Process PDF doc based on the output type...
            if (null != outputType && outputType.equalsIgnoreCase("pdf")) {
                report = new ProcessPdf(templateStream, outByte);
            } else {
                throw new OperationNotSupportedException("Output type is not supported: " + outputType);
            }

            // Preparation...
            report.processSetup();

            // Send it to Windward for processing...
            report.processData(datasource, "documentAttributes"); // Datasource name

            // Completed!!!
            report.processComplete();
            LOG.debug("Windward completed Document Process ");
            return outByte;

        } catch (Exception e) {
            LOG.error("Error in creating windward document", e);
            throw new RuntimeException("Could not complete windward process", e);
        }
    }
}
