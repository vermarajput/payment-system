package com.gbst.digital.documents.exceptionhandler;

import com.gbst.digital.documents.exception.ServletRunTimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletResponse;

import static org.owasp.esapi.ESAPI.encoder;

/**
 * @author nehas
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class ServletExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(ServletExceptionHandler.class);

    @ExceptionHandler({ServletRunTimeException.class})
    public ResponseEntity<String> handleException(ServletRunTimeException e, HttpServletResponse response) {
        if (LOG.isDebugEnabled()) {
            LOG.debug(encoder().encodeForHTML(("ServletExceptionHandler Error: status - " + e.getHttpStatus().toString() + " && message - " + e.getMessage())));
        }

        response.setContentType("application/text");
        return buildResponseEntity(e.getHttpStatus(), e.getMessage());
    }

    private ResponseEntity buildResponseEntity(HttpStatus httpStatus, String message) {
        return ResponseEntity.status(httpStatus).body(message);
    }

    //other exception handlers below
}
