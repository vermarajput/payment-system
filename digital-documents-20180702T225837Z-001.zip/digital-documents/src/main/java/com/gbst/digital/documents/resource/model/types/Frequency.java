package com.gbst.digital.documents.resource.model.types;

import com.gbst.common.data.GBSTEnumable;

import java.math.BigDecimal;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 10/10/2017
 */

public enum Frequency implements GBSTEnumable<String> {
	Annually("A", 1),
	HalfYearly("H", 2),
	Quarterly("Q", 4),
	Monthly("M", 12),
	Fortnightly("F", 24),
	Weekly("W", 48),
	Daily("InAdvance", 365),
	None("N", 0);

	private String shortCode;
	private BigDecimal annualFactor;
	
	/**
	 * Constructor.
	 * @param shortCode code
	 * @param annualizeFactor factor
	 */
	private Frequency(String shortCode, int annualizeFactor) {
		this.shortCode = shortCode;
		this.annualFactor = new BigDecimal(annualizeFactor);
	}
	
	@Override
	public String getValue() {
		return shortCode;
	}

	@Override
	public Enum getEnumFromValue(String value) {
		return null;
	}

	/**
	 * 
	 * @return frequency string.
	 */
	public String getDescription(){
		switch(this){
		case Monthly:     return "Monthly";
		case Quarterly:   return "Quarterly";
		case HalfYearly: return "Half Yearly";
		case Annually:    return "Annually";
        case Daily:    return "Daily";
        case Weekly:    return "Weekly";
        case Fortnightly:    return "Fortnightly";
		default:          return "";
		}
	}
	
	/**
	 * Gets the Frequency from short code.
	 * @param shortCode short code.
	 * @return frequency
	 */
	public static Frequency getFrequencyFromShortCode(String shortCode) {
		for(Frequency f : values()) {
			if(f.shortCode.equals(shortCode)) {
				return f;
			}
		}
		
		return null;
	}

	/**
	 *
	 * @param description the description.
	 * @return the frequency.
	 */
    public static Frequency getFrequencyFromDescription(String description){
        for (Frequency f : values()){
            if(f.getDescription().equals(description)){
                return  f;
            }
        }

        return  null;
    }
	
	/**
	 * Returns the short code.
	 * @return short code.
	 */
	public String getShortCode() {
		return this.shortCode;
	}
	
	/**
	 * 
	 * WithdrawalFrequency Enumerations.
	 *
	 */
	public enum WithdrawalFrequency {
		Monthly,
		Quarterly,
		Annually;
		/**
		 * 
		 * @return frequency string
		 */
		public String getDescription(){
			switch(this){
			case Monthly:     return "Monthly";
			case Quarterly:   return "Quarterly";
			case Annually:    return "Annually";
			default:          return "";
			}
		}
	}

	/**
	 * Used for annualizing amounts.
	 * @return factor.
	 */
	public int getAnnualFactor() {
		return annualFactor.intValue();
	}
	
	/**
	 * Used for annualizing amounts.
	 * @return factor.
	 */
	public BigDecimal getAnnualFactorAsBigDecimal() {
		return annualFactor;
	}


    /**
     *
     * RegularContributionFrequency Enumerations only for text display.
     *
     */
    public enum RegularContributionFrequency {
		Daily, Weekly, Fortnightly, Monthly, Quarterly, HalfYearly, Annually;

        /**
         *
         * @return frequency string
         */
        public String getDescription(){
            switch(this){
                case Daily:     return "per day";
                case Weekly:     return "per week";
                case Fortnightly:     return "per fortnight";
                case Monthly:     return "per month";
                case Quarterly:   return "per quarter";
                case HalfYearly:   return "half yearly";
                case Annually:    return "annually";
                default:          return "";
            }
        }
    }
}



