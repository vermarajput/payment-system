package com.gbst.digital.documents.resource.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * @author nehas
 */
@JsonApiResource(type = "list-documents-for-process")
public class DocumentList extends BaseDocumentGeneration<Document> {

    @Id
    @JsonApiId
    private String id;



    // for the return from the service
    private List<Document> documents;

    @JsonFilter("serializeAll")
    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getProcessStage() {
        return processStage;
    }

    public void setProcessStage(String processStage) {
        this.processStage = processStage;
    }

    public String getProcessTypeId() {
        return processTypeId;
    }

    public void setProcessTypeId(String processTypeId) {
        this.processTypeId = processTypeId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocumentAttributes() {
        return documentAttributes;
    }

    public void setDocumentAttributes(String documentAttributes) {
        this.documentAttributes = documentAttributes;
    }
}
