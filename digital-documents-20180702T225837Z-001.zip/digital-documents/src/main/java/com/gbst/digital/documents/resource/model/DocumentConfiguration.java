package com.gbst.digital.documents.resource.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * @author sanjayank    11/08/2017 10:59 AM
 */
@org.springframework.data.mongodb.core.mapping.Document(collection = "document-configuration")
@JsonApiResource(type = "document-configurations")
public class DocumentConfiguration {
    @Id
    @JsonApiId
    private String id;

    private String processType;
    private String processTypeId;
    private String role;
    private String processStage;

    private List<DocumentForConfig> documents;

    public DocumentConfiguration() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public String getProcessTypeId() {
        return processTypeId;
    }

    public void setProcessTypeId(String processTypeId) {
        this.processTypeId = processTypeId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getProcessStage() {
        return processStage;
    }

    public void setProcessStage(String processStage) {
        this.processStage = processStage;
    }

    @JsonFilter("serializeAll")
    public List<DocumentForConfig> getDocuments() {
        return documents;
    }

    public void setDocuments(List<DocumentForConfig> documents) {
        this.documents = documents;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DocumentConfiguration that = (DocumentConfiguration) o;

        if (processType != null ? !processType.equals(that.processType) : that.processType != null) return false;
        if (processTypeId != null ? !processTypeId.equals(that.processTypeId) : that.processTypeId != null) return false;
        if (role != null ? !role.equals(that.role) : that.role != null) return false;
        return processStage != null ? processStage.equals(that.processStage) : that.processStage == null;
    }

    @Override
    public int hashCode() {
        int result = processType != null ? processType.hashCode() : 0;
        result = 31 * result + (processTypeId != null ? processTypeId.hashCode() : 0);
        result = 31 * result + (role != null ? role.hashCode() : 0);
        result = 31 * result + (processStage != null ? processStage.hashCode() : 0);
        return result;
    }
}
