package com.gbst.digital.documents.resource.model.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * Stores the status for final endpoint status
 * @author nehas
 */
public enum GenerationStatusEnum implements GBSTEnumable<String>
{
    GENERATED("GENERATED"),
    GENERATION_FAILED("GENERATION_FAILED"),
    NOT_GENERATED("NOT_GENERATED");

    private String value;

    GenerationStatusEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

}