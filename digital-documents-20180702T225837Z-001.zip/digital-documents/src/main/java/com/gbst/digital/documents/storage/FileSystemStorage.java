package com.gbst.digital.documents.storage;

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.util.FileSystemStorageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

/**
 * @author nehas
 */
@Service
public class FileSystemStorage implements DocumentStorage {

    private static final Logger LOG = LoggerFactory.getLogger(FileSystemStorage.class);

    @Autowired
    FileSystemStorageUtil fileSystemStorageUtil;

    /**
     * @param documentWithParameter         - this contains the generated document and its details as returned by the document generator
     * @return
     * @throws DocumentStorageException
     */
    @Override
    public DocumentWithParameter store(DocumentWithParameter documentWithParameter) throws DocumentStorageException {
        return fileSystemStorageUtil.performDocumentUploadOperation(documentWithParameter);
    }

    @Override
    public List<DocumentWithParameter> storeMultipleDocuments(List<DocumentWithParameter> listOfdocumentWithParameters) {
        for (DocumentWithParameter documentWithParameter : listOfdocumentWithParameters) {
            try {
                this.store(documentWithParameter);
            } catch (DocumentStorageException e) {
                LOG.error(e.getMessage());
                documentWithParameter.getDocument().setGeneratedDate(null);
                documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
                documentWithParameter.getDocument().setStatusMessage("Storage failed to store the document");
            }
        }
        return listOfdocumentWithParameters;
    }

    @Override
    public File downloadFile(String storagePath) throws DocumentStorageException {
        return fileSystemStorageUtil.performDocumentDownloadOperation(storagePath);
    }

    @Override
    public boolean supportsStorageType(String type) {
        return StorageSystemEnum.FILESYSTEM.getValue().equals(String.valueOf(type)) || StorageSystemEnum.CMISDMS.getValue().equals(String.valueOf(type));
    }

    @Override
    public void removeFileFromStorage(String storagePath) throws DocumentStorageException {
        fileSystemStorageUtil.removeFile(storagePath);
    }
}
