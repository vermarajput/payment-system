
package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

public enum AnnuityFreqEnum implements GBSTEnumable<String>
{
    Quarterly("Q", 3),
    Monthly("M", 1),
    Annual("A", 12);

    private String value;
    private Integer monthValue;

    AnnuityFreqEnum(String value, Integer monthValue) {
        this.value = value;
        this.monthValue = monthValue;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

    public Integer getMonthValue() {
        return monthValue;
    }
}
