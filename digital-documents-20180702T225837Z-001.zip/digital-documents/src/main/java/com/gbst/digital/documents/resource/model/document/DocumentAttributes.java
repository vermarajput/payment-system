package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.document.types.AnnuityFreqEnum;
import com.gbst.digital.documents.resource.model.document.types.AnnuityTimingEnum;
import com.gbst.digital.documents.resource.model.document.types.GenderEnum;
import com.gbst.digital.documents.resource.model.document.types.QuoteStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public class DocumentAttributes {

    private String quoteId;
    private QuoteStatus status;
    private String relatedQuoteId;

    // Investor
    private String investorFirstName;
    private String investorLastName;
    private GenderEnum investorGender;
    private String investorEmailAddress;
    private Integer investorExpectedRetirementAge;
    private String policyNumber;
    private Boolean adviceGivenFlag;
    private Boolean existingPolicyFlag;
    private Boolean applyBoostFlag;
    private Integer applyBoostDirectDebitPaymentDay;
    private String owner;
    private String ownerId;
    private String ownerTypeId;
    private String ownerType;
    private String investorId;
    private String investorAccountId;
    private LocalDate investorDateOfBirth;
    private LocalDate dateOfRetirement;
    private Instant dateTimeCreated;
    private Instant dateTimeLastModified;
    private String processType;
    private String lastStep;
    private String productName;
    private String productDisplayName;
    private String isaType;
    private String investorAMLStatus;

    // Adviser
    private String adviserId;
    private String adviserTitle;
    private String adviserFirstName;
    private String adviserLastName;
    private String adviserBranchCompanyName;
    private String adviserNetworkCompanyName;

    // Product type
    private Integer productTypeId;

    // Annuity
    private AnnuityFreqEnum annuityFrequency;
    private AnnuityTimingEnum annuityTiming;
    private BigDecimal annuityGuarantee;
    private BigDecimal annuityEscalation;

    //Third Party
    private String thirdPartySystem;
    private String thirdPartySystemReference;

    // Dependant
    private BigDecimal dependantPensionPercent;
    private GenderEnum dependantGender;
    private LocalDate dependantDateOfBirth;
    private Boolean dependantPersonalisePensionFlag;

    // Ongoing Adviser Charges
    private BigDecimal ongoingAdviserChargeAmount;
    private BigDecimal ongoingAdviserChargePercent;
    private String ongoingAdviserChargeFrequency;

    private Boolean habitualResident;
    private String investorTitle;
    private String investorMobileNumber;
    private String investorHomeNumber;
    private String investorWorkNumber;
    private String investorNationality;
    private String nationalInsuranceNumber;
    private String employmentStatus;

    // Single Contributions
    private List<SingleContribution> singleContributions;

    // Regular Contributions
    private List<RegularContribution> regularContributions;

    private InvestmentStrategy investmentStrategy;

    //Regulatory Application Details
    private ApplicationDetails applicationDetails;

    // Investor Bank Accounts
    private List<BankAccount> investorBankAccounts;

    // Previous BCEs
    private PreviousBCE previousBCE;

    // Crystallisation Details
    private CrystallisationDetails crystallisationDetails;

    // Protection Data
    private Protection protection;

    //Drawdown Income
    private DrawdownIncome drawdownIncome;

    private PolicyPaymentPlan policyPaymentPlan;

    // Secondary Investment Strategy
    private SecondaryAccount secondaryAccount;

    private Boolean applySameInvestmentStrategy;

    // SIPP Transfer In
    private List<SippTransferIn> sippTransferIns;

    // Registered Contact Details
    private RegisteredContact registeredContactDetails;

    // Address
    private Address investorActualAddress;

    // ISA Transfer In
    private List<IsaTransferIn> isaTransferIns;

    //Initial Charge at the Top Level
    private BigDecimal transferInInitialChargeAmount;
    private BigDecimal transferInInitialChargePercent;
    private BigDecimal regularInitialChargeAmount;
    private BigDecimal regularInitialChargePercent;
    private Integer regularInitialChargeTerm;
    private BigDecimal singleInitialChargeAmount;
    private BigDecimal singleInitialChargePercent;

    //Trade
    private Trade trade;

    //Quoted Date
    private Instant quotedDateTime;

    // custom fields
    private List<CustomField> customFields;
    private LocalDate fundStartDate;

    public DocumentAttributes() {
    }

    public DocumentAttributes(QuoteStatus status, String investorFirstName, String investorLastName, LocalDate investorDateOfBirth) {
        this.status = status;
        this.investorFirstName = investorFirstName;
        this.investorLastName = investorLastName;
        this.investorDateOfBirth = investorDateOfBirth;
    }

    public Boolean getApplyBoostFlag() {
        return applyBoostFlag;
    }

    public void setApplyBoostFlag(Boolean applyBoostFlag) {
        this.applyBoostFlag = applyBoostFlag;
    }

    public Integer getApplyBoostDirectDebitPaymentDay() {
        return applyBoostDirectDebitPaymentDay;
    }

    public void setApplyBoostDirectDebitPaymentDay(Integer applyBoostDirectDebitPaymentDay) {
        this.applyBoostDirectDebitPaymentDay = applyBoostDirectDebitPaymentDay;
    }

    public String getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(String quoteId) {
        this.quoteId = quoteId;
    }

    public QuoteStatus getStatus() {
        return status;
    }

    public void setStatus(QuoteStatus status) {
        this.status = status;
    }

    public String getInvestorFirstName() {
        return investorFirstName;
    }

    public void setInvestorFirstName(String investorFirstName) {
        this.investorFirstName = investorFirstName;
    }

    public String getAdviserId() {
        return adviserId;
    }

    public void setAdviserId(String adviserId) {
        this.adviserId = adviserId;
    }

    public String getInvestorLastName() {
        return investorLastName;
    }

    public void setInvestorLastName(String investorLastName) {
        this.investorLastName = investorLastName;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public Boolean getAdviceGivenFlag() {
        return adviceGivenFlag;
    }

    public void setAdviceGivenFlag(Boolean adviceGivenFlag) {
        this.adviceGivenFlag = adviceGivenFlag;
    }

    public String getIsaType() {
        return isaType;
    }

    public void setIsaType(String isaType) {
        this.isaType = isaType;
    }

    public String getInvestorAMLStatus() {
        return investorAMLStatus;
    }

    public void setInvestorAMLStatus(String investorAMLStatus) {
        this.investorAMLStatus = investorAMLStatus;
    }

    public Boolean getExistingPolicyFlag() {
        return existingPolicyFlag;
    }

    public void setExistingPolicyFlag(Boolean existingPolicyFlag) {
        this.existingPolicyFlag = existingPolicyFlag;
    }

    public LocalDate getInvestorDateOfBirth() {
        return investorDateOfBirth;
    }

    public void setInvestorDateOfBirth(LocalDate dateOfBirth) {
        this.investorDateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfRetirement() {
        return dateOfRetirement;
    }

    public void setDateOfRetirement(LocalDate dateOfRetirement) {
        this.dateOfRetirement = dateOfRetirement;
    }

    public Instant getDateTimeCreated() {
        return dateTimeCreated;
    }

    public void setDateTimeCreated(Instant dateTimeCreated) {
        this.dateTimeCreated = dateTimeCreated;
    }

    public Instant getDateTimeLastModified() {
        return dateTimeLastModified;
    }

    public void setDateTimeLastModified(Instant dateTimeLastModified) {
        this.dateTimeLastModified = dateTimeLastModified;
    }

    public AnnuityFreqEnum getAnnuityFrequency() {
        return annuityFrequency;
    }

    public void setAnnuityFrequency(AnnuityFreqEnum annuityFrequency) {
        this.annuityFrequency = annuityFrequency;
    }

    public AnnuityTimingEnum getAnnuityTiming() {
        return annuityTiming;
    }

    public void setAnnuityTiming(AnnuityTimingEnum annuityTiming) {
        this.annuityTiming = annuityTiming;
    }

    public BigDecimal getAnnuityGuarantee() {
        return annuityGuarantee;
    }

    public void setAnnuityGuarantee(BigDecimal annuityGuarantee) {
        this.annuityGuarantee = annuityGuarantee;
    }

    public BigDecimal getAnnuityEscalation() {
        return annuityEscalation;
    }

    public void setAnnuityEscalation(BigDecimal annuityEscalation) {
        this.annuityEscalation = annuityEscalation;
    }

    public String getThirdPartySystemReference() {
        return thirdPartySystemReference;
    }

    public void setThirdPartySystemReference(String thirdPartySystemReference) {
        this.thirdPartySystemReference = thirdPartySystemReference;
    }

    public BigDecimal getDependantPensionPercent() {
        return dependantPensionPercent;
    }

    public void setDependantPensionPercent(BigDecimal dependantPensionPercent) {
        this.dependantPensionPercent = dependantPensionPercent;
    }

    public GenderEnum getDependantGender() {
        return dependantGender;
    }

    public void setDependantGender(GenderEnum dependantGender) {
        this.dependantGender = dependantGender;
    }

    public LocalDate getDependantDateOfBirth() {
        return dependantDateOfBirth;
    }

    public void setDependantDateOfBirth(LocalDate dependantDateOfBirth) {
        this.dependantDateOfBirth = dependantDateOfBirth;
    }

    public Boolean getDependantPersonalisePensionFlag() {
        return dependantPersonalisePensionFlag;
    }

    public Integer getProductTypeId() {
        return productTypeId;
    }

    public void setProductTypeId(Integer productTypeId) {
        this.productTypeId = productTypeId;
    }

    public GenderEnum getInvestorGender() {
        return investorGender;
    }

    public void setInvestorGender(GenderEnum investorGender) {
        this.investorGender = investorGender;
    }

    public String getInvestorEmailAddress() {
        return investorEmailAddress;
    }

    public void setInvestorEmailAddress(String investorEmailAddress) {
        this.investorEmailAddress = investorEmailAddress;
    }

    public Integer getInvestorExpectedRetirementAge() {
        return investorExpectedRetirementAge;
    }

    public void setInvestorExpectedRetirementAge(Integer investorExpectedRetirementAge) {
        this.investorExpectedRetirementAge = investorExpectedRetirementAge;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getOwnerTypeId() {
        return ownerTypeId;
    }

    public void setOwnerTypeId(String ownerTypeId) {
        this.ownerTypeId = ownerTypeId;
    }

    public String getOwnerType() {
        return ownerType;
    }

    public void setOwnerType(String ownerType) {
        this.ownerType = ownerType;
    }

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public String getInvestorAccountId() {
        return investorAccountId;
    }

    public void setInvestorAccountId(String investorAccountId) {
        this.investorAccountId = investorAccountId;
    }

    public void setDependantPersonalisePensionFlag(Boolean dependantPersonalisePensionFlag) {
        this.dependantPersonalisePensionFlag = dependantPersonalisePensionFlag;
    }

    @JsonFilter("serializeAll")
    public List<SingleContribution> getSingleContributions() {
        return singleContributions;
    }

    public void setSingleContributions(List<SingleContribution> singleContributions) {
        this.singleContributions = singleContributions;
    }

    @JsonFilter("serializeAll")
    public List<RegularContribution> getRegularContributions() {
        return regularContributions;
    }

    public void setRegularContributions(List<RegularContribution> regularContributions) {
        this.regularContributions = regularContributions;
    }

    @JsonFilter("serializeAll")
    public InvestmentStrategy getInvestmentStrategy() {
        return investmentStrategy;
    }

    public void setInvestmentStrategy(InvestmentStrategy investmentStrategy) {
        this.investmentStrategy = investmentStrategy;
    }

    @JsonFilter("serializeAll")
    public DrawdownIncome getDrawdownIncome() {
        return drawdownIncome;
    }

    public void setDrawdownIncome(DrawdownIncome drawdownIncome) {
        this.drawdownIncome = drawdownIncome;
    }

    public BigDecimal getOngoingAdviserChargeAmount() {
        return ongoingAdviserChargeAmount;
    }

    public void setOngoingAdviserChargeAmount(BigDecimal ongoingAdviserChargeAmount) {
        this.ongoingAdviserChargeAmount = ongoingAdviserChargeAmount;
    }

    public BigDecimal getOngoingAdviserChargePercent() {
        return ongoingAdviserChargePercent;
    }

    public void setOngoingAdviserChargePercent(BigDecimal ongoingAdviserChargePercent) {
        this.ongoingAdviserChargePercent = ongoingAdviserChargePercent;
    }

    public String getOngoingAdviserChargeFrequency() {
        return ongoingAdviserChargeFrequency;
    }

    public void setOngoingAdviserChargeFrequency(String ongoingAdviserChargeFrequency) {
        this.ongoingAdviserChargeFrequency = ongoingAdviserChargeFrequency;
    }

    public String getRelatedQuoteId() {
        return relatedQuoteId;
    }

    public void setRelatedQuoteId(String relatedQuoteId) {
        this.relatedQuoteId = relatedQuoteId;
    }

    @JsonFilter("serializeAll")
    public ApplicationDetails getApplicationDetails() {
        return applicationDetails;
    }

    public void setApplicationDetails(ApplicationDetails applicationDetails) {
        this.applicationDetails = applicationDetails;
    }

    @JsonFilter("serializeAll")
    public List<BankAccount> getInvestorBankAccounts() {
        return investorBankAccounts;
    }

    public void setInvestorBankAccounts(List<BankAccount> investorBankAccounts) {
        this.investorBankAccounts = investorBankAccounts;
    }

    @JsonFilter("serializeAll")
    public Trade getTrade() {
        return trade;
    }

    public void setTrade(Trade trade) {
        this.trade = trade;
    }

    //QuotedDate
    public Instant getQuotedDateTime() {
        return quotedDateTime;
    }

    public void setQuotedDateTime(Instant quotedDateTime) {
        this.quotedDateTime = quotedDateTime;
    }

    public Boolean getHabitualResident() {
        return habitualResident;
    }

    public void setHabitualResident(Boolean habitualResident) {
        this.habitualResident = habitualResident;
    }

    public String getInvestorTitle() {
        return investorTitle;
    }

    public void setInvestorTitle(String investorTitle) {
        this.investorTitle = investorTitle;
    }

    public String getInvestorMobileNumber() {
        return investorMobileNumber;
    }

    public void setInvestorMobileNumber(String investorMobileNumber) {
        this.investorMobileNumber = investorMobileNumber;
    }

    public String getInvestorHomeNumber() {
        return investorHomeNumber;
    }

    public void setInvestorHomeNumber(String investorHomeNumber) {
        this.investorHomeNumber = investorHomeNumber;
    }

    public String getInvestorWorkNumber() {
        return investorWorkNumber;
    }

    public void setInvestorWorkNumber(String investorWorkNumber) {
        this.investorWorkNumber = investorWorkNumber;
    }

    public String getInvestorNationality() {
        return investorNationality;
    }

    public void setInvestorNationality(String investorNationality) {
        this.investorNationality = investorNationality;
    }

    public String getNationalInsuranceNumber() {
        return nationalInsuranceNumber;
    }

    public void setNationalInsuranceNumber(String nationalInsuranceNumber) {
        this.nationalInsuranceNumber = nationalInsuranceNumber;
    }

    @JsonFilter("serializeAll")
    public SecondaryAccount getSecondaryAccount() {
        return secondaryAccount;
    }

    public void setSecondaryAccount(SecondaryAccount secondaryAccount) {
        this.secondaryAccount = secondaryAccount;
    }

    public Boolean getApplySameInvestmentStrategy() {
        return applySameInvestmentStrategy;
    }

    public void setApplySameInvestmentStrategy(Boolean applySameInvestmentStrategy) {
        this.applySameInvestmentStrategy = applySameInvestmentStrategy;
    }

    @JsonFilter("serializeAll")
    public PreviousBCE getPreviousBCE() {
        return previousBCE;
    }

    public void setPreviousBCE(PreviousBCE previousBCE) {
        this.previousBCE = previousBCE;
    }

    @JsonFilter("serializeAll")
    public Protection getProtection() {
        return protection;
    }

    public void setProtection(Protection protection) {
        this.protection = protection;
    }

    @JsonFilter("serializeAll")
    public PolicyPaymentPlan getPolicyPaymentPlan() {
        return policyPaymentPlan;
    }

    public void setPolicyPaymentPlan(PolicyPaymentPlan policyPaymentPlan) {
        this.policyPaymentPlan = policyPaymentPlan;
    }

    @JsonFilter("serializeAll")
    public List<SippTransferIn> getSippTransferIns() {
        return sippTransferIns;
    }

    public void setSippTransferIns(List<SippTransferIn> sippTransferIns) {
        this.sippTransferIns = sippTransferIns;
    }

    @JsonFilter("serializeAll")
    public CrystallisationDetails getCrystallisationDetails() {
        return crystallisationDetails;
    }

    public void setCrystallisationDetails(CrystallisationDetails crystallisationDetails) {
        this.crystallisationDetails = crystallisationDetails;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    @JsonFilter("serializeAll")
    public RegisteredContact getRegisteredContactDetails() {
        return registeredContactDetails;
    }

    public void setRegisteredContactDetails(RegisteredContact registeredContactDetails) {
        this.registeredContactDetails = registeredContactDetails;
    }

    public String getLastStep() {
        return lastStep;
    }

    public void setLastStep(String lastStep) {
        this.lastStep = lastStep;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    @JsonFilter("serializeAll")
    public Address getInvestorActualAddress() {
        return investorActualAddress;
    }

    public void setInvestorActualAddress(Address investorActualAddress) {
        this.investorActualAddress = investorActualAddress;
    }

    public BigDecimal getRegularInitialChargeAmount() {
        return regularInitialChargeAmount;
    }

    public void setRegularInitialChargeAmount(BigDecimal regularInitialChargeAmount) {
        this.regularInitialChargeAmount = regularInitialChargeAmount;
    }

    public BigDecimal getTransferInInitialChargeAmount() {
        return transferInInitialChargeAmount;
    }

    public void setTransferInInitialChargeAmount(BigDecimal transferInInitialChargeAmount) {
        this.transferInInitialChargeAmount = transferInInitialChargeAmount;
    }

    public BigDecimal getTransferInInitialChargePercent() {
        return transferInInitialChargePercent;
    }

    public void setTransferInInitialChargePercent(BigDecimal transferInInitialChargePercent) {
        this.transferInInitialChargePercent = transferInInitialChargePercent;
    }

    public BigDecimal getRegularInitialChargePercent() {
        return regularInitialChargePercent;
    }

    public void setRegularInitialChargePercent(BigDecimal regularInitialChargePercent) {
        this.regularInitialChargePercent = regularInitialChargePercent;
    }

    public Integer getRegularInitialChargeTerm() {
        return regularInitialChargeTerm;
    }

    public void setRegularInitialChargeTerm(Integer regularInitialChargeTerm) {
        this.regularInitialChargeTerm = regularInitialChargeTerm;
    }

    public BigDecimal getSingleInitialChargeAmount() {
        return singleInitialChargeAmount;
    }

    public void setSingleInitialChargeAmount(BigDecimal singleInitialChargeAmount) {
        this.singleInitialChargeAmount = singleInitialChargeAmount;
    }

    public BigDecimal getSingleInitialChargePercent() {
        return singleInitialChargePercent;
    }

    public void setSingleInitialChargePercent(BigDecimal singleInitialChargePercent) {
        this.singleInitialChargePercent = singleInitialChargePercent;
    }

    @JsonFilter("serializeAll")
    public List<IsaTransferIn> getIsaTransferIns() {
        return isaTransferIns;
    }

    public void setIsaTransferIns(List<IsaTransferIn> isaTransferIns) {
        this.isaTransferIns = isaTransferIns;
    }

    public String getProductDisplayName() {
        return productDisplayName;
    }

    public void setProductDisplayName(String productDisplayName) {
        this.productDisplayName = productDisplayName;
    }

    public String getThirdPartySystem() {
        return thirdPartySystem;
    }

    public void setThirdPartySystem(String thirdPartySystem) {
        this.thirdPartySystem = thirdPartySystem;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public List<CustomField> getCustomFields() {
        return customFields;
    }

    public void setCustomFields(List<CustomField> customFields) {
        this.customFields = customFields;
    }

    public LocalDate getFundStartDate() {
        return fundStartDate;
    }

    public void setFundStartDate(LocalDate fundStartDate) {
        this.fundStartDate = fundStartDate;
    }

    public String getAdviserTitle() {
        return adviserTitle;
    }

    public void setAdviserTitle(String adviserTitle) {
        this.adviserTitle = adviserTitle;
    }

    public String getAdviserFirstName() {
        return adviserFirstName;
    }

    public void setAdviserFirstName(String adviserFirstName) {
        this.adviserFirstName = adviserFirstName;
    }

    public String getAdviserLastName() {
        return adviserLastName;
    }

    public void setAdviserLastName(String adviserLastName) {
        this.adviserLastName = adviserLastName;
    }

    public String getAdviserBranchCompanyName() {
        return adviserBranchCompanyName;
    }

    public void setAdviserBranchCompanyName(String adviserBranchCompanyName) {
        this.adviserBranchCompanyName = adviserBranchCompanyName;
    }

    public String getAdviserNetworkCompanyName() {
        return adviserNetworkCompanyName;
    }

    public void setAdviserNetworkCompanyName(String adviserNetworkCompanyName) {
        this.adviserNetworkCompanyName = adviserNetworkCompanyName;
    }
}
