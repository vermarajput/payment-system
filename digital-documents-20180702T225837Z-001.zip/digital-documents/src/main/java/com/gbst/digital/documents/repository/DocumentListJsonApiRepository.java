package com.gbst.digital.documents.repository;

import com.gbst.common.jsonapi.DefaultResourceRepository;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.*;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import io.katharsis.queryParams.QueryParams;
import io.katharsis.repository.ResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Aman Verma on 17/11/2017
 */
@Component
public class DocumentListJsonApiRepository extends DefaultResourceRepository<DocumentList, String> implements ResourceRepository<DocumentList, String> {
    @Autowired
    private DocumentConfigurationsJsonApiRepository documentConfigurationsJsonApiRepository;

    @Autowired
    private RepositoryValidator repositoryValidator;

    @Autowired
    private RepositoryUtil repositoryUtil;

    @Autowired
    private List<DocumentGenerator> documentGenerationHandlers;

    @Autowired
    private DocumentPayloadFactory documentPayloadFactory;

    @Override
    public DocumentList save(DocumentList documentListRequest) {
        if (documentListRequest != null) {
            repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_LISTING, documentListRequest.getProcessType(), documentListRequest.getProcessTypeId(), documentListRequest.getProcessStage(), documentListRequest.getRole(), null);
            QueryParams document_configurations_queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig(documentListRequest.getProcessType(), documentListRequest.getProcessTypeId(), documentListRequest.getProcessStage(), documentListRequest.getRole());

            // get the document-configurations based on input
            List<DocumentConfiguration> docConfigs = (List<DocumentConfiguration>) documentConfigurationsJsonApiRepository.findAll(document_configurations_queryParams);
            repositoryValidator.validateDocumentConfiguration(docConfigs);

            DocumentPayload payload = documentPayloadFactory.createPayload(documentListRequest.getDocumentAttributesFormat(), documentListRequest.getDocumentAttributes());
            List<Document> docsList = new ArrayList<>();
            for (DocumentForConfig docForConfig : docConfigs.get(0).getDocuments()) {
                payload.setDocumentForConfig(docForConfig);
                
                Document document = new Document(docForConfig.getUrl(), docForConfig.getDocumentName(), docForConfig.getGenerationStrategy(), docForConfig.getOutputType(), docForConfig.getDocumentDisplayName());
                if (documentSupported(documentListRequest, payload)) {
                    docsList.add(document);
                }
            }
            documentListRequest.setDocuments(docsList);
        }
        return documentListRequest;
    }

    /**
     * @param documentWithParameter - extended document object to be sed a transfer object between handlers
     * @return boolean to show of document is supported to be generated or not
     */
    private boolean documentSupported(DocumentList documentWithParameter, DocumentPayload payload) {
        for (DocumentGenerator handler : documentGenerationHandlers) {
            if (handler.supports(documentWithParameter, payload)) {
                return true;
            }
        }
        return false;
    }

}
