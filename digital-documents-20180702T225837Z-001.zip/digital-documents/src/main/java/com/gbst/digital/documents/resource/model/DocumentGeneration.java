package com.gbst.digital.documents.resource.model;

import com.fasterxml.jackson.annotation.JsonFilter;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import org.springframework.data.annotation.Id;

import java.util.List;

/**
 * @author nehas
 */
@org.springframework.data.mongodb.core.mapping.Document(collection = "document-generation")
@JsonApiResource(type = "document-generations")
public class DocumentGeneration extends BaseDocumentGeneration<DocumentForGeneration> {

    @Id
    @JsonApiId
    private String id;
    private String processId ; //the identifier for the journey ..currently will hold the quote id

    // for the return from the service
    private String owner; // will contain the value from the token / auth header
    private List<DocumentForGeneration> documents;

    @JsonFilter("serializeAll")
    public List<DocumentForGeneration> getDocuments() {
        return documents;
    }

    public void setDocuments(List<DocumentForGeneration> documents) {
        this.documents = documents;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    @Override
    public String toString() {
        return "DocumentGenerationEntity{" +
                "id='" + id + '\'' +
                ", processType='" + processType + '\'' +
                ", processTypeId='" + processTypeId + '\'' +
                ", role='" + role + '\'' +
                ", processStage='" + processStage + '\'' +
                ", processId='" + processId + '\'' +
                ", documentAttributes=" + documentAttributes +
                ", documents=" + documents +
                '}';
    }
}
