package com.gbst.digital.documents.generator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.digital.documents.resource.model.PayloadFormatEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */

/**
 * If the format is provided in the request, DocumentPayloadFactory tries to convert the string payload to the provided format.
 * In this case, if it fails to do so, there will be error thrown and as the result document generation will fail.
 *
 * However, if the format is not provided, DocumentPayloadFactory examines the payload to determine the format. If it cannot
 * determine the format of the payload, {@link PayloadFormatEnum#PlainText} will be considered as the format and no error will be thrown.
 */
@Service
public class DocumentPayloadFactory {

    private static final Logger LOG = LoggerFactory.getLogger(DocumentPayloadFactory.class);

    private ObjectMapper mapper;

    @Autowired
    public DocumentPayloadFactory(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public DocumentPayload createPayload(PayloadFormatEnum format, String payload) {

        if((format == null || (format.equals(PayloadFormatEnum.PlainText))) && (payload == null || payload.trim().isEmpty())) {
            LOG.info("Payload is null or empty. Format will be plain text.");
            return new DocumentPayload(PayloadFormatEnum.PlainText, payload, "");
        }

        //Testing if the payload is JSON
        if(format == null || format.equals(PayloadFormatEnum.JSON)) {
            try {
                LOG.debug("Testing if payload is JSON text");
                return new DocumentPayload(PayloadFormatEnum.JSON, payload, mapper.readTree(payload));
            } catch (IOException e) {
                if(PayloadFormatEnum.JSON.equals(format)) {
                    LOG.error("Payload corrupted", e);
                    throw new IllegalStateException("Document payload is not of JSON format while incoming format type specified as JSON in the request");
                }

                LOG.error("Payload is either not JSON or is invalid JSON text. Ignore this if message is not JSON: {}", e.getMessage());
                if(LOG.isDebugEnabled()) {
                    LOG.debug("Payload => {}", payload);
                    LOG.debug("Could not map the payload to JsonNode", e);
                }
            }
        }

        if(format == null || format.equals(PayloadFormatEnum.XML)) {
            LOG.debug("Test if payload is XML message");
            if(payload.contains("<?xml")) { //xml documents have <?xml 
                //Note if we want to support XML we need to make changes here in future
                return new DocumentPayload(PayloadFormatEnum.XML, payload, payload);
            }
        }

        //default
        return new DocumentPayload(PayloadFormatEnum.PlainText, payload, payload);
    }

}
