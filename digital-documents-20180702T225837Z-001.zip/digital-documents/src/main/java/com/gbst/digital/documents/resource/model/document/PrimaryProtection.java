package com.gbst.digital.documents.resource.model.document;

import java.math.BigDecimal;

/***
 * @author nehas
 */
public class PrimaryProtection {

    private BigDecimal ltaEnhancementFactor;
    private BigDecimal protectedPCLS;

    public BigDecimal getLtaEnhancementFactor() {
        return ltaEnhancementFactor;
    }

    public void setLtaEnhancementFactor(BigDecimal ltaEnhancementFactor) {
        this.ltaEnhancementFactor = ltaEnhancementFactor;
    }

    public BigDecimal getProtectedPCLS() {
        return protectedPCLS;
    }

    public void setProtectedPCLS(BigDecimal protectedPCLS) {
        this.protectedPCLS = protectedPCLS;
    }
}
