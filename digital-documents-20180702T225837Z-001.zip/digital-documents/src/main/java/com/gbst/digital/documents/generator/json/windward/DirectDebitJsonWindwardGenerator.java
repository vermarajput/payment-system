package com.gbst.digital.documents.generator.json.windward;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.document.types.ContributorTypeEnum;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */
@ConditionalOnProperty(value = "gbst.digital.documents.types.directDebit", havingValue = "Windward")
@Service
public class DirectDebitJsonWindwardGenerator extends AbstractWindwardDocumentGenerator implements DocumentGenerator {

    private static final Logger LOG = LoggerFactory.getLogger(DirectDebitJsonWindwardGenerator.class);
    public static final String REGULAR_CONTRIBUTIONS_ATTR = "regularContributions";
    public static final String POLICY_PAYMENT_PLAN = "policyPaymentPlan";
    public static final String CONTRIBUTOR_TYPE = "contributorType";
    public static final String APPLY_BOOST_FLAG = "applyBoostFlag";
    public static final String CLIENT_PRESENT_FLAG = "clientPresentFlag";
    public static final String CLIENT_DEBIT_AUTHORISATION_FLAG = "clientDebitAuthorisationFlag";

   @Override
    public void validate(DocumentGeneration documentWithParameter, DocumentPayload payload) throws DocumentGenerationException {
        //no business validation required
    }

    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {
        DocumentForConfig config = payload.getDocumentForConfig();
        boolean supports = payload.isJson() && GenerationStrategyEnum.WINDWARD.getValue().equals(String.valueOf(config.getGenerationStrategy()));

        if(supports) {
            JsonNode jsonNodeAttributes = payload.getPayloadAsJsonNode();
            if (jsonNodeAttributes != null && config.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name())) {  //Manual Direct Debit Authorisation
                return isRegularContributionForInvestor(jsonNodeAttributes) || isPaperDirectDebitAuthorityAllowed(jsonNodeAttributes);
            }
        }

        return false;
    }

    @Override
    public List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        return super.generateFromJsonPayload(document, payload);
    }

    // if the journey jsonNodeAttributes has a regular contribution with contributor type "Investor"  OR tag to apply for Vitality+ defined that requires a paper direct debit authority
    private boolean isRegularContributionForInvestor(JsonNode jsonNodeAttributes) {
        if (jsonNodeAttributes.get(REGULAR_CONTRIBUTIONS_ATTR) != null && jsonNodeAttributes.get(REGULAR_CONTRIBUTIONS_ATTR).isArray()) {
            ArrayNode regContri = (ArrayNode) jsonNodeAttributes.get(REGULAR_CONTRIBUTIONS_ATTR);
            for (JsonNode node : regContri) {
                if (node.get(CONTRIBUTOR_TYPE) != null && node.get(CONTRIBUTOR_TYPE).asText().equalsIgnoreCase(ContributorTypeEnum.Investor.getValue()) && eitherOfClientFieldsIsSetToFalseOrNull(node)) {
                    return true;
                }
            }
        }

        // No regular contributions with Investor as ContributorType and
        // ClientPresentFlag and ClientDebitAuthorisationFlag field are set to true
        return false;
    }

    // Note - the windward template will generate a direct debit authority for each "paper" investor direct debit authority defined in the payload
    private boolean isPaperDirectDebitAuthorityAllowed(JsonNode node) {
        return (node.get(APPLY_BOOST_FLAG) != null && node.get(APPLY_BOOST_FLAG).asBoolean())
                && (node.get(POLICY_PAYMENT_PLAN) != null && eitherOfClientFieldsIsSetToFalseOrNull(node.get(POLICY_PAYMENT_PLAN)));
    }

    /**
     * If clientPresentFlag & clientDebitAuthorisationFlag are true then ensure that paper form is not generated in document list.
     *
     * This method checks if the field is present and set to false then returns true
     *
     * @param node
     * @return
     */
    private boolean eitherOfClientFieldsIsSetToFalseOrNull(JsonNode node){
        return node.get(CLIENT_PRESENT_FLAG) == null || !node.get(CLIENT_PRESENT_FLAG).asBoolean()
                || node.get(CLIENT_DEBIT_AUTHORISATION_FLAG) == null || !node.get(CLIENT_DEBIT_AUTHORISATION_FLAG).asBoolean();
    }
}
