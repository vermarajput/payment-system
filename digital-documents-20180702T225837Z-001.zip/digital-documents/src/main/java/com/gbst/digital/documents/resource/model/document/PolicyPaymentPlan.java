package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * @author Cecily on 23/10/2017
 */
public class PolicyPaymentPlan {
    private String amount;
    private String frequency;

    // Apply Money In Details
    private Boolean clientPresentFlag;
    private Boolean clientDebitAuthorisationFlag;
    private BankAccount bankAccount;

    public PolicyPaymentPlan() {
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public Boolean getClientPresentFlag() {
        return clientPresentFlag;
    }

    public void setClientPresentFlag(Boolean clientPresentFlag) {
        this.clientPresentFlag = clientPresentFlag;
    }

    public Boolean getClientDebitAuthorisationFlag() {
        return clientDebitAuthorisationFlag;
    }

    public void setClientDebitAuthorisationFlag(Boolean clientDebitAuthorisationFlag) {
        this.clientDebitAuthorisationFlag = clientDebitAuthorisationFlag;
    }

    @JsonFilter("serializeAll")
    public BankAccount getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccountDetails) {
        this.bankAccount = bankAccountDetails;
    }
}
