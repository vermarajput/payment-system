package com.gbst.digital.documents.resource.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.gbst.common.jsonapi.serializer.LocalDateDeserializer;
import com.gbst.common.jsonapi.serializer.LocalDateSerializer;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author rekhar on 23/10/2017
 */
public class PensionBenefitsEvents {

    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate crystallisedDate;

    private BigDecimal ltaPercent;

    public LocalDate getCrystallisedDate() {
        return crystallisedDate;
    }

    public void setCrystallisedDate(LocalDate crystallisedDate) {
        this.crystallisedDate = crystallisedDate;
    }

    public BigDecimal getLtaPercent() {
        return ltaPercent;
    }

    public void setLtaPercent(BigDecimal ltaPercent) {
        this.ltaPercent = ltaPercent;
    }
}
