package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * @author rekhar on 23/10/2017
 */
public class PreviousBCE {

    private PensionBenefits pensionBenefits;
    private PensionPayments pensionPayments;
    private OverseasTransfers overseasTransfers;

    @JsonFilter("serializeAll")
    public PensionBenefits getPensionBenefits() {
        return pensionBenefits;
    }

    public void setPensionBenefits(PensionBenefits pensionBenefits) {
        this.pensionBenefits = pensionBenefits;
    }

    @JsonFilter("serializeAll")
    public PensionPayments getPensionPayments() {
        return pensionPayments;
    }

    public void setPensionPayments(PensionPayments pensionPayments) {
        this.pensionPayments = pensionPayments;
    }

    @JsonFilter("serializeAll")
    public OverseasTransfers getOverseasTransfers() {
        return overseasTransfers;
    }

    public void setOverseasTransfers(OverseasTransfers overseasTransfers) {
        this.overseasTransfers = overseasTransfers;
    }
}
