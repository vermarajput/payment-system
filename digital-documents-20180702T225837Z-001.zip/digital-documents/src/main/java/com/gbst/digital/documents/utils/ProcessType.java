package com.gbst.digital.documents.utils;

/**
 * The values used for Process type has been matched with the CBIS process types, and there can have more new values
 */
public enum ProcessType {
    NEW_BUSINESS, //NEW_BUSINESS, NEW_WRAPPER
    TOPUP,
    TRANSFER_IN,
    DRAWDOWN,   //NEW_BUSINESS, NEW_WRAPPER
    SWITCH,
    CRYSTALLISE;

    /**
     * Constructor.
     */
    private ProcessType() {
    }

    /**
     * Helper to determine if current process type involves new business.
     * @return true if new business related or false otherwise.
     */
    public boolean isNewBusiness()
    {
        return NEW_BUSINESS.equals(this) || DRAWDOWN.equals(this);
    }

   
}
