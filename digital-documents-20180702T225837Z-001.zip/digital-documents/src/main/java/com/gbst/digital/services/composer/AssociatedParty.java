package com.gbst.digital.services.composer;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 16/01/2018
 */
public class AssociatedParty {

    private Integer partyId;
    private Integer partyTypeId;

    public void setPartyId(Integer partyId) {
        this.partyId = partyId;
    }

    public Integer getPartyId() {
        return partyId;
    }

    public void setPartyTypeId(Integer partyTypeId) {
        this.partyTypeId = partyTypeId;
    }

    public Integer getPartyTypeId() {
        return partyTypeId;
    }
}
