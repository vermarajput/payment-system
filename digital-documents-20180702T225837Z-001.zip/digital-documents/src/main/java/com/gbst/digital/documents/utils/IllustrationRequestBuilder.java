package com.gbst.digital.documents.utils;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.party.PartyTypeSettings;
import com.gbst.common.utils.GbstDateUtils;
import com.gbst.digital.Services;
import com.gbst.digital.documents.generator.json.cie.IllustrationDocumentGeneratorSettings;
import com.gbst.digital.documents.resource.model.document.Application;
import com.gbst.digital.documents.resource.model.document.Contribution;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.document.InvestmentStrategy;
import com.gbst.digital.documents.resource.model.document.IsaTransferIn;
import com.gbst.digital.documents.resource.model.document.RegularContribution;
import com.gbst.digital.documents.resource.model.document.SingleContribution;
import com.gbst.digital.documents.resource.model.document.SippTransferIn;
import com.gbst.digital.documents.resource.model.document.types.AnnuityTimingEnum;
import com.gbst.digital.documents.resource.model.document.types.ContributorTypeEnum;
import com.gbst.digital.documents.resource.model.document.types.GenderEnum;
import com.gbst.digital.documents.resource.model.document.types.SippTransferTypeEnum;
import com.gbst.digital.documents.utils.builder.ClientSpecificRequestBuilder;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.common.GenderCharType;
import com.infocomp.cbis.common.YesNoFlag;
import com.infocomp.cbis.uk.domain.common.ClientRequestIllustrationType;
import com.infocomp.cbis.uk.domain.common.IllustrationType;
import com.infocomp.cbis.uk.request.ClientSpecificValue;
import com.infocomp.cbis.uk.request.IllustrationChargesType;
import com.infocomp.cbis.uk.request.IllustrationContributionType;
import com.infocomp.cbis.uk.request.IllustrationFundType;
import com.infocomp.cbis.uk.request.IllustrationPayloadType;
import com.infocomp.cbis.uk.request.IllustrationPersonalDetailsType;
import com.infocomp.cbis.uk.request.IllustrationProtectionType;
import com.infocomp.cbis.uk.request.IllustrationTrancheType;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.AccumulationIllustration;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.Default;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.DrawdownIllustration;
import static com.gbst.digital.documents.utils.ProcessType.DRAWDOWN;
import static com.gbst.digital.documents.utils.ProcessType.NEW_BUSINESS;
import static com.gbst.digital.documents.utils.ProcessType.TOPUP;
import static java.lang.Boolean.TRUE;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 5/10/2017
 */
@Service
@Profile("illustration")
public class IllustrationRequestBuilder {

    private ObjectFactory requestObjectFactory = new ObjectFactory();
    private com.infocomp.cbis.uk.domain.common.ObjectFactory commonObjectFactory = new com.infocomp.cbis.uk.domain.common.ObjectFactory();

    static final String FIXED_COMM_CHARGE_TYPE_CODE = "FXD_COMM";
    static final String TRANSFER_COMM_CHARGE_TYPE_CODE = "TRN_COMM";
    static final String SINGLE_COMM_CHARGE_TYPE_CODE = "SGL_COMM";
    static final String REGULAR_COMM_CHARGE_TYPE_CODE = "REG_COMM";
    static final String TRAIL_COMM_CHARGE_TYPE_CODE = "TRL_COMM";
    static final String DFM_COMM_CHARGE_TYPE_CODE = "DFM_COMM";
    private static final String DFM_CHARGE = "dfm-charge";
    private static final String FXD_COMM_CHARGE = "fxd-comm-charge";

    @Autowired
    private ProductService productService;

    @Autowired
    IllustrationDocumentGeneratorSettings settings;

    @Autowired
    AuthenticationFacade authenticationFacade;

    @Autowired
    PartyTypeSettings partyTypeSettings;

    @Autowired
    private ClientSpecificRequestBuilder clientSpecificRequestBuilder;

    public RequestIllustrationType buildRequestIllustrationType(DocumentAttributes illustrationDocument, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        Objects.requireNonNull(illustrationSelectorEnum, "At least 'Default' should be provided");

        ProductTypes.ProductType primaryProductType = null;
        if (illustrationDocument.getProductTypeId() != null) {
            primaryProductType = getProductType(illustrationDocument.getProductTypeId());
        }

        boolean isISA = false;
        if(primaryProductType != null && primaryProductType.getDetails() != null && "I".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag())) {
            //there is no point checking for ISA account is product type is not "I"
            isISA = isISA(illustrationDocument);
        }

        RequestIllustrationType req = requestObjectFactory.createRequestIllustrationType();

        // Illustration Payload
        setTopLevelFields(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setPartyType(req, illustrationDocument, processType, illustrationSelectorEnum);
        setCrystallisationRelatedFields(req, illustrationDocument, processType, illustrationSelectorEnum);
        setInvestmentModel(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setProductType(req, illustrationDocument, processType, illustrationSelectorEnum);
        setClientSpecificValues(req, illustrationDocument, processType, illustrationSelectorEnum);
        setIncomeRequired(req, illustrationDocument, processType, illustrationSelectorEnum);
        IllustrationPayloadType payload = requestObjectFactory.createIllustrationPayloadType();
        req.setIllustrationPayload(payload);
        setPlanStartDate(req, illustrationDocument, processType, illustrationSelectorEnum, payload);
        setPayloadFields(req, illustrationDocument, processType, illustrationSelectorEnum, payload);
        setOtherFields(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setClientRequest(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setQuoteType(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setAnnuities(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setPersonalDetails(req, illustrationDocument, processType, illustrationSelectorEnum);
        // Protection must occur prior to contributions. Pls don't move it
        setProtectionOptions(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setMixedContribution(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setProductCharges(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setIncomeOptions(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        //This should be after setQuoteType() pls don't move it
        setTargetTfc(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setContributions(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setTranches(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        setFund(req, illustrationDocument, processType, illustrationSelectorEnum);
        clientSpecificRequestBuilder.enrichRequest(req, illustrationDocument, primaryProductType, processType, illustrationSelectorEnum, isISA);
        return req;
    }

    public IllustrationSelectorEnum[] getDocumentTypesRequired(DocumentAttributes illustrationDocument, ProcessType processType) {
        if (DRAWDOWN.equals(processType)) {
            boolean fullCrystallisation = illustrationDocument.getCrystallisationDetails().getCrystalliseFullAmountFlag();
            boolean noRegularContribution = !hasRegularContribution(illustrationDocument);
            if(fullCrystallisation && noRegularContribution) {
                return new IllustrationSelectorEnum[] {DrawdownIllustration};
            } else if(fullCrystallisation) {// and there is regular contributions
                return new IllustrationSelectorEnum[] {AccumulationIllustration, DrawdownIllustration};
            } else {
                return new IllustrationSelectorEnum[] {DrawdownIllustration, AccumulationIllustration};
            }
        }

        return new IllustrationSelectorEnum[] {Default};
    }

    private void setPlanStartDate(RequestIllustrationType req, DocumentAttributes doc, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, IllustrationPayloadType payload) {
        //planStartDate defaults to current system date
        if(doc.getInvestorAccountId() != null && doc.getFundStartDate() != null) {
            payload.setPlanStartDate(GbstDateUtils.asXMLGregorianCalendar(doc.getFundStartDate()));
        } else if ((processType.isNewBusiness())) {
            payload.setPlanStartDate(GbstDateUtils.asXMLGregorianCalendar(LocalDate.now()));
        }
    }

    private void setPayloadFields(RequestIllustrationType req, DocumentAttributes doc, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, IllustrationPayloadType payload) {

        //This is illustration run date
        payload.setIllustrationDate(GbstDateUtils.asXMLGregorianCalendar(LocalDateTime.now()));
    }

    private void setCrystallisationRelatedFields(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        if (ProcessType.CRYSTALLISE.equals(processType)) {
            //TODO to be set when crystallisation is going to be implemented
            // req.setTargetIDDAccountId(crystallisationDetails.getTargetIDDAccountId());
//            if(crystallisationDetails.getCrystalliseOption() != null && !CrystalliseOption.FULL.equals(crystallisationDetails.getCrystalliseOption())){
//                req.setInvestmentModelSelected(YesNoFlag.N);
//                req.setFullCrystallization(YesNoFlag.N);
//            } else {
//                req.setInvestmentModelSelected(null);
//                req.setFullCrystallization(YesNoFlag.Y);
//            }
        }
    }

    private void setIncomeRequired(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        if (DRAWDOWN.equals(processType) || ProcessType.CRYSTALLISE.equals(processType)) {
            if (document.getDrawdownIncome() != null &&
                    document.getDrawdownIncome().getAmount() != null &&
                    document.getDrawdownIncome().getAmount().compareTo(BigDecimal.ZERO) > 0) {
                req.setIncomeRequired(true);
            }
        }
    }

    private void setPartyType(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        GbstPrincipal principal = authenticationFacade.getPrincipal();
        Integer partyTypeId = partyTypeSettings.getValueAsInteger(Services.COMPOSER, principal.getGbstPartyType());
        req.setPartyTypeId(partyTypeId);
    }

    private void setProductType(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        req.setProductTypeId(document.getProductTypeId()); //by default

        if (ProcessType.CRYSTALLISE.equals(processType)) {
            ProductTypes.ProductType iddProductType = productService.getAssociatedIDDProductType(document.getProductTypeId());
            req.setProductTypeId(iddProductType.getDetails().getProductTypeId());
        } else if (DRAWDOWN.equals(processType) && document.getCrystallisationDetails() != null) {
            switch (illustrationSelectorEnum) {
                case AccumulationIllustration:
                    //top level productTypeId is always Accumulation when doing Drawdown
                    req.setProductTypeId(document.getProductTypeId());
                    break;
                case DrawdownIllustration:
                    //secondary account is always IDD account when doing Drawdown
                    req.setProductTypeId(Integer.parseInt(document.getSecondaryAccount().getProductTypeId()));
                    break;
            }
        }
    }

    private void setClientSpecificValues(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        RequestIllustrationType.ClientSpecificValues clientSpecificValues = requestObjectFactory.createRequestIllustrationTypeClientSpecificValues();

        if ((NEW_BUSINESS.equals(processType)
                || TOPUP.equals(processType)
                || DRAWDOWN.equals(processType))
                && document.getAdviceGivenFlag() != null) {
            ClientSpecificValue clientSpecificValue = requestObjectFactory.createClientSpecificValue();
            clientSpecificValue.setShortCode("ADVICEGIVENFLAG");
            clientSpecificValue.setValue(document.getAdviceGivenFlag() ? "Y" : "N");

            clientSpecificValues.getClientSpecificValue().add(clientSpecificValue);
        }
        /*
        TODO PRICEPLAN ?
        if(account.getPricePlan() != null) {
            ClientSpecificValue clientSpecificValue = objectFactory.createClientSpecificValue();
            clientSpecificValue.setShortCode("PRICEPLAN");
            clientSpecificValue.setValue(account.getPricePlan());

            clientSpecificValues.getClientSpecificValue().add(clientSpecificValue);
        }
         */

        if (!clientSpecificValues.getClientSpecificValue().isEmpty()) {
            req.setClientSpecificValues(clientSpecificValues);
        }
    }

    public JAXBElement<RequestIllustrationType> createRequestIllustration(RequestIllustrationType req) {
        return requestObjectFactory.createRequestIllustration(req);
    }

    private void setInvestmentModel(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }

        if (document.getInvestmentStrategy() != null) {
            req.setInvestmentModelSelected(document.getInvestmentStrategy().getInvestmentModelId() != null ? YesNoFlag.Y : YesNoFlag.N);
        }
    }

    private void setTopLevelFields(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isISA) {
            req.setIllustrationType(IllustrationType.G); 
        } else if (processType.isNewBusiness()) {
            req.setIllustrationType(IllustrationType.N); //New Business
        } else if (ProcessType.TOPUP.equals(processType)) {
            req.setIllustrationType(IllustrationType.T);
        }
        //Setting the output type default as B for CIE.
        req.setOutputTypeRequired("B"); // When B, the result will be output stream
        req.setContributionType(null); //This is for special illustration, for now it's null
        GbstPrincipal principal = authenticationFacade.getPrincipal();
        String userName = principal.getUsername();
        req.setUsername(userName);
        if (document.getCrystallisationDetails() != null && document.getCrystallisationDetails().getCrystalliseFullAmountFlag() != null) {
            req.setFullCrystallization(Boolean.TRUE.equals(document.getCrystallisationDetails().getCrystalliseFullAmountFlag()) ? YesNoFlag.Y : YesNoFlag.N);
        }

        if(document.getInvestorAccountId() != null && !document.getInvestorAccountId().isEmpty()) {
            req.setMemberAccountId(Integer.valueOf(document.getInvestorAccountId()));
        } else if ("P".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag()) || DrawdownIllustration.equals(illustrationSelectorEnum)) {
            req.setMemberAccountId(-1);
        }

        if(document.getInvestorId() != null && !document.getInvestorId().isEmpty()) {
            req.setInvestorId(Integer.valueOf(document.getInvestorId()));
        }

        //request.setEmployerGroupId();
        //request.setFullCrystallization();
        //request.setMasterMemberAccountId(); //CW: req.setMasterMemberAccountId(payload.getComposerPartyId());
        //request.setSetupOnly();

    }

    private void setFund(RequestIllustrationType req, DocumentAttributes document, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        IllustrationPayloadType.Funds fundList = requestObjectFactory.createIllustrationPayloadTypeFunds();
        InvestmentStrategy investmentStrategy;
        if(DRAWDOWN.equals(processType) && DrawdownIllustration.equals(illustrationSelectorEnum)) {
            investmentStrategy = document.getSecondaryAccount().getInvestmentStrategy();
        } else {
            investmentStrategy = document.getInvestmentStrategy();
        }

        if (investmentStrategy != null && investmentStrategy.getInvestments() != null) {
            for (com.gbst.digital.documents.resource.model.document.Investment inv : investmentStrategy.getInvestments()) {
                IllustrationFundType fund = requestObjectFactory.createIllustrationFundType();
                fund.setPortfolioId(Integer.parseInt(inv.getInvestmentId()));
                fund.setFundValue(inv.getInvestmentPercent() != null ? inv.getInvestmentPercent().doubleValue() : null);
                fundList.getFund().add(fund);
            }
        }

        req.getIllustrationPayload().setFunds(fundList);
    }

    private void setOtherFields(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        IllustrationPayloadType payload = req.getIllustrationPayload();
        if(isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }

        payload.setDependantsIllustration(0);
    }

    private void setClientRequest(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }

        IllustrationPayloadType payload = req.getIllustrationPayload();

        payload.setClientRequest(commonObjectFactory.createClientRequestType());
        payload.setClientRequestRequired(true);
        /*
        We should create client request only when there is sri account.
        But as aegon introduced this node as mandatory, so we currently always sent it for pre sales illustration.
        For other clients, we have clientRequestRequired flag to filter out this node in cbis side.
        This is mandatory field
        */
        payload.getClientRequest().setIllustrationType(ClientRequestIllustrationType.DEFAULT);
    }

    private void setTranches(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
            isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }
        
        IllustrationPayloadType.Tranches tranches = requestObjectFactory.createIllustrationPayloadTypeTranches();
        if (hasSIPPTransferInContribution(document)) {
            String productFlag = primaryProductType.getDetails().getProductFlag();
            for (SippTransferIn ti : document.getSippTransferIns()) {
                if ("P".equals(productFlag) || DrawdownIllustration.equals(illustrationSelectorEnum)) {
                    IllustrationTrancheType tranche = requestObjectFactory.createIllustrationTrancheType();
                    tranche.setAdditionalFunds(0);
                    tranche.setAdditionalTfc(0);
                    tranche.setGadMaxValue(0); //TODO set GAD maximum
                    tranche.setIncomeTaken(0.0); //TODO to be set in future
                    tranche.setLastReviewDate(GbstDateUtils.asXMLGregorianCalendar(LocalDate.now())); //TODO to be set
                    tranche.setReviewLimitsNow(false);
                    tranche.setType(2);
                    tranche.setCurrentValue(ti.getAmount().doubleValue());
                    tranche.setProtectedRights(false);
                    tranches.getTranche().add(tranche);
                }
            }
        }
        //This is mandatory node so even if 'tranches' is empty this should be set
        req.getIllustrationPayload().setTranches(tranches);
    }

    private ProductTypes.ProductType getProductType(Integer productTypeId) {
        ProductTypes productTypes = productService.getProductTypes(null, null, null, false, true);
        return productTypes.getProductType(productTypeId);
    }

    private void setContributions(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        IllustrationPayloadType.Contributions contributions = requestObjectFactory.createIllustrationPayloadTypeContributions();
        if (DRAWDOWN.equals(processType)) {
            /*
            NOTE: Assumption is that crystallised and uncrystallised amounts already calculated in the UI by considering regular/single/transfer contributions
             */
            if(isPartialImmediateDrawdown(document, processType) && DrawdownIllustration.equals(illustrationSelectorEnum)) {
                IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                contribution.setAmount(document.getCrystallisationDetails().getAmountToCrystallise().doubleValue());
                contribution.setContributionType(1); //Transfer
                contributions.getContribution().add(contribution);
            } else if (isPartialImmediateDrawdown(document, processType) && AccumulationIllustration.equals(illustrationSelectorEnum)) {
                IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                contribution.setAmount(document.getCrystallisationDetails().getUncrystallisedValue().doubleValue());
                contribution.setContributionType(1); //transfer - because this contribution is uncrys amount
                contributions.getContribution().add(contribution);

                includeRegularContributions(contributions, document, primaryProductType, processType, illustrationSelectorEnum, false, isISA);

            } else if (!isPartialImmediateDrawdown(document, processType) && !hasRegularContribution(document) && DrawdownIllustration.equals(illustrationSelectorEnum)) {
                IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                contribution.setAmount(document.getCrystallisationDetails().getAmountToCrystallise().doubleValue());
                contribution.setContributionType(1); //Transfer
                contributions.getContribution().add(contribution);
            } else if (!isPartialImmediateDrawdown(document, processType) && hasRegularContribution(document) && DrawdownIllustration.equals(illustrationSelectorEnum)) {
                IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                contribution.setAmount(document.getCrystallisationDetails().getAmountToCrystallise().doubleValue());
                contribution.setContributionType(1); //Transfer
                contributions.getContribution().add(contribution);
            } else if (!isPartialImmediateDrawdown(document, processType) && hasRegularContribution(document) && AccumulationIllustration.equals(illustrationSelectorEnum)) {
                includeRegularContributions(contributions, document, primaryProductType, processType, illustrationSelectorEnum, false, isISA);
            } else {
                throw new IllegalStateException("Cannot decide how to structure contributions in the request");
            }

        } else {
            //TODO Crystallisation details to be used in future
            boolean isSIPP = "SIPP".equalsIgnoreCase(primaryProductType.getDetails().getProductGrouping());
            //Regular contributions
            includeRegularContributions(contributions, document, primaryProductType, processType, illustrationSelectorEnum, isSIPP, isISA);

            if (hasSingleContribution(document)) {
                for (SingleContribution sc : document.getSingleContributions()) {
                    IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                    contribution.setAmount(sc.getAmount() != null ? sc.getAmount().doubleValue() : null);
                    if(!isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) &&
                            !isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
                        contribution.setStartDate(GbstDateUtils.asXMLGregorianCalendar(LocalDate.now()));
                    }
                    contribution.setContributionType(getContributorType(sc, isSIPP, isISA));
                    contributions.getContribution().add(contribution);
                }
            }

            if (hasSIPPTransferInContribution(document)) {
                String productFlag = primaryProductType.getDetails().getProductFlag();
                for (SippTransferIn ti : document.getSippTransferIns()) {
                    int contributionType = 1;
                    if ("A".equals(productFlag) && SippTransferTypeEnum.PensionCredit == ti.getTransferType()) {
                        contributionType = 6;
                    }
                    IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                    contribution.setContributionType(contributionType);
                    contribution.setAmount(ti.getAmount().doubleValue());
                    contributions.getContribution().add(contribution);
                }
            }

            if (hasISATransferInContribution(document)) {
                for (IsaTransferIn ti : document.getIsaTransferIns()) {
                    int contributionType = 1;
                    IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                    contribution.setContributionType(contributionType);
                    contribution.setAmount(ti.getAmount().doubleValue());
                    contributions.getContribution().add(contribution);
                }
            }
        }


        if (!contributions.getContribution().isEmpty()) {
            req.getIllustrationPayload().setContributions(contributions);
        }
    }

    private void includeRegularContributions(IllustrationPayloadType.Contributions contributions, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum selector, boolean isSIPP, boolean isISA) {

        if (hasRegularContribution(document)) {
            for (RegularContribution rc : document.getRegularContributions()) {
                IllustrationContributionType contribution = requestObjectFactory.createIllustrationContributionType();
                contribution.setAmount(rc.getAmount() != null ? rc.getAmount().doubleValue() : null);
                contribution.setStartDate(GbstDateUtils.asXMLGregorianCalendar(LocalDate.now()));
                contribution.setContributionType(getContributorType(rc, isSIPP, isISA));
                boolean escalationTypeNotApplicable = DrawdownIllustration.equals(selector) ||
                        (NEW_BUSINESS.equals(processType) && "P".equals(primaryProductType.getDetails().getProductFlag())
                        || !TRUE.equals(rc.isIndexByRPIFlag()));

                if(!escalationTypeNotApplicable) {
                    contribution.setEscalationType(2);
                }
                contribution.setEscalationValue(getEscalationValue(rc));
                contribution.setFrequency(getContributionFrequency(rc));
                contributions.getContribution().add(contribution);
            }
        }
    }


    private Integer getContributionFrequency(Contribution contribution) {
        if (contribution instanceof RegularContribution) {
            RegularContribution rc = (RegularContribution) contribution;
            if (rc.getFrequency() != null) {
                switch (rc.getFrequency()) {
                    case "Monthly":
                        return 1;
                    case "Quarterly":
                        return 3;
                    case "HalfYearly":
                        return 6;
                    case "Annually":
                        return 12;
                    default:
                        throw new IllegalArgumentException("Unsupported regular contribution frequency: " + rc.getFrequency());
                }
            } else {
                return 1; //Default
            }
        } else if (contribution instanceof SingleContribution) {
            return 0;
        }

        return null;
    }

    private BigDecimal getRegularContributionMultiplier(String rcFrequency) {
        if (rcFrequency != null) {
            switch (rcFrequency) {
                case "Monthly":
                    return BigDecimal.valueOf(12);
                case "Quarterly":
                    return BigDecimal.valueOf(4);
                case "HalfYearly":
                    return BigDecimal.valueOf(2);
                case "Annually":
                    return BigDecimal.ONE;
                default:
                    throw new IllegalArgumentException("Unsupported regular contribution frequency: " + rcFrequency);
            }
        } else {
            return BigDecimal.ONE; //Default
        }
    }

    private Double getEscalationValue(Contribution contribution) {
        String indexToUse = null;//TODO this is needed in future
        if (indexToUse != null) {
            //escalationType
            if (contribution instanceof RegularContribution) {
                if ("FIXED".equals(indexToUse)) {
                    //(deposit.getIndexPercentage() != null ? deposit.getIndexPercentage().doubleValue() : null);
                    //TODO need index percentage
                    return null;
                }
            }
        }
        return null;
    }

    private int getContributorType(Contribution contribution, boolean isSIPPProductGroup, boolean isISA) {
        /*
        if product grouping is SIPP and type of fund is Employer then cont. type is 2
        if product grouping is SIPP and type of fund is not Employer and tax relief is greater than max age then cont. type is 11
        if product grouping is SIPP and type of fund is not Employer and tax relief is NOT greater than max age then cont. type is 3
        if product grouping is NOT SIPP then cont. type is 0
         */
        if(isISA) {
            return 11;
        }
        if (ContributorTypeEnum.Employer.equals(contribution.getContributorType())) {
            return 2;
        } else if (ContributorTypeEnum.InvestorNoTaxRelief.equals(contribution.getContributorType())) {
            return 11;
        } else if (ContributorTypeEnum.Investor.equals(contribution.getContributorType())){
            return 3;
        } else {
            return 0;
        }

    }

    private void setTargetTfc(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isAccumulationNewBusiness(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isPartialDrawdownAccumulation(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isFullDrawdownAccumulation(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISAAccumulationNewBusiness(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isAccumulationTopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            // not applicable
            return;
        }
        IllustrationPayloadType payload = req.getIllustrationPayload();

        if (doc.getCrystallisationDetails() != null) {

            if (doc.getCrystallisationDetails().getPclsAmount() != null) {
                //Setting TFC amount
                if (ProcessType.CRYSTALLISE.equals(processType)) {
                    req.getIllustrationPayload().setTargetTfcAmount(0.0);
                } else {
                    req.getIllustrationPayload().setTargetTfcAmount(doc.getCrystallisationDetails().getPclsAmount().doubleValue());
                }

                //Note: The logic here is based on when "req.getQuoteType() == 0'
                //Setting TFC percentage
                if (DRAWDOWN.equals(processType)) { //There is no TFC in Quote object
                    payload.setTargetTfcPercentage(0d);
                } else {
                    //To avoid calling cbis for product list unnecessarily, added this to 'else' statement
                    String productTypeFlag = primaryProductType.getDetails().getProductFlag();
                    if (!"P".equals(productTypeFlag) && !"A".equals(productTypeFlag)) {
                        payload.setTargetTfcPercentage(0d);
                    }
                }
            }
        }
    }

    private void setIncomeOptions(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        // Set default values
        IllustrationPayloadType payload = req.getIllustrationPayload();

        if(!(isPartialDrawdownAccumulation(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isFullDrawdownAccumulation(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isAccumulationNewBusiness(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISAAccumulationNewBusiness(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isAccumulationTopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA))) {
            payload.setIncomeFrequency(12);
            payload.setIncomeAmount(0.0);
        }

        if(!(isISATopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isAccumulationTopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA))) {
            payload.setTargetIncomeType(0);
            payload.setIncomeStartDate(payload.getPlanStartDate());
        }
        /*
        TODO
        More fields need to be set if there is 'withdrawal', crystallisation details and or pension product
         */
        if(DrawdownIllustration.equals(illustrationSelectorEnum) ||
                (NEW_BUSINESS.equals(processType) && "P".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag()))) {
            //Louise: flexible income is always true for Vitality we may change it later on for other clients
            payload.setFlexibleIncome(true);
            payload.setTargetIncomeType(2);
            if(doc.getCrystallisationDetails() != null && doc.getDrawdownIncome() != null) {
                if(doc.getDrawdownIncome().getFrequency() != null) {
                    payload.setIncomeFrequency(getFrequency(doc.getDrawdownIncome().getFrequency()));
                } else {
                    payload.setIncomeFrequency(12);
                }

                if(doc.getDrawdownIncome().getAmount() != null) {
                    payload.setIncomeAmount(doc.getDrawdownIncome().getAmount().doubleValue());
                } else {
                    payload.setIncomeAmount(0.0D);
                }
            }
        }
    }

    private Integer getFrequency(String frequency) {
        switch (frequency) {
            case "Monthly":
                return 1;
            case "Quarterly":
                return 3;
            case "HalfYearly":
                return 6;
            case "Annually":
                return 12;
            default:
                throw new IllegalArgumentException("Unsupported frequency: " + frequency);
        }
    }

    private void setMixedContribution(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        if(isAccumulationTopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, document, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }
        req.getIllustrationPayload().setMixedContribution(isMixedContribution(document));
    }

    private void setProductCharges(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        IllustrationPayloadType.ProductCharges productCharges = requestObjectFactory.createIllustrationPayloadTypeProductCharges();

        /*
        * Comment from Cweb:
        * If commission is Pound Based
        *    then 'initial commission' and 'trail commission' will also be sent to Imago with value set to 0
        * else if commission is percentage based
        *    then 'pound based commission' will not be sent.
        */
        //NOTE: In CW when the amount is present, we send fixed comm charge and when percentage is present we send as trail comm charge

        //Trail charge (ongoing charge)
        IllustrationChargesType charge = requestObjectFactory.createIllustrationChargesType();
        if(!isAccumulationTopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) &&
                !isISATopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            charge.setChargeTypeCode(TRAIL_COMM_CHARGE_TYPE_CODE);
            charge.setDescription(settings.getTrailCommissionDesc());
            double trailCharge = 0d;
            if (doc.getOngoingAdviserChargePercent() != null) {
                charge.setCalculationType(BigInteger.ZERO);
                trailCharge = doc.getOngoingAdviserChargePercent().doubleValue();
            } else if (doc.getOngoingAdviserChargeAmount() != null) {
                charge.setCalculationType(BigInteger.ONE);
                trailCharge = doc.getOngoingAdviserChargeAmount().doubleValue();
            }
            charge.setChargeValue(trailCharge);
            if (doc.getOngoingAdviserChargeFrequency() != null) {
                Integer annualised = annualise(doc.getOngoingAdviserChargeFrequency());
                charge.setFrequency(new BigInteger(String.valueOf(Integer.valueOf(12 / annualised))));
            } else {
                //If null, default is Monthly
                charge.setFrequency(new BigInteger(String.valueOf(Integer.valueOf(1))));
            }
            productCharges.getCharge().add(charge);
        }

        addInitialAdviserChargeTransfer(productCharges, doc);

        if (hasRegularContribution(doc)) {
            addInitialAdviserChargeRegular(productCharges, doc);
        }

        if (hasSingleContribution(doc)) {
            addInitialAdviserChargeSingle(productCharges, doc);
        }

        req.getIllustrationPayload().setProductCharges(productCharges);
    }

    private Integer annualise(String frequency) {
        switch (frequency) {
            case "Monthly":
                return 12;
            case "Quarterly":
                return 4;
            case "HalfYearly":
                return 2;
            case "Annually":
                return 1;
        }
        throw new IllegalArgumentException("Invalid frequency: " + frequency);

    }

    private boolean isAccumulationNewBusiness(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return NEW_BUSINESS.equals(processType) && "A".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag());
    }

    private boolean isDrawdownNewBusiness(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return NEW_BUSINESS.equals(processType) && "P".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag());
    }

    private boolean isPartialDrawdownAccumulation(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return DRAWDOWN.equals(processType) &&
                AccumulationIllustration.equals(illustrationSelectorEnum) &&
                isPartialImmediateDrawdown(document, processType);
    }

    private boolean isPartialDrawdownDrawdown(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return DRAWDOWN.equals(processType) &&
                DrawdownIllustration.equals(illustrationSelectorEnum) &&
                isPartialImmediateDrawdown(document, processType);
    }

    private boolean isFullDrawdownAccumulation(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return DRAWDOWN.equals(processType) &&
                AccumulationIllustration.equals(illustrationSelectorEnum) &&
                isFullImmediateDrawdown(document, processType);
    }

    private boolean isFullDrawdownDrawdown(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return DRAWDOWN.equals(processType) &&
                DrawdownIllustration.equals(illustrationSelectorEnum) &&
                isFullImmediateDrawdown(document, processType);
    }

    private boolean isISAAccumulationNewBusiness(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return isISA && NEW_BUSINESS.equals(processType);
    }

    private boolean isISATopUp(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return isISA && TOPUP.equals(processType);
    }

    private boolean isAccumulationTopUp(RequestIllustrationType req, DocumentAttributes document, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        return TOPUP.equals(processType) && "A".equalsIgnoreCase(primaryProductType.getDetails().getProductFlag());
    }

    private String getDescription(String freq) {
        switch (freq) {
            case "Monthly":
                return "Monthly";
            case "Quarterly":
                return "Quarterly";
            case "HalfYearly":
                return "Half Yearly";
            case "Annually":
                return "Annually";
        }
        throw new IllegalArgumentException("Invalid frequency: " + freq);
    }

    private void addInitialAdviserChargeTransfer(IllustrationPayloadType.ProductCharges productCharges, DocumentAttributes doc) {

        Optional<BigDecimal> totalAmount;
        Optional<BigDecimal> totalPercentage;
        // The assumption is that we either have ISA transfer-in ot SIPP and not both at the same time
        if (hasSIPPTransferInContribution(doc)) {
            totalAmount = doc.getSippTransferIns().stream().filter(a -> a.getInitialChargeAmount() != null).map(Application::getInitialChargeAmount).reduce(BigDecimal::add);
            totalPercentage = doc.getSippTransferIns().stream().filter(a -> a.getInitialChargePercent() != null).map(Application::getInitialChargePercent).reduce(BigDecimal::add);
        } else if (hasISATransferInContribution(doc)) {
            totalAmount = doc.getIsaTransferIns().stream().filter(a -> a.getInitialChargeAmount() != null).map(Application::getInitialChargeAmount).reduce(BigDecimal::add);
            totalPercentage = doc.getIsaTransferIns().stream().filter(a -> a.getInitialChargePercent() != null).map(Application::getInitialChargePercent).reduce(BigDecimal::add);
        } else {
            //No transfer-in, no charges
            return;
        }

        if(totalAmount.isPresent() && doc.getTransferInInitialChargeAmount() != null) {
            totalAmount = Optional.of(totalAmount.get().add(doc.getTransferInInitialChargeAmount()));
        } else if (!totalAmount.isPresent() && doc.getTransferInInitialChargeAmount() != null) {
            totalAmount = Optional.of(doc.getTransferInInitialChargeAmount());
        }

        if(totalPercentage.isPresent() && doc.getTransferInInitialChargePercent() != null) {
            totalPercentage = Optional.of(totalPercentage.get().add(doc.getTransferInInitialChargePercent()));
        } else if (!totalPercentage.isPresent() && doc.getTransferInInitialChargePercent() != null) {
            totalPercentage = Optional.of(doc.getTransferInInitialChargePercent());
        }

        if (totalAmount.isPresent() && totalPercentage.isPresent() && totalAmount.get().doubleValue() > 0 && totalPercentage.get().doubleValue() > 0) {
            //making sure amounts and percents haven't been mixed
            throw new IllegalStateException("All the charges must be either percentage based or amount based");
        }

        IllustrationChargesType transferCharge = requestObjectFactory.createIllustrationChargesType();
        transferCharge.setDescription(settings.getTransferCommissionDesc());
        transferCharge.setChargeTypeCode(TRANSFER_COMM_CHARGE_TYPE_CODE);

        totalAmount.ifPresent(amount -> {
            if (BigDecimal.ZERO.compareTo(amount) < 0) {
                transferCharge.setChargeValue(amount.doubleValue());
                transferCharge.setCalculationType(BigInteger.valueOf(1));
                productCharges.getCharge().add(transferCharge);
            }
        });
        totalPercentage.ifPresent(percentage -> {
            if (BigDecimal.ZERO.compareTo(percentage) < 0) {
                transferCharge.setCalculationType(BigInteger.valueOf(0));
                transferCharge.setChargeValue(percentage.doubleValue());
                productCharges.getCharge().add(transferCharge);
            }
        });

    }

    private void addInitialAdviserChargeSingle(IllustrationPayloadType.ProductCharges productCharges, DocumentAttributes doc) {
        Optional<BigDecimal> totalAmount = doc.getSingleContributions().stream().filter(a -> a.getInitialChargeAmount() != null).map(Application::getInitialChargeAmount).reduce(BigDecimal::add);
        Optional<BigDecimal> totalPercentage = doc.getSingleContributions().stream().filter(a -> a.getInitialChargePercent() != null).map(Application::getInitialChargePercent).reduce(BigDecimal::add);

        if(totalAmount.isPresent() && doc.getSingleInitialChargeAmount() != null) {
            totalAmount = Optional.of(totalAmount.get().add(doc.getSingleInitialChargeAmount()));
        } else if (!totalAmount.isPresent() && doc.getSingleInitialChargeAmount() != null) {
            totalAmount = Optional.of(doc.getSingleInitialChargeAmount());
        }

        if(totalPercentage.isPresent() && doc.getSingleInitialChargePercent() != null) {
            totalPercentage = Optional.of(totalPercentage.get().add(doc.getSingleInitialChargePercent()));
        } else if (!totalPercentage.isPresent() && doc.getSingleInitialChargePercent() != null) {
            totalPercentage = Optional.of(doc.getSingleInitialChargePercent());
        }

        if (totalAmount.isPresent() && totalPercentage.isPresent() && totalAmount.get().doubleValue() > 0 && totalPercentage.get().doubleValue() > 0) {
            //making sure amounts and percents haven't been mixed
            throw new IllegalStateException("All the charges must be either percentage based or amount based");
        }

        IllustrationChargesType transferCharge = requestObjectFactory.createIllustrationChargesType();
        transferCharge.setDescription(settings.getSingleCommissionDesc());
        transferCharge.setChargeTypeCode(SINGLE_COMM_CHARGE_TYPE_CODE);

        totalAmount.ifPresent(amount -> {
            if (BigDecimal.ZERO.compareTo(amount) < 0) {
                transferCharge.setChargeValue(amount.doubleValue());
                transferCharge.setCalculationType(BigInteger.ONE);
                productCharges.getCharge().add(transferCharge);
            }
        });
        totalPercentage.ifPresent(percentage -> {
            if (BigDecimal.ZERO.compareTo(percentage) < 0) {
                transferCharge.setChargeValue(percentage.doubleValue());
                transferCharge.setCalculationType(BigInteger.ZERO);
                productCharges.getCharge().add(transferCharge);
            }
        });

    }

    private void addInitialAdviserChargeRegular(IllustrationPayloadType.ProductCharges productCharges, DocumentAttributes doc) {
        Optional<BigDecimal> totalAmount = doc.getRegularContributions().stream().filter(a -> a.getInitialChargeAmount() != null).map(Application::getInitialChargeAmount).reduce(BigDecimal::add);
        Optional<BigDecimal> totalPercentage = doc.getRegularContributions().stream().filter(a -> a.getInitialChargePercent() != null).map(Application::getInitialChargePercent).reduce(BigDecimal::add);

        if(totalAmount.isPresent() && doc.getRegularInitialChargeAmount() != null) {
            totalAmount = Optional.of(totalAmount.get().add(doc.getRegularInitialChargeAmount()));
        } else if (!totalAmount.isPresent() && doc.getRegularInitialChargeAmount() != null) {
            totalAmount = Optional.of(doc.getRegularInitialChargeAmount());
        }

        if(totalPercentage.isPresent() && doc.getRegularInitialChargePercent() != null) {
            totalPercentage = Optional.of(totalPercentage.get().add(doc.getRegularInitialChargePercent()));
        } else if (!totalPercentage.isPresent() && doc.getRegularInitialChargePercent() != null) {
            totalPercentage = Optional.of(doc.getRegularInitialChargePercent());
        }

        if (totalAmount.isPresent() && totalPercentage.isPresent() && totalAmount.get().doubleValue() > 0 && totalPercentage.get().doubleValue() > 0) {
            //making sure amounts and percents haven't been mixed
            throw new IllegalStateException("All the charges must be either percentage based or amount based");
        }

        IllustrationChargesType regularCharge = requestObjectFactory.createIllustrationChargesType();
        regularCharge.setDescription(settings.getTrailCommissionDesc());
        regularCharge.setChargeTypeCode(TRAIL_COMM_CHARGE_TYPE_CODE);

        final boolean endMonth = doc.getRegularInitialChargeTerm() != null;

        totalAmount.ifPresent(amount -> {
            if (BigDecimal.ZERO.compareTo(amount) < 0) {
                regularCharge.setCalculationType(BigInteger.ONE);
                regularCharge.setChargeValue(amount.doubleValue());
                regularCharge.setEndMonth(endMonth ? new BigInteger("" + doc.getRegularInitialChargeTerm()) : null);
                productCharges.getCharge().add(regularCharge);
            }
        });
        totalPercentage.ifPresent(percentage -> {
            if (BigDecimal.ZERO.compareTo(percentage) < 0) {
                regularCharge.setCalculationType(BigInteger.ZERO);
                regularCharge.setEndMonth(endMonth ? new BigInteger("" + doc.getRegularInitialChargeTerm()) : null);
                regularCharge.setChargeValue(percentage.doubleValue());
                productCharges.getCharge().add(regularCharge);
            }
        });


    }

    private boolean isMixedContribution(DocumentAttributes doc) {
        //TODO later we need to check if this isn't CashISA
        return hasSingleContribution(doc) && hasRegularContribution(doc);
    }

    private boolean hasSingleContribution(DocumentAttributes illustrationDocument) {
        return illustrationDocument.getSingleContributions() != null && !illustrationDocument.getSingleContributions().isEmpty();
    }

    private boolean hasRegularContribution(DocumentAttributes illustrationDocument) {
        return illustrationDocument.getRegularContributions() != null && !illustrationDocument.getRegularContributions().isEmpty();
    }

    private boolean hasSIPPTransferInContribution(DocumentAttributes illustrationDocument) {
        return illustrationDocument.getSippTransferIns() != null && !illustrationDocument.getSippTransferIns().isEmpty();
    }

    private boolean hasISATransferInContribution(DocumentAttributes illustrationDocument) {
        return illustrationDocument.getIsaTransferIns() != null && !illustrationDocument.getIsaTransferIns().isEmpty();
    }

    private void setPersonalDetails(RequestIllustrationType req, DocumentAttributes doc, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        IllustrationPayloadType payload = req.getIllustrationPayload();
        payload.setMemberDetails(requestObjectFactory.createIllustrationPayloadTypeMemberDetails());
        payload.getMemberDetails().setAdviserAccountId(Integer.parseInt(doc.getAdviserId()));
        payload.getMemberDetails().setPersonalDetails(requestObjectFactory.createIllustrationPersonalDetailsType());
        XMLGregorianCalendar dob = GbstDateUtils.asXMLGregorianCalendar(doc.getInvestorDateOfBirth());
        if (dob == null) {
            //source: CW
            dob = GbstDateUtils.asXMLGregorianCalendar(LocalDate.of(1900, 1, 1));
        }
        payload.getMemberDetails().getPersonalDetails().setDateOfBirth(dob);
        payload.getMemberDetails().getPersonalDetails().setFirstName(doc.getInvestorFirstName());
        payload.getMemberDetails().getPersonalDetails().setSurname(doc.getInvestorLastName());
        payload.getMemberDetails().getPersonalDetails().setTitle(doc.getInvestorTitle());
        GenderCharType gender = doc.getInvestorGender() == null ? GenderCharType.N : doc.getInvestorGender() == GenderEnum.Male ? GenderCharType.M : GenderCharType.F;
        payload.getMemberDetails().getPersonalDetails().setGender(gender);

        if(hasSingleContribution(doc)) {
            Optional<SingleContribution> contribution = doc.getSingleContributions().stream().filter(c -> ContributorTypeEnum.Investor.equals(c.getContributorType())).findFirst();
            if(contribution.isPresent() && contribution.get().getGrossAnnualSalary() != null) {
                payload.getMemberDetails().getPersonalDetails().setGrossSalary(contribution.get().getGrossAnnualSalary().doubleValue());
            }
        }

        //TODO CW checks and sets only if the second investor is of type Spouse. Here we don't know who is the dependent

        // Now determine if there is a joint account. If so, add the secondary entity to the spouse details.
        if (doc.getDependantDateOfBirth() != null && doc.getDependantGender() != null) { //TODO How do we know there is Spouse?
            //Note: if there is Dependent pension percent, the percentage is to be set in setAnnuities()
            //CW: the second investor is not always (as per the previous implementation) the spouse details since the order in the investor list cannot be guaranteed.
            IllustrationPersonalDetailsType spouseDetails = requestObjectFactory.createIllustrationPersonalDetailsType();
            GenderCharType spouseGender = doc.getDependantGender() == GenderEnum.Male ? GenderCharType.M : GenderCharType.F;
            spouseDetails.setGender(spouseGender);

            XMLGregorianCalendar spouseDob = GbstDateUtils.asXMLGregorianCalendar(doc.getDependantDateOfBirth());
            spouseDetails.setDateOfBirth(spouseDob);

            payload.getMemberDetails().setSpouseDetails(spouseDetails);
        }

        if (hasSIPPTransferInContribution(doc)) {
            Optional<SippTransferIn> transferIn = doc.getSippTransferIns().stream().filter(t -> t.getProtectedAge() != null).findFirst();
            transferIn.ifPresent(t -> payload.getMemberDetails().getPersonalDetails().setProtectedAge(t.getProtectedAge()));
        }
    }

    private void setQuoteType(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        //  NB, TOPUP
        if (NEW_BUSINESS.equals(processType) ||
                TOPUP.equals(processType)) {
            /*
            Account account = cwPayload.getCurrentWorkingAccount();
            if(ProductType.PRODUCT_FLAG_ACCUMULATION.equals(getProductFlag(account.getComposerProductTypeId()))) {
             */
            String productTypeFlag = primaryProductType.getDetails().getProductFlag();
            if("A".equals(productTypeFlag)) {
                // if process type is drawdown then 0 - Savings/Full Drawdown
                // pre-retirement
                req.getIllustrationPayload().setQuoteType(4);
                // if drawdown then assume its 8 - drawdown transfer
            } else if("P".equals(productTypeFlag)) {
                req.getIllustrationPayload().setQuoteType(8);
            } else if("I".equals(productTypeFlag) && isISA) {
                req.getIllustrationPayload().setQuoteType(4);
            } else {
                req.getIllustrationPayload().setQuoteType(0);
            }
        }
        // if crystallisation use Review quote type.
        else if (ProcessType.CRYSTALLISE.equals(processType)) {
            req.getIllustrationPayload().setQuoteType(6);
        } else if(DRAWDOWN.equals(processType)) {
            if(AccumulationIllustration.equals(illustrationSelectorEnum)) {
                req.getIllustrationPayload().setQuoteType(4);
            } else if (DrawdownIllustration.equals(illustrationSelectorEnum)) {
                if(isPartialImmediateDrawdown(doc, processType)) {
                    req.getIllustrationPayload().setQuoteType(8);
                } else {
                    req.getIllustrationPayload().setQuoteType(0);
                }
            }
        } else {
            // default is 0 - Savings
            req.getIllustrationPayload().setQuoteType(0);
        }

        //special cases that override above values goe here


    }

    private boolean isISA(DocumentAttributes document) {
        return productService.isISA(document.getProductTypeId() + "");
    }

    private boolean isPartialImmediateDrawdown(DocumentAttributes doc, ProcessType processType) {
        return DRAWDOWN.equals(processType) && doc.getCrystallisationDetails() != null && !doc.getCrystallisationDetails().getCrystalliseFullAmountFlag();
    }

    private boolean isFullImmediateDrawdown(DocumentAttributes doc, ProcessType processType) {
        return DRAWDOWN.equals(processType) && doc.getCrystallisationDetails() != null && doc.getCrystallisationDetails().getCrystalliseFullAmountFlag();
    }

    private void setAnnuities(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {
        setFinalAnnuityDate(req, doc, processType);

        IllustrationPayloadType payload = req.getIllustrationPayload();
        //set defaults
        payload.setAnnuityFrequency(1);
        payload.setAnnuityEscalationType(0);
        payload.setAnnuityEscalation(0.0);
        payload.setAnnuityGuaranteePeriod(5);
        payload.setAnnuitySpousePension(0.5);
        payload.setAnnuityTiming(0);
        if (doc.getAnnuityFrequency() != null) {
            payload.setAnnuityFrequency(doc.getAnnuityFrequency().getMonthValue());
        }
        if (doc.getAnnuityEscalation() != null && BigDecimal.ZERO.compareTo(doc.getAnnuityEscalation()) < 0) {
            payload.setAnnuityEscalation(doc.getAnnuityEscalation().doubleValue());
            payload.setAnnuityEscalationType(4);
        }
        if (doc.getAnnuityGuarantee() != null) {
            //TODO this seems to be int not BigDecimal
            payload.setAnnuityGuaranteePeriod(doc.getAnnuityGuarantee().intValue());
        }

        if (doc.getDependantPensionPercent() != null) {
            payload.setAnnuitySpousePension(doc.getDependantPensionPercent().doubleValue());
        }

        if (AnnuityTimingEnum.InAdvance.equals(doc.getAnnuityTiming())) { //In Advance
            payload.setAnnuityTiming(0);
        } else if (AnnuityTimingEnum.InArrears.equals(doc.getAnnuityTiming())) { // In Arrears
            payload.setAnnuityTiming(1);
        }
    }

    private void setFinalAnnuityDate(RequestIllustrationType req, DocumentAttributes doc, ProcessType processType) {
        // set preferred retirement age
        Integer retirementAge = doc.getInvestorExpectedRetirementAge();
        if (retirementAge != null) {
            if (doc.getInvestorDateOfBirth() != null) {
                // first need to calculate the Preferred Retirement Date (PRD) which is DOB + PRA
                LocalDate retirementDate = doc.getInvestorDateOfBirth().plusYears(retirementAge);

                // now check if the PRD is after today
                if (retirementDate.compareTo(getToday()) < 0) { //meaning: if ret date 'less than' today
                    //PRD is on or before the quote date then
                    //the final annuity date for illustrations should be set to the PRD + 10 years
                    req.getIllustrationPayload().setFinalAnnuityDate(GbstDateUtils.asXMLGregorianCalendar(doc.getInvestorDateOfBirth().plusYears(retirementAge + 10)));
                } else {
                    req.getIllustrationPayload().setFinalAnnuityDate(GbstDateUtils.asXMLGregorianCalendar(doc.getInvestorDateOfBirth().plusYears(retirementAge)));
                }
            }
        }
    }

    public LocalDate getToday() {
        //Created this to avoid unit tests doing check again current date which make them fail at some point
        return LocalDate.now();
    }

    private void setProtectionOptions(RequestIllustrationType req, DocumentAttributes doc, ProductTypes.ProductType primaryProductType, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum, boolean isISA) {

        if(isAccumulationTopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA) ||
                isISATopUp(req, doc, primaryProductType, processType, illustrationSelectorEnum, isISA)) {
            return;
        }

        IllustrationProtectionType protectionDetails = requestObjectFactory.createIllustrationProtectionType();

        // Set the type and SSLS to 0. These will be overridden in setContributions() if applicable.
        protectionDetails.setType(0);
        protectionDetails.setSsls(0.0);

        protectionDetails.setEnhancedProtection(false);
        protectionDetails.setPrimaryProtection(0);
        protectionDetails.setEnhancedTfc(0.0);
        protectionDetails.setLtaEnhancement(0.0);
        protectionDetails.setProtectedTfc(0.0);

        if (doc.getProtection() != null) {
            if (doc.getProtection().getFixedProtection() != null && doc.getProtection().getFixedProtection().getYear() != null) {
                switch (doc.getProtection().getFixedProtection().getYear()) {
                    case "2012":
                        protectionDetails.setType(3);
                        break;
                    case "2014":
                        protectionDetails.setType(4);
                        break;
                    case "2016":
                        protectionDetails.setType(6);
                        break;
                }
            } else if (doc.getProtection().getIndividualProtection() != null) {
                protectionDetails.setPla(doc.getProtection().getIndividualProtection().getAmount());
                if (doc.getProtection().getIndividualProtection().getYear() != null) {
                    switch (doc.getProtection().getIndividualProtection().getYear()) {
                        case "2014":
                            protectionDetails.setType(5);
                            break;
                        case "2016":
                            protectionDetails.setType(7);
                            break;
                    }
                }

            }

            /*
            TODO the following types to be done later
            if(QuoteProtectionType.PENSION == investor.getProtectionType())
            {
                // set scheme specific to 0.
                protectionDetails.setSsls(0.0);

                // set to A-day protection
                protectionDetails.setType(2);

                // primary protection
                if(LTAProtectionType.PRIMARY == investor.getLtaProtection())
                {
                    protectionDetails.setPrimaryProtection(1);
                }

                // set protected pcls if available otherwise assume primary prot is none.
                if(investor.getRetirementProtectedPcls()!=null)
                {
                    protectionDetails.setProtectedTfc(investor.getRetirementProtectedPcls().doubleValue());
                }

                // set lta enhancment factor.
                if(investor.getLtaEnhancementFactor()!=null)
                {
                    protectionDetails.setLtaEnhancement(investor.getLtaEnhancementFactor().doubleValue());
                }

                // if enhanced tax free cash is set then assume enhanced protection.
                if(investor.getEnhancedTaxFreeCash()!=null)
                {
                    protectionDetails.setEnhancedProtection(true);
                    protectionDetails.setEnhancedTfc(investor.getEnhancedTaxFreeCash().doubleValue());
                }

            }

            else if(QuoteProtectionType.SCHEME_SPECIFIC == investor.getProtectionType() && account != null)
            {
                protectionDetails.setType(1);
                protectionDetails.setSsls(account.getSchemeSpecificLumpSum().doubleValue());
            }
             */
        }

        req.getIllustrationPayload().setProtection(protectionDetails);

    }
}