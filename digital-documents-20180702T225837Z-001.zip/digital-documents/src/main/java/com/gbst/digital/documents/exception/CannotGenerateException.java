package com.gbst.digital.documents.exception;

/**
 * Created by Aman Verma on 08/03/2018.
 */
public class CannotGenerateException extends Exception {
    public CannotGenerateException(String message) {
        super(message);
    }
}
