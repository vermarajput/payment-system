package com.gbst.digital.documents.resource.model.document;

import com.gbst.digital.documents.resource.model.document.types.ContributorTypeEnum;

/**
 * @author rekhar on 25/09/2017
 */
public class Contribution extends Application{

    private ContributorTypeEnum contributorType;

    public Contribution() {
    }

    public ContributorTypeEnum getContributorType() {
        return contributorType;
    }

    public void setContributorType(ContributorTypeEnum contributorType) {
        this.contributorType = contributorType;
    }
}
