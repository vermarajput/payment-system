package com.gbst.digital.documents.resource.model.document;

import java.time.LocalDate;

/**
 * @author nehas
 */
public class ApplicationDetails {

    private Boolean planSetUpOptOutFlag;
    private Boolean planSetUpNonJoiningFlag;
    private Boolean flexiblyAccessedPensionFlag;
    private LocalDate flexiblyAccessedPensionDate;

    public Boolean getPlanSetUpOptOutFlag() {
        return planSetUpOptOutFlag;
    }

    public void setPlanSetUpOptOutFlag(Boolean planSetUpOptOutFlag) {
        this.planSetUpOptOutFlag = planSetUpOptOutFlag;
    }

    public Boolean getPlanSetUpNonJoiningFlag() {
        return planSetUpNonJoiningFlag;
    }

    public void setPlanSetUpNonJoiningFlag(Boolean planSetUpNonJoiningFlag) {
        this.planSetUpNonJoiningFlag = planSetUpNonJoiningFlag;
    }

    public Boolean getFlexiblyAccessedPensionFlag() {
        return flexiblyAccessedPensionFlag;
    }

    public void setFlexiblyAccessedPensionFlag(Boolean flexiblyAccessedPensionFlag) {
        this.flexiblyAccessedPensionFlag = flexiblyAccessedPensionFlag;
    }

    public LocalDate getFlexiblyAccessedPensionDate() {
        return flexiblyAccessedPensionDate;
    }

    public void setFlexiblyAccessedPensionDate(LocalDate flexiblyAccessedPensionDate) {
        this.flexiblyAccessedPensionDate = flexiblyAccessedPensionDate;
    }
}
