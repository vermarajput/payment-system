package com.gbst.digital.documents.resource.model.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * Stores the various storage systems to be supported
 * @author nehas
 */

public enum StorageSystemEnum implements GBSTEnumable<String>
{
    S3("S3"),
    FILESYSTEM("FILESYSTEM"),
    CMISDMS("CMISDMS");

    private String value;

    StorageSystemEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

}