package com.gbst.digital.documents.generator.json.cie;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.cbis.WSFault;
import com.gbst.common.cbis.WSFaultHelper;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.exception.CannotGenerateException;
import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.utils.IllustrationRequestBuilder;
import com.gbst.digital.documents.utils.IllustrationSelectorEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import com.infocomp.cbis.uk.response.IllustrationResponseType;
import com.infocomp.cbis.uk.response.ResponseDetailType;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;

import javax.naming.OperationNotSupportedException;
import javax.xml.bind.JAXBElement;
import java.io.ByteArrayOutputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Aman Verma on 11/10/2017.
 *
 * @author Mohammad Norouzi
 */
@Profile("illustration")
@ConditionalOnProperty(value = "gbst.digital.documents.types.illustration", havingValue = "CIE")
@Service
public class IllustrationDocumentGenerator implements DocumentGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(IllustrationDocumentGenerator.class);

    @Autowired
    WebServiceTemplate webServiceTemplate;

    @Autowired
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Autowired
    IllustrationRequestBuilder illustrationRequestBuilder;

    @Autowired
    protected ObjectMapper mapper;
    
    /**
     * Returns multiple Illustration documents where applicable.
     *
     * @param documentWithParameter
     * @param documentAttributes
     * @param payload
     * @return
     */
    private List<DocumentWithParameter> generateDocuments(DocumentGeneration documentWithParameter, DocumentAttributes documentAttributes, DocumentPayload payload) {
        List<DocumentWithParameter> illustrationResponse = new ArrayList<>();
        ProcessType processType = getProcessType(documentWithParameter.getProcessType());
        IllustrationSelectorEnum[] types = illustrationRequestBuilder.getDocumentTypesRequired(documentAttributes, processType);

        for(IllustrationSelectorEnum type : types) {
            illustrationResponse.add(generateDocRequest(documentWithParameter, payload, documentAttributes, processType, type));
        }

        return illustrationResponse;
    }

    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {

        if (!payload.isJson()) {
            return false;
        }
        DocumentForConfig config = payload.getDocumentForConfig();
        if (!GenerationStrategyEnum.ILLUSTRATION.getValue().equals(config.getGenerationStrategy())) {
            LOGGER.debug("Document generation strategy [" + config.getGenerationStrategy() + "] should be ILLUSTRATION.");
            return false;
        }

        //check other businessValidation and if not valid as per config then return false and this handler is ignored
        return (Arrays.asList(
                DocumentTypeEnum.PRE_SALE_ILLUSTRATION.name(),
                DocumentTypeEnum.PRE_SALE_ILLUSTRATION_SINGLE.name(),
                DocumentTypeEnum.PRE_SALE_ILLUSTRATION_REGULAR.name(),
                DocumentTypeEnum.STATIC_GENERIC_ILLUSTRATION.name(),
                DocumentTypeEnum.ADHOC_ADVISER_CHARGE_ILLUSTRATION.name()
        ).contains(config.getDocumentName()));

    }

    @Override
    public void validate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        try {
            ProcessType.valueOf(document.getProcessType());
        } catch (IllegalArgumentException e) {
            throw new DocumentGenerationException("Invalid Process Type [" + document.getProcessType() + "]");
        }
    }


    @Override
    public List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        DocumentAttributes documentAttributes;
        try {
            documentAttributes = mapper.readValue(payload.getSource(), DocumentAttributes.class);
        } catch (Exception e) {
            LOGGER.error("Error while generating document", e);
            throw new DocumentGenerationException("Invalid input could not be processed to DocumentAttributes: " + payload, e);
        }

        return generateDocuments(document, documentAttributes, payload);
    }

    private DocumentWithParameter generateDocRequest(DocumentGeneration documentWithParameter, DocumentPayload payload, DocumentAttributes documentAttributes, ProcessType processType, IllustrationSelectorEnum illustrationSelectorEnum) {
        RequestIllustrationType request = illustrationRequestBuilder.buildRequestIllustrationType(documentAttributes, processType, illustrationSelectorEnum);
        return processIllustrationRequest(documentWithParameter, payload, request, illustrationSelectorEnum);
    }

    private DocumentWithParameter processIllustrationRequest(DocumentGeneration documentGeneration, DocumentPayload payload, RequestIllustrationType request, IllustrationSelectorEnum illustrationSelectorEnum) {
        DocumentWithParameter documentWithParameter = createAndInitialiseDocumentWithParameter(documentGeneration, payload, illustrationSelectorEnum);
        try {
            JAXBElement<IllustrationResponseType> response = (JAXBElement<IllustrationResponseType>) webServiceTemplate.marshalSendAndReceive(multiUrlConnectionSettings.getConnections().get(Services.CBIS).getUrl(), (Object) illustrationRequestBuilder.createRequestIllustration(request));

            if (response.getValue() != null && response.getValue().getResponseDetails() != null &&
                    response.getValue().getResponseDetails().getResponseDetail() != null) {

                for (ResponseDetailType d : response.getValue().getResponseDetails().getResponseDetail()) {
                    //TODO not clear how to handle multiple files. Do we even have multiple files?
                    if (d.getIllustrationPdfStream() != null && d.getIllustrationPdfStream().getFile() != null) {
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        d.getIllustrationPdfStream().getFile().writeTo(baos);

                        documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATED);
                        documentWithParameter.getDocument().setGeneratedDate(Instant.now());
                        documentWithParameter.setGeneratedDocumentStream(baos);
                        return documentWithParameter;
                    } else if (d.getIllustrationFileUrl() != null) {
                        throw new OperationNotSupportedException("File URL is not supported");
                    }
                }
            }

        } catch (SoapFaultClientException x) {
            WSFault fault = WSFaultHelper.getWSFault(x);
            LOGGER.error("An error occurred while calling CBIS: " + fault.toString(), x);
        } catch (Exception x) {
            LOGGER.error("An error occurred while calling CBIS", x);
        }

        documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
        return documentWithParameter;
    }

    private ProcessType getProcessType(String processType) {
        return ProcessType.valueOf(processType);
    }

    /**
     * Base on IllustartioSelector, the documentName and documentDisplayname as updated,
     * additionally, the key is reassigned to avoid multiple documents having same key.
     *
     * @param orgDocWithParameter
     * @param illustrationSelectorEnum
     * @return
     */
    private DocumentWithParameter createAndInitialiseDocumentWithParameter(DocumentGeneration orgDocWithParameter, DocumentPayload payload, IllustrationSelectorEnum illustrationSelectorEnum) {
        DocumentWithParameter documentWithParameter = DocumentWithParameter.createDocumentWithParameter(orgDocWithParameter, payload.getDocumentForConfig());
        String currentDocumentName = documentWithParameter.getDocument().getDocumentName();
        String currentDocumentDisplayName = documentWithParameter.getDocument().getDocumentDisplayName();

        switch (illustrationSelectorEnum) {
            case DrawdownIllustration:
                documentWithParameter.getDocument().setDocumentName(currentDocumentName + "(Drawdown)");
                documentWithParameter.getDocument().setDocumentDisplayName(currentDocumentDisplayName + "(Drawdown)");
                documentWithParameter.getDocument().setDocumentKey(new ObjectId().toHexString()); // Set different key in case of Accumulation as they are generated when two documents are generated
                break;
            case AccumulationIllustration:
                documentWithParameter.getDocument().setDocumentName(currentDocumentName + "(Accumulation)");
                documentWithParameter.getDocument().setDocumentDisplayName(currentDocumentDisplayName + "(Accumulation)");
                documentWithParameter.getDocument().setDocumentKey(new ObjectId().toHexString()); // Set different key in case of Accumulation as they are generated when two documents are generated
                break;
            default:
                documentWithParameter.getDocument().setDocumentKey(new ObjectId().toHexString()); // Set different key in case of Accumulation as they are generated when two documents are generated
                break;
        }
        return documentWithParameter;
    }
}
