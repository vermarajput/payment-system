package com.gbst.digital.services.composer;

import com.gbst.common.auth.perms.ConditionalOnPermissionProvider;
import com.gbst.common.auth.perms.PermissionProviderEnum;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.infocomp.cbis.uk.request.GetAssociatedPartyListType;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.response.AssociatedPartyListType;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import javax.validation.constraints.NotNull;
import javax.xml.bind.JAXBElement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 16/01/2018
 */
@Service
@ConditionalOnPermissionProvider(PermissionProviderEnum.Composer)
public class PartyTypeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PartyTypeService.class);
    private static final ObjectFactory objectFactory = new ObjectFactory();

    @Autowired
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    /**
     * This returns all party ids associated with the given partyId and partyTypeId.
     * Associated party type is mandatory as the service returns the list of parties of that party type.
     * @param partyId party id to return associated party ids
     * @param partyTypeId party type of the party id
     * @param associatedPartyType the party type of the associated party ids to be returned
     * @return a list with items or empty if none were found.
     */
    @Cacheable("getAssociatedParties")
    public List<AssociatedParty> getAssociatedParties(@NotNull Integer partyId, @NotNull Integer partyTypeId,@NotNull Integer associatedPartyType) {
        GetAssociatedPartyListType req = objectFactory.createGetAssociatedPartyListType();

        req.setPartyId(partyId);
        req.setPartyTypeId(partyTypeId);
        req.setSearchPartyTypeId(associatedPartyType);

        req.setReturnEntityDetails(false);

        JAXBElement<AssociatedPartyListType> response = (JAXBElement<AssociatedPartyListType>)
                webServiceTemplate.marshalSendAndReceive(multiUrlConnectionSettings.getConnections().get(Services.CBIS).getUrl(),objectFactory.createGetAssociatedPartyList(req));

        List<AssociatedParty> result = new ArrayList<>();
        if(response.isNil() || response.getValue() == null || response.getValue().getAssociatedParties() == null) {
            LOGGER.debug("No response from cbis for associated parties");
            return result;
        }

        for(AssociatedPartyListType.AssociatedParties.AssociatedParty ap : response.getValue().getAssociatedParties().getAssociatedParty()) {
            AssociatedParty party = new AssociatedParty();
            party.setPartyId(ap.getAssociatedPartyId());
            party.setPartyTypeId(ap.getPartyTypeId());
            result.add(party);
        }

        return result;
    }

    /**
     * To examine if a particular party id (or a list of them are) is associated with the given party id and party type
     * @param partyId party id to return associated party ids
     * @param partyTypeId party type of the party id
     * @param associatedPartyType the party type of the associated party ids to be returned
     * @param associatedPartyIds list of party ids to be examined
     * @return true if ALL the party ids in associatedPartyIds are associated with the given party id,
     * false if one associatedPartyIds is not associated with the given party id.
     */
    @Cacheable("isPartyAssociated")
    public boolean isPartyAssociated(@NotNull Integer partyId, @NotNull Integer partyTypeId,@NotNull Integer associatedPartyType, @NotNull String... associatedPartyIds) {
        GetAssociatedPartyListType req = objectFactory.createGetAssociatedPartyListType();

        req.setPartyId(partyId);
        req.setPartyTypeId(partyTypeId);
        req.setSearchPartyTypeId(associatedPartyType);
        req.setSearchPartyIds(StringUtils.join(associatedPartyIds, ","));
        req.setReturnEntityDetails(false);

        JAXBElement<AssociatedPartyListType> response = (JAXBElement<AssociatedPartyListType>)
                webServiceTemplate.marshalSendAndReceive(multiUrlConnectionSettings.getConnections().get(Services.CBIS).getUrl(),objectFactory.createGetAssociatedPartyList(req));

        if(response.isNil() || response.getValue() == null || response.getValue().getAssociatedParties() == null) {
            LOGGER.debug("No response from cbis for associated parties!");
            return false;
        }

        Set<String> searchSet = new HashSet<>();
        for(AssociatedPartyListType.AssociatedParties.AssociatedParty ap : response.getValue().getAssociatedParties().getAssociatedParty()) {
            searchSet.add(ap.getAssociatedPartyId() + "");
        }

        for(String id : associatedPartyIds) {
            if(!searchSet.contains(id)) {
                return false;
            }
        }

        return true;
    }


}
