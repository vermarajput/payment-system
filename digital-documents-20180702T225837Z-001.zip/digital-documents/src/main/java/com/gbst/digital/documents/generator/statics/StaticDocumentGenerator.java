package com.gbst.digital.documents.generator.statics;

import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Arrays;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 14/03/2018
 */
@ConditionalOnProperty(value = "gbst.digital.documents.types.staticDocument", havingValue = "Config")
@Service
public class StaticDocumentGenerator extends AbstractStaticDocumentGenerator implements DocumentGenerator {

    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {
        DocumentForConfig conf = payload.getDocumentForConfig();

        if (!GenerationStrategyEnum.STATIC.getValue().equalsIgnoreCase(conf.getGenerationStrategy())) {
            return false;
        }

        //this is generic/default static generator which means any static doc other than the followings
        return !(Arrays.asList(
                DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name(),
                DocumentTypeEnum.STATIC_PROTECTOR_FUND_FEATURES.name(),
                DocumentTypeEnum.STATIC_RETIREMENT_INCOME_BOOST.name()
        ).contains(conf.getDocumentName()));
    }

}
