package com.gbst.digital.documents.resource.model.types;

import com.gbst.common.data.GBSTEnumable;

import java.util.Map;

/**
 * Stores the various mime types supported by the application
 *
 * @author nehas
 */

public enum MimeTypeEnum implements GBSTEnumable<String> {
    MIME_PDF("application/pdf"),
    MIME_DOC("application/msword"),
    MIME_XML("application/xml"),
    MIME_RTF("application/rtf");
    private static Map<String, MimeTypeEnum> mapper;

    private String value;

    MimeTypeEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }

    public static MimeTypeEnum getMimeType(String outputType) {

        switch (outputType) {
            case "pdf" : return MIME_PDF;
            case "doc" : return MIME_DOC;
            case "xml" : return MIME_XML;
            case "rtf" : return MIME_RTF;
        }

        throw new IllegalStateException("Output type is not valid: " + outputType);
    }

}