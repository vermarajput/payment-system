package com.gbst.digital.documents.generator.json.windward;

import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.utils.WindwardUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.OutputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 13/03/2018
 */
public abstract class AbstractWindwardDocumentGenerator implements DocumentGenerator {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractWindwardDocumentGenerator.class);

    @Autowired
    WindwardUtil windwardUtil;
    
    protected DocumentWithParameter populateOutput(DocumentWithParameter documentWithParameter, OutputStream output) {
        documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATED);
        documentWithParameter.getDocument().setGeneratedDate(Instant.now());
        documentWithParameter.setGeneratedDocumentStream(output);
        return documentWithParameter;
    }

    protected DocumentWithParameter generationFailed(DocumentWithParameter documentWithParameter, String reason) {
        documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
        documentWithParameter.getDocument().setStatusMessage(reason);
        return documentWithParameter;
    }

    protected List<DocumentWithParameter> generateFromJsonPayload(DocumentGeneration document, DocumentPayload payload) {
        List<DocumentWithParameter> result = new ArrayList<>();
        DocumentForConfig config = payload.getDocumentForConfig();
        DocumentWithParameter documentWithParameter = DocumentWithParameter.createDocumentWithParameter(document, payload.getDocumentForConfig());
        try {
            OutputStream output = windwardUtil.generate(payload.getSource(), "pdf", "json", config.getTemplateFileName());
            result.add(populateOutput(documentWithParameter, output));
        } catch (Exception x) {
            LOG.error("Generation failed", x);
            result.add(generationFailed(documentWithParameter, "Unable to generate document: " + x.getMessage()));
        }

        return result;
    }
    
}
