package com.gbst.digital.documents.generator.json.cie;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;
import java.util.Map;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 24/10/2017
 */
@Profile("illustration")
@Component
@ConfigurationProperties(prefix = "gbst.digital.illustration")
public class IllustrationDocumentGeneratorSettings {

    private String trailCommissionDesc;
    private String dfmChargeDesc;
    private String transferCommissionDesc;
    private String singleCommissionDesc;
    private String regularCommissionDesc;

    @Nullable
    private Map<String, FieldConfigEnum> fields;

    public String getTrailCommissionDesc() {
        return trailCommissionDesc;
    }

    public void setTrailCommissionDesc(String trailCommissionDesc) {
        this.trailCommissionDesc = trailCommissionDesc;
    }

    public String getDfmChargeDesc() {
        return dfmChargeDesc;
    }

    public void setDfmChargeDesc(String DFMChargeDesc) {
        this.dfmChargeDesc = DFMChargeDesc;
    }

    public String getTransferCommissionDesc() {
        return transferCommissionDesc;
    }

    public void setTransferCommissionDesc(String transferCommissionDesc) {
        this.transferCommissionDesc = transferCommissionDesc;
    }

    public String getSingleCommissionDesc() {
        return singleCommissionDesc;
    }

    public void setSingleCommissionDesc(String singleCommissionDesc) {
        this.singleCommissionDesc = singleCommissionDesc;
    }

    public String getRegularCommissionDesc() {
        return regularCommissionDesc;
    }

    public void setRegularCommissionDesc(String regularCommissionDesc) {
        this.regularCommissionDesc = regularCommissionDesc;
    }

    public Map<String, FieldConfigEnum> getFields() {
        return fields;
    }

    public void setFields(Map<String, FieldConfigEnum> fields) {
        this.fields = fields;
    }

    /**
     * A field is considered as included if it is not present in the fieldList, or if the field has valie assigned as On
     *
     * @param fieldName
     * @return
     */
    public boolean isFieldIncluded(String fieldName) {
        return fields == null || fields.isEmpty() || fields.getOrDefault(fieldName, FieldConfigEnum.On) == FieldConfigEnum.On;
    }
}
