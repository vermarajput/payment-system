package com.gbst.digital.documents.generator.json.statics;

import com.gbst.common.jsonapi.JsonMessage;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.statics.AbstractStaticDocumentGenerator;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 28/03/2018
 */
@Profile("vitality") //This is only applicable for vitality.
@ConditionalOnProperty(value = "gbst.digital.documents.types.retirementIncomeBoost", havingValue = "Config")
@Service
public class RetirementIncomeBoostDocumentGenerator extends AbstractStaticDocumentGenerator implements DocumentGenerator {

    @Autowired
    ProductService productService;
    
    @Override
    public boolean supports(BaseDocumentGeneration document, DocumentPayload payload) {

        /*
         Requirement says:
         Retirement Income Boost (RIB) Schedule: required when opening a SIPP (transfer in drawdown OR full/partial immediate crystallisation) and Vitality assets are selected.
         Additionally, when some processes (e.g. Top-up or Switch) occur within certain products with Vitality assets selected, Boost or RIB Schedule documents must be generated.

         Translation:

         Process Type is DRAWDOWN
         AND secondary product type is 'P' (this is safety check as secondary acc should always be P)
         AND
         (At least one asset in secondary account is Vitality asset, that is assetAttribute has value 'BOOST_ALLOWED'.
         OR
         Any one BuyInvestment is Vitality asset, that is assetAttribute has value 'BOOST_ALLOWED'.)

         OR

         Primary product type is 'P'
         AND
         (At least one asset in primary account is Vitality asset, that is assetAttribute has value 'BOOST_ALLOWED'.
         OR
         Any one BuyInvestment is Vitality asset, that is assetAttribute has value 'BOOST_ALLOWED'.)


         */

        if(!payload.isJson()) {
            return false;
        }

        DocumentForConfig conf = payload.getDocumentForConfig();

        if(!GenerationStrategyEnum.STATIC.getValue().equalsIgnoreCase(conf.getGenerationStrategy())) {
            return false;
        }

        if(!DocumentTypeEnum.STATIC_RETIREMENT_INCOME_BOOST.name().equalsIgnoreCase(conf.getDocumentName())) {
            return false;
        }

        JsonMessage jm = payload.getPayloadAsJsonMessage();
        List<String> buyInvestmentAssetAttribute = jm.withJsonPath("$.trade.buyInvestments[*].assetAttribute").ofType(String.class).getArray();

        if (ProcessType.DRAWDOWN.name().equalsIgnoreCase(document.getProcessType())) {
            List<String> investmentAssetAttribute = jm.withJsonPath("$.secondaryAccount.investmentStrategy.investments[*].assetAttribute").ofType(String.class).getArray();

            Integer productTypeId = jm.with("/secondaryAccount/productTypeId").ofType(Integer.class).getActual();

            ProductTypes.ProductType productType = productService.getProductType(productTypeId);

            boolean assetAttributeFlag = (investmentAssetAttribute != null && !investmentAssetAttribute.isEmpty() && checkBoostAllowedValue(investmentAssetAttribute))
                    || (buyInvestmentAssetAttribute != null && !buyInvestmentAssetAttribute.isEmpty() && checkBoostAllowedValue(buyInvestmentAssetAttribute));

            return "P".equalsIgnoreCase(productType.getDetails().getProductFlag()) && assetAttributeFlag;
        }

        List<String> investmentAssetAttribute = jm.withJsonPath("$.investmentStrategy.investments[*].assetAttribute").ofType(String.class).getArray();
        boolean vitalityAsset = (investmentAssetAttribute != null && !investmentAssetAttribute.isEmpty() && checkBoostAllowedValue(investmentAssetAttribute))
                || (buyInvestmentAssetAttribute != null && !buyInvestmentAssetAttribute.isEmpty() && checkBoostAllowedValue(buyInvestmentAssetAttribute));

        if(!vitalityAsset) {
            return false;
        }

        Integer productTypeId = jm.with("/productTypeId").ofType(Integer.class).getActual();

        ProductTypes.ProductType productType = productService.getProductType(productTypeId);
        return "P".equalsIgnoreCase(productType.getDetails().getProductFlag());

    }

    private boolean checkBoostAllowedValue(List<String> assetAttributes) {
        if (assetAttributes.size() > 0) {
            for (String assetAttribute : assetAttributes) {
                if (assetAttribute.equalsIgnoreCase("BOOST_ALLOWED")) {
                    return true;
                }
            }
        }
        return false;
    }

}
