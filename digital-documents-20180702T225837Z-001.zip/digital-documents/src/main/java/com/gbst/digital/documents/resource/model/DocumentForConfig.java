package com.gbst.digital.documents.resource.model;

import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import org.bson.types.ObjectId;

import java.time.Instant;

/**
 * Holds details for document configuration
 *
 * @auther Aman Verma created on 20/11/2017
 */
public class DocumentForConfig extends Document {

    private String templateFileName;
    private String storageSystem; // S3, FILESYSTEM

    public DocumentForConfig() { } // Default constructor

    public DocumentForConfig(String url, String documentName, String generationStrategy, OutputTypeEnum outputType, String templateFileName, String storageSystem, String documentDisplayName) {
        super(url, documentName, generationStrategy, outputType, documentDisplayName);
        this.templateFileName = templateFileName;
        this.storageSystem = storageSystem;
    }

    public String getTemplateFileName() {
        return templateFileName;
    }

    public void setTemplateFileName(String templateFileName) {
        this.templateFileName = templateFileName;
    }

    public String getStorageSystem() {
        return storageSystem;
    }

    public void setStorageSystem(String storageSystem) {
        this.storageSystem = storageSystem;
    }

    @Override
    public String toString() {
        return "DocumentForConfig{" +
                "url='" + getUrl() + '\'' +
                ", documentDisplayName='" + getDocumentDisplayName()  + '\'' +
                ", documentName='" + getDocumentName()  + '\'' +
                ", templateFileName='" + templateFileName + '\'' +
                ", generationStrategy='" + getGenerationStrategy() + '\'' +
                ", outputType=" + getOutputType() +
                ", storageSystem='" + storageSystem + '\'' +
                "}";
    }
}
