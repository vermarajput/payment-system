package com.gbst.digital.documents.exception;

/**
 * Created by Aman Verma on 11/10/2017.
 */
public class DocumentGenerationException extends Exception {
    public DocumentGenerationException(String message) {
        super(message);
    }
    public DocumentGenerationException(String message, Throwable cause) {
        super(message, cause);
    }
}
