package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.util.List;

/**
 * Created by Aman Verma on 30/04/2018.
 */
public class BaseInvestment {
    protected String investmentId;
    private String urlKIID;
    private String urlFundFactSheet;
    private List<CustomField> customFields;
    //To be used for Vitality fund flag and for anything for other clients
    private String assetAttribute;

    private String assetName;

    public String getInvestmentId() {
        return investmentId;
    }

    public void setInvestmentId(String investmentId) {
        this.investmentId = investmentId;
    }

    public String getUrlKIID() {
        return urlKIID;
    }

    public void setUrlKIID(String urlKIID) {
        this.urlKIID = urlKIID;
    }

    public String getUrlFundFactSheet() {
        return urlFundFactSheet;
    }

    public void setUrlFundFactSheet(String urlFundFactSheet) {
        this.urlFundFactSheet = urlFundFactSheet;
    }

    public String getAssetAttribute() {
        return assetAttribute;
    }

    public void setAssetAttribute(String assetAttribute) {
        this.assetAttribute = assetAttribute;
    }

    @JsonFilter("serializeAll")
    public List<CustomField> getCustomFields() {
        return customFields;
    }

    public void setCustomFields(List<CustomField> customFields) {
        this.customFields = customFields;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BaseInvestment)) return false;

        BaseInvestment that = (BaseInvestment) o;

        if (getInvestmentId() != null ? !getInvestmentId().equals(that.getInvestmentId()) : that.getInvestmentId() != null)
            return false;
        if (getUrlKIID() != null ? !getUrlKIID().equals(that.getUrlKIID()) : that.getUrlKIID() != null) return false;
        if (getUrlFundFactSheet() != null ? !getUrlFundFactSheet().equals(that.getUrlFundFactSheet()) : that.getUrlFundFactSheet() != null)
            return false;
        if (getCustomFields() != null ? !getCustomFields().equals(that.getCustomFields()) : that.getCustomFields() != null)
            return false;
        if (getAssetAttribute() != null ? !getAssetAttribute().equals(that.getAssetAttribute()) : that.getAssetAttribute() != null)
            return false;
        return getAssetName() != null ? getAssetName().equals(that.getAssetName()) : that.getAssetName() == null;
    }

    @Override
    public int hashCode() {
        int result = getInvestmentId() != null ? getInvestmentId().hashCode() : 0;
        result = 31 * result + (getUrlKIID() != null ? getUrlKIID().hashCode() : 0);
        result = 31 * result + (getUrlFundFactSheet() != null ? getUrlFundFactSheet().hashCode() : 0);
        result = 31 * result + (getCustomFields() != null ? getCustomFields().hashCode() : 0);
        result = 31 * result + (getAssetAttribute() != null ? getAssetAttribute().hashCode() : 0);
        result = 31 * result + (getAssetName() != null ? getAssetName().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BaseInvestment{" +
                "investmentId='" + investmentId + '\'' +
                ", urlKIID='" + urlKIID + '\'' +
                ", urlFundFactSheet='" + urlFundFactSheet + '\'' +
                ", customFields=" + customFields +
                ", assetAttribute='" + assetAttribute + '\'' +
                ", assetName='" + assetName + '\'' +
                '}';
    }
}
