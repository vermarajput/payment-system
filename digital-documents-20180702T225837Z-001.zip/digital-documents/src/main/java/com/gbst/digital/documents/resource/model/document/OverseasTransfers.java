package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.util.List;

/**
 * @author rekhar on 23/10/2017
 */
public class OverseasTransfers {

    private Boolean overseasTransfersFlag;

    private List<OverseasTransfersEvents> overseasTransfersEvents;

    public Boolean getOverseasTransfersFlag() {
        return overseasTransfersFlag;
    }

    public void setOverseasTransfersFlag(Boolean overseasTransfersFlag) {
        this.overseasTransfersFlag = overseasTransfersFlag;
    }

    @JsonFilter("serializeAll")
    public List<OverseasTransfersEvents> getOverseasTransfersEvents() {
        return overseasTransfersEvents;
    }

    public void setOverseasTransfersEvents(List<OverseasTransfersEvents> overseasTransfersEvents) {
        this.overseasTransfersEvents = overseasTransfersEvents;
    }
}
