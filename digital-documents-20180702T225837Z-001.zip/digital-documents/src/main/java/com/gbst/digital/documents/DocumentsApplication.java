package com.gbst.digital.documents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.integration.transaction.PseudoTransactionManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@EnableConfigurationProperties
@EnableAutoConfiguration(exclude = {HibernateJpaAutoConfiguration.class, JpaRepositoriesAutoConfiguration.class, DataSourceAutoConfiguration.class, RabbitAutoConfiguration.class})
@ComponentScan(basePackages = "com.gbst",
        excludeFilters = @ComponentScan.Filter(type = FilterType.REGEX,
                pattern = {"com\\.gbst\\.common\\.data\\..*", "com\\.gbst\\.common\\.encryption\\..*"})
)
@SpringBootApplication(scanBasePackages = "com.gbst")
@EnableWebMvc
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class DocumentsApplication extends WebMvcConfigurerAdapter {
    /**
     * Main method.
     *
     * @param args args
     */
    public static void main(String[] args) {
        SpringApplication.run(DocumentsApplication.class, args);
    }

    /**
     * Adding extra resource.
     *
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        super.addResourceHandlers(registry);
        // Static Resources required by docs
        registry.addResourceHandler("**/*.css", "**/*.js", "**/*.html", "**/swagger.json")
                .addResourceLocations("classpath:/api-docs")
                .addResourceLocations("classpath:/docs")
                .setCachePeriod(3600);
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return new PseudoTransactionManager();
    }


}
