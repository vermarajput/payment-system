package com.gbst.digital.documents.generator.statics;

import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 3/04/2018
 */
public abstract class AbstractStaticDocumentGenerator implements DocumentGenerator {

    /**
     * Most static documents will need this method.
     * @param document
     * @param payload
     * @return
     * @throws DocumentGenerationException
     */
    @Override
    public List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        List<DocumentWithParameter> result = new ArrayList<>();
        DocumentWithParameter documentWithParameter = DocumentWithParameter.createDocumentWithParameter(document, payload.getDocumentForConfig());
        //url to the static doc is in the DocumentForConfig
        documentWithParameter.setDocument(new DocumentForGeneration(payload.getDocumentForConfig()));
        documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.NOT_GENERATED);
        result.add(documentWithParameter);
        return result;

    }

    @Override
    public void validate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException {
        //default
    }
}
