package com.gbst.digital.documents.resource.model.document;


import com.gbst.digital.documents.resource.model.document.types.InvestmentMethodEnum;

import java.math.BigDecimal;

public class SingleContribution extends Contribution{

    private String investmentSource;
    private String investmentSourceAdditionalDetails;
    private InvestmentMethodEnum investmentMethod;

    private BigDecimal grossAnnualSalary;
    private String occupation;

    public SingleContribution() {
    }

    public BigDecimal getGrossAnnualSalary() {
        return grossAnnualSalary;
    }

    public void setGrossAnnualSalary(BigDecimal grossAnnualSalary) {
        this.grossAnnualSalary = grossAnnualSalary;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getInvestmentSource() {
        return investmentSource;
    }

    public void setInvestmentSource(String investmentSource) {
        this.investmentSource = investmentSource;
    }

    public String getInvestmentSourceAdditionalDetails() {
        return investmentSourceAdditionalDetails;
    }

    public void setInvestmentSourceAdditionalDetails(String investmentSourceAdditionalDetails) {
        this.investmentSourceAdditionalDetails = investmentSourceAdditionalDetails;
    }

    public InvestmentMethodEnum getInvestmentMethod() {
        return investmentMethod;
    }

    public void setInvestmentMethod(InvestmentMethodEnum investmentMethod) {
        this.investmentMethod = investmentMethod;
    }
}
