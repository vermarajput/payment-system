package com.gbst.digital.documents.scheduler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.Metadata;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.util.MetadataHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author rekhar on 26/02/2018
 */
@Component
@EnableScheduling
public class ScheduledTasks {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private DocumentStorageTaskService documentStorageTaskService;

    @Autowired
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    MetadataHelper metadataHelper;

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledTasks.class);

    /**
     * Documents with CMISDMS storageSystem and with no externalId are sent to storage service to be stored in DMS
     */
    @Scheduled(fixedRateString = "#{schedulerSettings.getSchedulerFixedRateSeconds()}")
    public void storeDMSDocuments() {

        List<DocumentWithParameter> listOfdocumentWithParameters = new ArrayList<>();
        String documentStorageServiceURL = multiUrlConnectionSettings.getConnections().get(Services.STORAGE).getUrl();

        Criteria staticCriteria = Criteria.where("documents").elemMatch(Criteria.where("externalId").exists(false).and("generationStrategy").is(GenerationStrategyEnum.STATIC).and("generationStatus").is(GenerationStatusEnum.NOT_GENERATED).and("storageSystem").is(StorageSystemEnum.CMISDMS));
        Criteria cmisCriteria = Criteria.where("documents").elemMatch(Criteria.where("externalId").exists(false).and("generationStatus").is(GenerationStatusEnum.GENERATED).and("storageSystem").is(StorageSystemEnum.CMISDMS));
        Criteria findDocResponseCriteria = new Criteria().orOperator(cmisCriteria, staticCriteria);
        BasicQuery basicQuery = new BasicQuery(findDocResponseCriteria.getCriteriaObject());
        // Doc Generation list retreived here might contain documents that has externalId/not externalId.. There might be documents with FILESYSTEM storage also..
        List<DocumentGeneration> documentGenerationList = mongoTemplate.find(basicQuery, DocumentGeneration.class);
        LOGGER.info("Retreived Document Generation Object - " + documentGenerationList);

        for (DocumentGeneration documentGeneration : documentGenerationList) {
            if (!CollectionUtils.isEmpty(documentGeneration.getDocuments())) {
                // Here we filter out only the documents where(storage is CMISDMS && null externalId && GENERATED status) || (storage is CMISDMS && null externalId && STATIC generationStrategy).
                // By doing this we are making sure that documents with FILESYSTEM storage or documents which are already in DMS are not processed
                List<DocumentForGeneration> documentForGenerationList = documentGeneration.getDocuments().stream().filter(doc -> (doc.getGenerationStatus().equals(GenerationStatusEnum.GENERATED)
                        && doc.getStorageSystem().equals(StorageSystemEnum.CMISDMS.getValue()) && null == doc.getExternalId()) || (doc.getGenerationStrategy().equals(GenerationStrategyEnum.STATIC.getValue()) && null == doc.getExternalId() && doc.getStorageSystem().equals(StorageSystemEnum.CMISDMS.getValue())))
                        .collect(Collectors.toList());
                for (DocumentForGeneration document : documentForGenerationList) {
                    DocumentWithParameter documentWithParameter = new DocumentWithParameter();
                    documentWithParameter.setDocument(document);
                    documentWithParameter.setProcessId(documentGeneration.getProcessId());
                    documentWithParameter.setPayload(metadata(documentGeneration, documentWithParameter));
                    if(!documentWithParameter.getPayload().equals("")) {
                        listOfdocumentWithParameters.add(documentWithParameter);
                    }
                }
            }
        }
        LOGGER.debug("Documents to be sent to DMS for processing ::: {},  Size of Documents {}", listOfdocumentWithParameters, listOfdocumentWithParameters.size());

        if (!CollectionUtils.isEmpty(listOfdocumentWithParameters)) {
            if (!StringUtils.isEmpty(documentStorageServiceURL)) {
                for (DocumentWithParameter documentWithParameter : listOfdocumentWithParameters) {
                    // invoke the document storage end point to store documents in DMS
                    documentStorageTaskService.storeDocument(documentWithParameter.getDocument().getUrl(), documentWithParameter.getPayload(), documentWithParameter.getDocument().getDocumentKey(), documentWithParameter.getDocument().getGenerationStrategy());
                }
            }
        } else {
            LOGGER.info("DocumentTaskService - NO documents to be sent to DMS storage");
        }
    }

    /**
     * Metadata (document properties) constructed here from the documentAttributes
     *
     * @param documentGeneration
     * @param documentWithParameter
     * @return
     */
    private String metadata(DocumentGeneration documentGeneration, DocumentWithParameter documentWithParameter) {
        DocumentAttributes documentAttributes = null;
        Metadata metaData = null;
        String metadataString = "";
        if (null != documentGeneration && null != documentGeneration.getDocumentAttributes()) {
            try {
                documentAttributes = mapper.readValue(documentGeneration.getDocumentAttributes(), DocumentAttributes.class);
                metaData = metadataHelper.metadataForDocument(documentWithParameter, documentAttributes);
                metadataString = mapper.writeValueAsString(metaData);
            } catch (IOException e) {
                LOGGER.error("Error processing document attribute payload: " + documentGeneration.getDocumentAttributes(), e);
            }
        }
        return metadataString;
    }
}
