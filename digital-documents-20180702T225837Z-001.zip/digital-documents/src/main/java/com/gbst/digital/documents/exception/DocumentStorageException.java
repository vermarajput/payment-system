package com.gbst.digital.documents.exception;

/**
 * @author nehas
 */
public class DocumentStorageException extends Exception {
    public DocumentStorageException(String message) {
        super(message);
    }
    public DocumentStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
