package com.gbst.digital.documents.repository;

import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.google.common.collect.Iterables;
import io.katharsis.queryParams.QueryParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.StreamSupport;

import static org.springframework.util.StringUtils.isEmpty;

@Service
public class RepositoryValidator {

    private static final Logger LOG = LoggerFactory.getLogger(RepositoryValidator.class);
    public static final String SOURCE_DOCUMENT_GENERATION = "DocumentGeneration";
    public static final String SOURCE_DOCUMENT_LISTING = "DocumentListing";
    public static final String SOURCE_DOCUMENT_CONFIGURATION = "DocumentConfiguration";

    @Autowired
    private DocumentConfigurationsJsonApiRepository documentConfigurationsJsonApiRepository;

    @Autowired
    private RepositoryUtil repositoryUtil;

    /**
     * Validate Request
     *
     * @param processType, processTypeId, processStage, role, processId
     * @return
     */
    public void validateMandatoryParams(String source, String processType, String processTypeId, String processStage, String role, String processId) {
        if (isEmpty(processType)) {
            LOG.error("Error: Process Type is mandatory.");
            throw new JsonApiValidationException("invalid_format", "Process Type is mandatory.",
                    "/data/attributes/processType");
        } else if (isEmpty(processTypeId)) {
            LOG.error("Error: Process Type Id is mandatory");
            throw new JsonApiValidationException("invalid_format", "Process Type Id is mandatory.",
                    "/data/attributes/processTypeId");
        } else if (isEmpty(processStage)) {
            LOG.error("Error: Process Stage is mandatory.");
            throw new JsonApiValidationException("invalid_format", "Process Stage is mandatory.",
                    "/data/attributes/processStage");
        } else if (isEmpty(role)) {
            LOG.error("Error: Role is mandatory.");
            throw new JsonApiValidationException("invalid_format", "Role is mandatory.",
                    "/data/attributes/role");
        } else if (source.equalsIgnoreCase(SOURCE_DOCUMENT_GENERATION) && isEmpty(processId)) { // check only required for document generation
            LOG.error("Error: Process Id is mandatory");
            throw new JsonApiValidationException("invalid_format", "Process Id is mandatory.",
                    "/data/attributes/processId");
        }
    }

    /**
     * Validate Document Config
     *
     * @param docConfigs
     */
    public void validateDocumentConfiguration(List<DocumentConfiguration> docConfigs) {
        // check if no doc config found or more than one or doc config with no docs to prepare
        if (CollectionUtils.isEmpty(docConfigs)) {
            throw new JsonApiValidationException("invalid_configuration", "No Document Configuration found.", "/data/attributes/");
        } else if (docConfigs.size() > 1) {
            throw new JsonApiValidationException("invalid_configuration", "Multiple Document Configuration found, expected only one.", "/data/attributes/");
        } else if (CollectionUtils.isEmpty(docConfigs.get(0).getDocuments())) {
            throw new JsonApiValidationException("invalid_value", "No Documents found in Document Configuration.", "/data/attributes/documents/");
        }

        validateMandatoryParams(SOURCE_DOCUMENT_CONFIGURATION, docConfigs.get(0).getProcessType(), docConfigs.get(0).getProcessTypeId(), docConfigs.get(0).getProcessStage(), docConfigs.get(0).getRole(), null);
    }

    /**
     * Validates document Configuration
     *
     * @param documentConfiguration
     */
    public void validateDocConfig(DocumentConfiguration documentConfiguration) {
        if (null == documentConfiguration) {
            LOG.error("Error: Document Configuration missing.");
            throw new JsonApiValidationException("invalid_format", "Document Configuration missing.", "/data/attributes");
        }

        boolean isPatch = !isEmpty(documentConfiguration.getId());

        if (isPatch) {
            validateDocConfigPatchRequest(documentConfiguration);
        } else {
            validateDocConfigPostRequest(documentConfiguration);
        }

        // Iterate for each document in a given configuration and check if valid
        validateDocuments(documentConfiguration);

        //validate if any illustration type document to be generated then the process_type value provided in the request : must be the valid/allowed process type provided in ProcessType Enum
        validateProcessTypeForIllustration(documentConfiguration);


    }

    /**
     * Validate the configuration to check if any Illustration document is part of the document then the Process Type must be the valid one
     *
     * @param documentConfiguration
     */
    private void validateProcessTypeForIllustration(DocumentConfiguration documentConfiguration) {
        if (!CollectionUtils.isEmpty(documentConfiguration.getDocuments())) {
            if (documentConfiguration.getDocuments().stream().filter(documentForConfig ->
                    (documentForConfig != null && GenerationStrategyEnum.ILLUSTRATION.getValue().equalsIgnoreCase(documentForConfig.getGenerationStrategy()))).count() > 0) {
                try {
                    ProcessType.valueOf(documentConfiguration.getProcessType());
                }catch(IllegalArgumentException e){
                    LOG.error("Error: Process Type is invalid if there are one or more documents with the document generation strategy of Illustration.");
                    throw new JsonApiValidationException("invalid_format", "Process Type is invalid if there are one or more documents with the document generation strategy of Illustration.",
                            "/data/attributes/processType");
                }
            }
        }
    }

    /**
     * Validates document Configuration post request
     *
     * @param documentConfiguration
     */
    private void validateDocConfigPostRequest(DocumentConfiguration documentConfiguration) {
        validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_CONFIGURATION, documentConfiguration.getProcessType(), documentConfiguration.getProcessTypeId(), documentConfiguration.getProcessStage(), documentConfiguration.getRole(), null);

        // should not be duplicate config
        Iterable<DocumentConfiguration> documentConfigurations = find(documentConfiguration);
        if (!Iterables.isEmpty(documentConfigurations)) {
            throw new JsonApiValidationException("is_duplicate", "Duplicate Document Configuration is not allowed.", "/data/attributes");
        }

        // atleast one document must be part of the document configuration
        if (CollectionUtils.isEmpty(documentConfiguration.getDocuments())) {
            throw new JsonApiValidationException("is_required", "At least one document is required.", "/data/attributes/documents");
        }
    }

    /**
     * Validates document Configuration patch request
     *
     * @param documentConfiguration
     */
    private void validateDocConfigPatchRequest(DocumentConfiguration documentConfiguration) {

        // If documents supplied then atleast one document must be part of the document configuration
        if (documentConfiguration.getDocuments() != null && documentConfiguration.getDocuments().isEmpty()) {
            throw new JsonApiValidationException("is_required", "At least one document is required.", "/data/attributes/documents");
        }

        // should not be duplicate config
        Iterable<DocumentConfiguration> documentConfigurations = find(documentConfiguration);

        if (!Iterables.isEmpty(documentConfigurations) &&
                StreamSupport.stream(documentConfigurations.spliterator(), false)
                        .filter(docConfigInDb -> !documentConfiguration.getId().equals(docConfigInDb.getId()))
                        .count() > 0) {
            throw new JsonApiValidationException("is_duplicate", "Duplicate Document Configuration is not allowed.", "/data/attributes");

        }
    }

    /**
     * Validates specific cases per document
     *
     * @param documentConfiguration
     */
    private void validateDocuments(DocumentConfiguration documentConfiguration) {
        if (null != documentConfiguration && !CollectionUtils.isEmpty(documentConfiguration.getDocuments())) {
            int index = 0;
            for (DocumentForConfig eachDoc : documentConfiguration.getDocuments()) {

                if (null == eachDoc.getGenerationStrategy()) {
                    throw new JsonApiValidationException("is_required", "Document generation strategy is required.", "/data/attributes/documents/" + index + "/generationStrategy");
                }

                if (null == eachDoc.getOutputType()) {
                    throw new JsonApiValidationException("is_required", "Document output type is required.", "/data/attributes/documents/" + index + "/outputType");
                }

                if (null == eachDoc.getDocumentDisplayName()) {
                    throw new JsonApiValidationException("is_required", "Document display name is required.", "/data/attributes/documents/" + index + "/documentDisplayName");
                }

                if (null == eachDoc.getDocumentName()) {
                    throw new JsonApiValidationException("is_required", "Document name is required.", "/data/attributes/documents/" + index + "/documentName");
                }

                if (GenerationStrategyEnum.STATIC.getValue().equals(eachDoc.getGenerationStrategy())
                        && (null == eachDoc.getUrl() || eachDoc.getUrl().trim().length() == 0)) {
                    throw new JsonApiValidationException("is_required", "URL is required when Document generation strategy is static.", "/data/attributes/documents/" + index + "/url");
                }

                if (GenerationStrategyEnum.WINDWARD.getValue().equals(eachDoc.getGenerationStrategy())
                        && (null == eachDoc.getTemplateFileName() || eachDoc.getTemplateFileName().trim().length() == 0)) {
                    throw new JsonApiValidationException("is_required", "templateFileName is required when generationStrategy is WINDWARD.", "/data/attributes/documents/" + index + "/templateFileName");
                }

                index++;
            }

        }
    }

    /**
     * Finds single DocumentConfiguration based on following parameters
     * * processType
     * * processTypeId
     * * processStage
     * * role
     *
     * @param docConfig
     * @return
     */
    private Iterable<DocumentConfiguration> find(DocumentConfiguration docConfig) {
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig(docConfig.getProcessType(), docConfig.getProcessTypeId(), docConfig.getProcessStage(), docConfig.getRole());
        return documentConfigurationsJsonApiRepository.findAll(queryParams);
    }
}
