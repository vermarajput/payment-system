package com.gbst.digital.documents.exception;

import org.springframework.http.HttpStatus;

/**
 * @author nehas
 */

public class ServletRunTimeException extends RuntimeException {

        private HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

        public HttpStatus getHttpStatus() {
            return httpStatus;
        }

        /**
         * Constructs a new runtime exception with the status and specified detail message.
         */
        public ServletRunTimeException(HttpStatus httpStatus, String message) {
            super(message);
            this.httpStatus = httpStatus;
        }

}
