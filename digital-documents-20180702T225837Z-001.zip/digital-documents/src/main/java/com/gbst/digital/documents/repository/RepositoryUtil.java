package com.gbst.digital.documents.repository;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.jsonapi.QueryParamValue;
import com.gbst.common.data.mongo.MongoQueryUtil;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import io.katharsis.queryParams.DefaultQueryParamsParser;
import io.katharsis.queryParams.QueryParams;
import io.katharsis.queryParams.QueryParamsBuilder;
import io.katharsis.queryParams.params.FilterParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

@Service
public class RepositoryUtil {

    @Autowired
    AuthenticationFacade authenticationFacade;

    /**
     * Prepare Query Parameters
     *
     * @return QueryParams
     */
    public QueryParams prepareQueryParamsForDocumentConfig(String processType, String processTypeId, String processStage, String role) {
        QueryParamsBuilder builder = new QueryParamsBuilder(new DefaultQueryParamsParser());
        Map<String, Set<String>> filters = new HashMap<>();

        if (!StringUtils.isEmpty(processTypeId)) {
            filters.put("filter[document-configurations][processTypeId]", new HashSet<String>());
            filters.get("filter[document-configurations][processTypeId]").add(processTypeId);
        }

        if (!StringUtils.isEmpty(processStage)) {
            filters.put("filter[document-configurations][processStage]", new HashSet<String>());
            filters.get("filter[document-configurations][processStage]").add(processStage);
        }

        if (!StringUtils.isEmpty(processType)) {
            filters.put("filter[document-configurations][processType]", new HashSet<String>());
            filters.get("filter[document-configurations][processType]").add(processType);
        }

        if (!StringUtils.isEmpty(role)) {
            filters.put("filter[document-configurations][role]", new HashSet<String>());
            filters.get("filter[document-configurations][role]").add(role);
        }

        return builder.buildQueryParams(filters);
    }

    /**
     * @param queryParams
     * @return
     */
    public Query findAllBasedOnQueryParams(QueryParams queryParams, Class klass) {
        Query query = new Query();

        // adding criteria
        List<Criteria> criteria = MongoQueryUtil.prepareQueryCriteria(queryParams);

        if (klass.equals(DocumentGeneration.class)) {
            addMandatoryConditions(criteria);
        }
        if (!criteria.isEmpty()) {
            query.addCriteria(new Criteria().andOperator(criteria.toArray(new Criteria[criteria.size()])));
        }

        // adding sorting and paging
        MongoQueryUtil.addPagingSorting(queryParams, query);

        return query;
    }

    /**
     * Adding condition to filter documents that the user does not have access to.
     * @param criteria
     */
    private void addMandatoryConditions(List<Criteria> criteria) {
        GbstPrincipal principal = authenticationFacade.getPrincipal();
        criteria.add(Criteria.where("owner").is(principal.getGbstPartyId() + principal.getGbstPartyType()));
    }

    /**
     * Prepare document generation query params from the input document Generation request
     *
     * @param documentGeneration
     * @return
     */
    public Map<String, QueryParamValue> getDocumentGenerationQueryParams(DocumentGeneration documentGeneration) {
        Map<String, QueryParamValue> parameters = new HashMap<>();
        Map<String, Set<String>> mapParams = new HashMap<>();
        mapParams.put("processType", new HashSet<String>(Arrays.asList(documentGeneration.getProcessType())));
        mapParams.put("processTypeId", new HashSet<String>(Arrays.asList(documentGeneration.getProcessTypeId())));
        mapParams.put("processId", new HashSet<String>(Arrays.asList(documentGeneration.getProcessId())));
        mapParams.put("role", new HashSet<String>(Arrays.asList(documentGeneration.getRole())));
        mapParams.put("processStage", new HashSet<String>(Arrays.asList(documentGeneration.getProcessStage())));
        FilterParams filterParams = new FilterParams(mapParams);
        for (Map.Entry<String, Set<String>> entry : filterParams.getParams().entrySet()) {
            String key = entry.getKey();
            parameters.put(key, new QueryParamValue(entry.getValue().toArray()));
        }
        return parameters;
    }

    /**
     * Get the query based on Query Param input
     *
     * @param queryParam
     * @return
     */
    public Query getQuery(Map<String, QueryParamValue> queryParam) {
        Query query = new Query();
        List<Criteria> criterias = new ArrayList<>();
        if (!queryParam.isEmpty()) {
            queryParam.keySet().forEach(filterField -> {
                if (null != queryParam.get(filterField).getValues()) {
                    List<Object> values = new ArrayList<>();
                    for (Object value : queryParam.get(filterField).getValues()) {
                        values.add(value);
                    }
                    Criteria criteria = new Criteria().andOperator(Criteria.where(filterField).in(values));
                    criterias.add(criteria);
                }
            });
        }
        if (!criterias.isEmpty()) {
            query.addCriteria(new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()])));
        }
        return query;
    }

}
