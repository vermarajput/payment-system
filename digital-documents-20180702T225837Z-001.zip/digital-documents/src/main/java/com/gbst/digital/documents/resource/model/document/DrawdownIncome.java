package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.math.BigDecimal;

/**
 * @author Jonathan Bildan on 19/10/2017
 */

public class DrawdownIncome {

    private BigDecimal amount;
    private String frequency;
    private String paymentDate;
    private BankAccount bankAccount;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    @JsonFilter("serializeAll")
    public BankAccount getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccountDetails) {
        this.bankAccount = bankAccountDetails;
    }

}
