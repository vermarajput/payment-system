package com.gbst.digital.documents.service;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.digital.documents.repository.DocumentCleanupUtility;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringEscapeUtils.*;

/**
 * @author nehas
 */
@RestController
public class DocumentCleanupService {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private DocumentCleanupUtility documentCleanupUtility;

    @Autowired
    Permissions<List<String>, OperationEnum> permissions;

    @Autowired
    private AuthenticationFacade authenticationFacade;

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentCleanupService.class);

    @PostMapping("/api/cleanup-document-generation")
    public void cleanup(@RequestBody String[] expiredProcessIds) throws Exception {
        GbstPrincipal principal = authenticationFacade.getPrincipal();
        if(!principal.isClientOnly()){
            throw new AccessDeniedException("This is not client-only request.");
        }

        if (!StringUtils.isEmpty(expiredProcessIds)) {
            List<String> expiredProcessIdList = new ArrayList<String>(Arrays.asList(expiredProcessIds));
            permissions.check(null, expiredProcessIdList);
            LOGGER.info("CleanUp called for - " + escapeCsv(expiredProcessIdList.stream().collect(Collectors.joining(","))));
            deleteExpiredDocuments(expiredProcessIdList);
        }
    }

    private void deleteExpiredDocuments(List<String> processIds) {
        Query query = new Query().addCriteria(Criteria.where("processId").in(processIds));
        List<DocumentGeneration> expiryCandidates = mongoTemplate.find(query, DocumentGeneration.class);
        if (!CollectionUtils.isEmpty(expiryCandidates)) {
            LOGGER.info("expiryCandidates for documents found : count = " + expiryCandidates.size());
            for (DocumentGeneration docGenToExpire : expiryCandidates) {
                try {
                    documentCleanupUtility.clearPreviousGenerationRecords(docGenToExpire);
                } catch (Exception e) {
                    LOGGER.error("Error occurred while deleting expired documents - " + e.getMessage());
                    //forcefully remove the document generation record even though exception occurs
                    mongoTemplate.remove(docGenToExpire);
                }
            }
        }

    }


}
