package com.gbst.digital.documents.scheduler;

/**
 * @author rekhar on 14/03/2018
 */
public class StoreDocumentResponse {

    private String externalId;
    private String statusMessage;

    public StoreDocumentResponse(String externalId, String statusMessage) {
        this.externalId = externalId;
        this.statusMessage = statusMessage;
    }

    public StoreDocumentResponse() {
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    @Override
    public String toString() {
        return "StoreDocumentResponse{" +
                "externalId='" + externalId + '\'' +
                ", statusMessage='" + statusMessage + '\'' +
                '}';
    }
}
