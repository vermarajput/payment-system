package com.gbst.digital.documents.repository;

import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * @author nehas
 */
@Service
public class DocumentCleanupUtility {


    @Autowired
    private DownloadAndCleanupDelegator downloadAndCleanupDelegator;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private RepositoryUtil repositoryUtil;

    /**
     * Method to handle previous generation requests and clear records and storage
     *
     * @param documentGenerationRequest
     */
    public void handlePreviousGenerationRequestsData(DocumentGeneration documentGenerationRequest) throws DocumentStorageException {

        // find document generation request already made
        Query queryforDocGen = repositoryUtil.getQuery(repositoryUtil.getDocumentGenerationQueryParams(documentGenerationRequest));
        List<DocumentGeneration> documentGenerationsFromDB = mongoTemplate.find(queryforDocGen, DocumentGeneration.class);

        // there can not be multiple document generation records present
        if (!CollectionUtils.isEmpty(documentGenerationsFromDB)) {
            if (documentGenerationsFromDB.size() > 1) {
                throw new JsonApiValidationException("invalid_value", "multiple document generation records present", "");
            } else {
                // clear from DB and Storage
                clearPreviousGenerationRecords(documentGenerationsFromDB.get(0));
            }
        }
    }

    /**
     * Clear the Db record and remove from file storage
     *
     * @param documentGenerationRecordFromDB
     * @throws DocumentStorageException
     */
    public void clearPreviousGenerationRecords(DocumentGeneration documentGenerationRecordFromDB) throws DocumentStorageException {
        //clear the storage
        List<DocumentForGeneration> docResponses = documentGenerationRecordFromDB.getDocuments();
        if (!CollectionUtils.isEmpty(docResponses)) {
            for (DocumentForGeneration docResponse : docResponses) {
                if ((!GenerationStrategyEnum.STATIC.getValue().equalsIgnoreCase(docResponse.getGenerationStrategy()))
                        && (!StringUtils.isEmpty(docResponse.getUrl()))
                        && (docResponse.getGenerationStatus().equals(GenerationStatusEnum.GENERATED))
                        && (!StorageSystemEnum.CMISDMS.getValue().equalsIgnoreCase(docResponse.getStorageSystem()))) {
                    downloadAndCleanupDelegator.removeDocumentsFromStorageSystems(docResponse.getUrl(), docResponse.getStorageSystem());
                }
            }
        }
        // clear the exisitng record from DB
        mongoTemplate.remove(documentGenerationRecordFromDB);
    }

}
