package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.PensionBenefitsEvents;

import java.util.List;

/**
 * @author rekhar on 23/10/2017
 */
public class PensionBenefits {

    private Boolean pensionBenefitsFlag;

    private List<PensionBenefitsEvents> pensionBenefitsEvents;

    public Boolean getPensionBenefitsFlag() {
        return pensionBenefitsFlag;
    }

    public void setPensionBenefitsFlag(Boolean pensionBenefitsFlag) {
        this.pensionBenefitsFlag = pensionBenefitsFlag;
    }

    @JsonFilter("serializeAll")
    public List<PensionBenefitsEvents> getPensionBenefitsEvents() {
        return pensionBenefitsEvents;
    }

    public void setPensionBenefitsEvents(List<PensionBenefitsEvents> pensionBenefitsEvents) {
        this.pensionBenefitsEvents = pensionBenefitsEvents;
    }
}
