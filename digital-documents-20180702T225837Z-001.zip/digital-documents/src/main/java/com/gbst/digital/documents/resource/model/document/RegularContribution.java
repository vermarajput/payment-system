package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.gbst.digital.documents.resource.model.types.Frequency;

/**
 * @author rekhar on 25/09/2017
 */
public class RegularContribution extends Contribution {
    private String frequency;
    private Boolean indexByRPIFlag;
    private Integer initialChargeTerm;
    private Integer directDebitPaymentDay;

    // Apply Money In Details
    private Boolean clientPresentFlag;
    private Boolean clientDebitAuthorisationFlag;
    private BankAccount bankAccount;

    public RegularContribution() {
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public Boolean isIndexByRPIFlag() {
        return indexByRPIFlag;
    }

    public void setIndexByRPIFlag(Boolean indexByRPIFlag) {
        this.indexByRPIFlag = indexByRPIFlag;
    }

    public Integer getInitialChargeTerm() {
        return initialChargeTerm;
    }

    public void setInitialChargeTerm(Integer initialChargeTerm) {
        this.initialChargeTerm = initialChargeTerm;
    }

    public Integer getDirectDebitPaymentDay() {
        return directDebitPaymentDay;
    }

    public void setDirectDebitPaymentDay(Integer directDebitPaymentDay) {
        this.directDebitPaymentDay = directDebitPaymentDay;
    }

    public Boolean getClientPresentFlag() {
        return clientPresentFlag;
    }

    public void setClientPresentFlag(Boolean clientPresentFlag) {
        this.clientPresentFlag = clientPresentFlag;
    }

    public Boolean getClientDebitAuthorisationFlag() {
        return clientDebitAuthorisationFlag;
    }

    public void setClientDebitAuthorisationFlag(Boolean clientDebitAuthorisationFlag) {
        this.clientDebitAuthorisationFlag = clientDebitAuthorisationFlag;
    }

    @JsonFilter("serializeAll")
    public BankAccount getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccountDetails) {
        this.bankAccount = bankAccountDetails;
    }
}
