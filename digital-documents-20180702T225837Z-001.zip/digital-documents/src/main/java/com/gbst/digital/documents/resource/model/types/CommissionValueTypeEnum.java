package com.gbst.digital.documents.resource.model.types;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 10/10/2017
 */
public enum CommissionValueTypeEnum {
    Percentage,
    Amount,
    NotApplicable;
}
