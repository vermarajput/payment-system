package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.gbst.common.jsonapi.serializer.LocalDateDeserializer;
import com.gbst.common.jsonapi.serializer.LocalDateSerializer;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author rekhar on 23/10/2017
 */
public class OverseasTransfersEvents {

    private String cedingScheme;
    private BigDecimal transferAmount;
    private LocalDate transferDate;

    public String getCedingScheme() {
        return cedingScheme;
    }

    public void setCedingScheme(String cedingScheme) {
        this.cedingScheme = cedingScheme;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }

    public LocalDate getTransferDate() {
        return transferDate;
    }

    public void setTransferDate(LocalDate transferDate) {
        this.transferDate = transferDate;
    }
}
