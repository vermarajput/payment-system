package com.gbst.digital.documents.generator;

import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;

import java.util.List;

/**
 * Created by Aman Verma on 11/10/2017.
 */
public interface DocumentGenerator {

    boolean supports(BaseDocumentGeneration document, DocumentPayload payload);
    void validate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException;
    List<DocumentWithParameter> generate(DocumentGeneration document, DocumentPayload payload) throws DocumentGenerationException;
}
