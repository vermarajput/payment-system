package com.gbst.digital.documents.resource.model.document;


import com.gbst.digital.documents.resource.model.document.types.TransferFullPartialTypeEnum;

public class TransferIn extends Application{

    private String scheme;
    private String schemeAddress;
    private String schemePolicyNumber;
    private String schemeTelephone;
    private TransferFullPartialTypeEnum fullPartialFlag;
    private Boolean transferAuthorityFlag;

    public TransferIn(){
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getSchemeAddress() {
        return schemeAddress;
    }

    public void setSchemeAddress(String schemeAddress) {
        this.schemeAddress = schemeAddress;
    }

    public String getSchemePolicyNumber() {
        return schemePolicyNumber;
    }

    public void setSchemePolicyNumber(String schemePolicyNumber) {
        this.schemePolicyNumber = schemePolicyNumber;
    }

    public String getSchemeTelephone() {
        return schemeTelephone;
    }

    public void setSchemeTelephone(String schemeTelephone) {
        this.schemeTelephone = schemeTelephone;
    }

    public TransferFullPartialTypeEnum getFullPartialFlag() {
        return fullPartialFlag;
    }

    public void setFullPartialFlag(TransferFullPartialTypeEnum fullPartialFlag) {
        this.fullPartialFlag = fullPartialFlag;
    }

    public Boolean isTransferAuthorityFlag() {
        return transferAuthorityFlag;
    }

    public void setTransferAuthorityFlag(Boolean transferAuthorityFlag) {
        this.transferAuthorityFlag = transferAuthorityFlag;
    }
}
