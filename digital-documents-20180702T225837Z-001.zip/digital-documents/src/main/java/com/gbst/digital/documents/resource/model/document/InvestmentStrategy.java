package com.gbst.digital.documents.resource.model.document;

import com.fasterxml.jackson.annotation.JsonFilter;

import java.util.List;

/**
 * @author Aman Verma on 25/09/2017
 * @author nehas modified on 26/09/2017
 */
public class InvestmentStrategy {

    private String investmentModelId;
    private String rebalanceFrequency;
    private List<Investment> investments;

    public String getInvestmentModelId() {
        return investmentModelId;
    }

    public void setInvestmentModelId(String investmentModelId) {
        this.investmentModelId = investmentModelId;
    }

    public String getRebalanceFrequency() {
        return rebalanceFrequency;
    }

    public void setRebalanceFrequency(String rebalanceFrequency) {
        this.rebalanceFrequency = rebalanceFrequency;
    }

    @JsonFilter("serializeAll")
    public List<Investment> getInvestments() {
        return investments;
    }

    public void setInvestments(List<Investment> modelInvestments) {
        this.investments = modelInvestments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InvestmentStrategy that = (InvestmentStrategy) o;

        return investmentModelId != null ? investmentModelId.equals(that.investmentModelId) : that.investmentModelId == null;
    }

    @Override
    public int hashCode() {
        return investmentModelId != null ? investmentModelId.hashCode() : 0;
    }

}
