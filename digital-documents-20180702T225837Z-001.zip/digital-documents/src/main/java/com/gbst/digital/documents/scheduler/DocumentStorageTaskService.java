package com.gbst.digital.documents.scheduler;

import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.owasp.esapi.SafeFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.*;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static org.apache.commons.lang3.StringEscapeUtils.escapeJava;
import static org.owasp.esapi.ESAPI.encoder;

/**
 * @author rekhar on 28/02/2018
 */
@Service
public class DocumentStorageTaskService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentStorageTaskService.class);

    @Autowired
    OAuth2RestTemplate restOperations;

    @Autowired
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Service to send document and metatdata to storage service to store in DMS
     *
     * @param url
     * @param metadata
     * @param documentKey
     */
    public void storeDocument(String url, String metadata, String documentKey, String generationStrategy) {
        String documentStorageServiceURL = multiUrlConnectionSettings.getConnections().get(Services.STORAGE).getUrl();
        try {
            LinkedMultiValueMap<String, Object> parts =
                    new LinkedMultiValueMap<>();
            if (!generationStrategy.equals(GenerationStrategyEnum.STATIC.getValue())) {
                parts.add("file", new FileSystemResource(new SafeFile(url)));
            } else {
                parts.add("file", new FileSystemResource(createStaticFile()));
            }

            parts.add("metadata", metadata);

            HttpEntity<LinkedMultiValueMap<String, Object>> requestEntity =
                    new HttpEntity<LinkedMultiValueMap<String, Object>>(parts, prepareRequestHeader());
            ResponseEntity<StoreDocumentResponse> response = restOperations.exchange(documentStorageServiceURL, HttpMethod.POST, requestEntity, StoreDocumentResponse.class);
            LOGGER.debug("Response from document storage service ::: {}", encoder().encodeForHTML(escapeJava(response.getBody().toString())));
            LOGGER.debug("Document Key ::: {}", encoder().encodeForHTML(escapeJava(documentKey)));
            if (response.getStatusCode().equals(HttpStatus.OK)) {
                StoreDocumentResponse storedDocument = response.getBody();
                saveExternalId(storedDocument.getExternalId(), storedDocument.getStatusMessage(), documentKey);
            }
        } catch (Exception e) {
            LOGGER.error("Error occurred while storing documents to DMS - " + e.getMessage());
        }
    }

    private HttpHeaders prepareRequestHeader() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        return headers;
    }

    /**
     * Updates mongo record with the externalId/statusMessage for the given documentKey
     *
     * @param externalId
     * @param statusMessage
     * @param documentKey
     */
    private void saveExternalId(String externalId, String statusMessage, String documentKey) {
        DocumentGeneration documentGeneration = findOneDocGenObject(documentKey);
        if (null != documentGeneration) {
            for (DocumentForGeneration document : documentGeneration.getDocuments()) {
                if (document.getDocumentKey().equalsIgnoreCase(documentKey)) {
                    document.setExternalId(externalId);
                    document.setStatusMessage(statusMessage);
                }
            }
            mongoTemplate.save(documentGeneration, "document-generation");
            LOGGER.debug("Saved DMS Document Generation Object with External ID::: {}", documentGeneration);
        }
    }

    /**
     * Finds document generation object from mongo for the given documentKey
     *
     * @param key
     * @return
     */
    private DocumentGeneration findOneDocGenObject(String key) {
        Criteria findDocResponseCriteria = Criteria.where("documents").elemMatch(Criteria.where("documentKey").is(key));
        BasicQuery basicQuery = new BasicQuery(findDocResponseCriteria.getCriteriaObject());
        return mongoTemplate.findOne(basicQuery, DocumentGeneration.class);
    }

    private File createStaticFile() {
        File staticFile = new File(System.getProperty("java.io.tmpdir") + "/static.txt");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(staticFile))) {
            if (!staticFile.exists()) {
                staticFile.createNewFile();
            }
            bw.write(" ");

        } catch (IOException e) {
            LOGGER.error("Error occurred while creating static documents - " + e.getMessage());
        }
        return staticFile;
    }
}
