package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * @author Cecily on 28/03/2018
 */
public enum SellByEnum implements GBSTEnumable<String> {

    Percentage("PERCENTAGE"),
    Units("UNITS"),
    Amount("AMOUNT");
    private String value;

    SellByEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }
}
