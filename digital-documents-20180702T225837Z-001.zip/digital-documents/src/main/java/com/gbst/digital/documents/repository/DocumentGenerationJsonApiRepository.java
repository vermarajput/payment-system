package com.gbst.digital.documents.repository;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.DefaultResourceRepository;
import com.gbst.common.jsonapi.GbstJsonApiUtils;
import com.gbst.common.jsonapi.ResourceNotFoundException;
import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import io.katharsis.queryParams.QueryParams;
import io.katharsis.repository.ResourceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class DocumentGenerationJsonApiRepository extends DefaultResourceRepository<DocumentGeneration, String> implements ResourceRepository<DocumentGeneration, String> {

    private static final Logger LOG = LoggerFactory.getLogger(DocumentGenerationJsonApiRepository.class);

    @Autowired
    private DocumentConfigurationsJsonApiRepository documentConfigurationsJsonApiRepository;

    @Autowired
    private RepositoryValidator repositoryValidator;

    @Autowired
    private RepositoryUtil repositoryUtil;

    @Autowired
    private DocumentGenerationDelegator documentGenerationDelegator;

    @Autowired
    private DocumentStorageDelegator documentStorageDelegator;

    @Autowired
    private DocumentCleanupUtility documentCleanupUtility;

    @Autowired
    AuthenticationFacade authenticationFacade;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    Permissions<DocumentGeneration, OperationEnum> documentGenerationPermissions;

    @Autowired
    DocumentPayloadFactory documentPayloadFactory;

    @Autowired
    Permissions<DocumentPayload, OperationEnum> payloadPermissions;

    @Override
    public Iterable<DocumentGeneration> findAll(QueryParams documentGenQueryParams) {
        Query query = repositoryUtil.findAllBasedOnQueryParams(documentGenQueryParams, DocumentGeneration.class);
        List<DocumentGeneration> result = mongoTemplate.find(query, DocumentGeneration.class);

        // URL is not updated to null - as part of DIG-2888

        return GbstJsonApiUtils.createIterableResult(result);
    }

    @PreAuthorize("principal.gbstPartyType == 'Adviser' or principal.gbstPartyType == 'Investor'")
    @Override
    public DocumentGeneration save(DocumentGeneration documentGenerationRequest) {

        boolean isPatch = null != documentGenerationRequest.getId();

        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_GENERATION, documentGenerationRequest.getProcessType(), documentGenerationRequest.getProcessTypeId(), documentGenerationRequest.getProcessStage(), documentGenerationRequest.getRole(), documentGenerationRequest.getProcessId());
        QueryParams document_configurations_queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig(documentGenerationRequest.getProcessType(), documentGenerationRequest.getProcessTypeId(), documentGenerationRequest.getProcessStage(), documentGenerationRequest.getRole());
        List<DocumentConfiguration> docConfigs = (List<DocumentConfiguration>) documentConfigurationsJsonApiRepository.findAll(document_configurations_queryParams);
        repositoryValidator.validateDocumentConfiguration(docConfigs);

        if (!isPatch) {
            GbstPrincipal principal = authenticationFacade.getPrincipal();
            documentGenerationRequest.setOwner(principal.getGbstPartyId() + principal.getGbstPartyType());

            // handle previous generation requests and clear records and storage
            try {
                documentCleanupUtility.handlePreviousGenerationRequestsData(documentGenerationRequest);
            } catch (Exception e) {
                LOG.error("Error occurred during cleanup of previous generation data.  " + e.getMessage());
                throw new JsonApiValidationException("invalid_state", "Error occurred during cleanup of previous generation data.", "/data/attributes/");
            }
            //This needs to be saved and then updated later at the end of the process
            mongoTemplate.save(documentGenerationRequest);
            //process and persist document generation with responses
            List<DocumentWithParameter> documentWithParameters = processDocuments(documentGenerationRequest, docConfigs.get(0).getDocuments());
            List<DocumentForGeneration> docForGen = documentWithParameters.stream().map(DocumentWithParameter::getDocument).collect(Collectors.toList());

            documentGenerationRequest.setDocuments(docForGen);


            //This will update the DocumentGeneration after updates being made during the process
            mongoTemplate.save(documentGenerationRequest, "document-generation");
            LOG.info("Saved Document Generation Object - " + documentGenerationRequest);

            // URL is not updated to null - as part of DIG-2888
        } else {
            throw new UnsupportedOperationException("PATCH is not implemented");
        }
        return documentGenerationRequest;
    }

    @Override
    public DocumentGeneration findOne(String id, QueryParams queryParams){
        DocumentGeneration documentGeneration = mongoTemplate.findById(id, DocumentGeneration.class);
        if (documentGeneration == null) {
            throw new ResourceNotFoundException(DocumentGeneration.class, id);
        }
        documentGenerationPermissions.check(OperationEnum.FindOne, documentGeneration);
        return documentGeneration;
    }

    /**
     * Process documents, generates and stores them
     *
     * @param documentGenerationRequest - document generation input request
     * @param docsForConfig             - list of documents to generate
     * @return List<DocumentWithParameter>
     */
    private List<DocumentWithParameter> processDocuments(DocumentGeneration documentGenerationRequest, List<DocumentForConfig> docsForConfig) {
        List<DocumentWithParameter> listOfDocumentWithParameters = new ArrayList<>();
        DocumentPayload payload = documentPayloadFactory.createPayload(documentGenerationRequest.getDocumentAttributesFormat(), documentGenerationRequest.getDocumentAttributes());
        LOG.info("Checking permissions...");
        payloadPermissions.check(OperationEnum.Save, payload);

        for (DocumentForConfig document : docsForConfig) {
            payload.setDocumentForConfig(document);
            listOfDocumentWithParameters.addAll(documentGenerationDelegator.generateDocumentForSupportedHandlers(payload, documentGenerationRequest));
        }

        return documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(listOfDocumentWithParameters);
    }

}
