package com.gbst.digital.documents.resource.model.document.types;

import com.gbst.common.data.GBSTEnumable;

/**
 * @author Cecily on 28/03/2018
 */
public enum TradeTypeEnum implements GBSTEnumable<String> {

    Sell("SELL"),
    Buy("BUY"),
    Switch("SWITCH");
    private String value;

    TradeTypeEnum(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public Enum getEnumFromValue(String value) {
        return GBSTEnumableHelper.getEnumFromValue(this, value);
    }
}
