package com.gbst.digital.documents.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.digital.documents.exception.DocumentGenerationException;
import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aman Verma on 31/10/2017.
 */

@Service
public class DocumentGenerationDelegator {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentGenerationDelegator.class);
    
    @Autowired
    private List<DocumentGenerator> documentGenerators;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    DocumentPayloadFactory documentPayloadFactory;

    /**
     *
     *
     * @param payload
     * @param documentGeneration
     * @return
     * @throws DocumentGenerationException
     */
    public List<DocumentWithParameter> generateDocumentForSupportedHandlers(DocumentPayload payload, DocumentGeneration documentGeneration) {
        List<DocumentWithParameter> generatedDocuments = new ArrayList<>();
        /*
        First we call 'supports' if the generator is supporting the payload/generating doc,
        then we call 'validate' to validate the payload data
        and then 'generate'
         */
        LOGGER.info("Sending payload to document generators...");
        for (DocumentGenerator handler : documentGenerators) {
            LOGGER.debug("Invoking document generator: {}", handler);
            if (handler.supports(documentGeneration, payload)) {
                try {
                    handler.validate(documentGeneration, payload);
                    generatedDocuments.addAll(handler.generate(documentGeneration, payload));
                } catch (Exception e) {
                    LOGGER.warn("Generation handler failed to generate the document: " + e.getMessage());
                    LOGGER.debug("Error while generating document - Ignorable if validation error has occurred", e); // This is only for debugging
                    DocumentWithParameter documentWithParameter = DocumentWithParameter.createDocumentWithParameter(documentGeneration, payload.getDocumentForConfig());
                    documentWithParameter.getDocument().setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
                    documentWithParameter.getDocument().setStatusMessage("Generation handler failed to generate the document");
                    generatedDocuments.add(documentWithParameter);
                }
            }
        }

        return generatedDocuments;
    }
}
