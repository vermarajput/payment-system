package com.gbst.digital.documents.security.composer;

import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.AbstractPermissions;
import com.gbst.common.auth.perms.ConditionalOnPermissionProvider;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.PermissionProviderEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.common.party.PartyTypeEnum;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 7/02/2018
 */
@Service
@Profile("permissions")
@ConditionalOnPermissionProvider(PermissionProviderEnum.Composer)
public class DocumentCleanupPermissions extends AbstractPermissions<List<String>, OperationEnum> implements Permissions<List<String>, OperationEnum> {

    @Override
    public void check(OperationEnum type, List<String> resource) throws GbstJsonApiAccessDeniedException {

        GbstPrincipal principal = authenticationFacade.getPrincipal();
        if(!principal.isClientOnly() && !PartyTypeEnum.SysAdmin.name().equalsIgnoreCase(principal.getGbstPartyType())) {
            throw new GbstJsonApiAccessDeniedException("document-cleanup", principal.getGbstPartyId());
        }
    }
}
