package com.gbst.digital.documents.storage;

import com.gbst.digital.documents.repository.DocumentTestDataHolder;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.Metadata;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.storage.util.MetadataHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * @author rekhar on 16/11/2017
 */
@RunWith(MockitoJUnitRunner.class)
public class MetaDataHelperTest {

    @InjectMocks
    private MetadataHelper metadataHelper;

    @Test
    public void get_metadata_test_WINDWARD_no_documenturl() {
        DocumentWithParameter documentWithParameter = DocumentTestDataHolder.documentWithParameter();
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("DIRECT-DEBIT");
        document.setUrl("/home/documents/DIRECT-DEBIT.pdf");
        document.setGenerationStrategy("WINDWARD");
        documentWithParameter.setDocument(document);

        DocumentAttributes documentAttributes = DocumentTestDataHolder.documentAttributes();
        Metadata metadata = metadataHelper.metadataForDocument(documentWithParameter, documentAttributes);

        assertTrue(metadata.getPayloadId().equals("12345"));
        assertNull(metadata.getDocumentUrl());
    }

    @Test
    public void get_metadata_test_STATIC_documenturl() {
        DocumentWithParameter documentWithParameter = DocumentTestDataHolder.documentWithParameter();
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("STATIC_BOOST_SCHEDULE");
        document.setGenerationStrategy("STATIC");
        document.setUrl("https://gbst.com/static/document1");
        documentWithParameter.setDocument(document);

        DocumentAttributes documentAttributes = DocumentTestDataHolder.documentAttributes();
        Metadata metadata = metadataHelper.metadataForDocument(documentWithParameter, documentAttributes);

        assertTrue(metadata.getPayloadId().equals("12345"));
        assertTrue(metadata.getDocumentUrl().equals("https://gbst.com/static/document1"));
    }
}
