package com.gbst.digital.documents.repository;

import com.gbst.digital.documents.resource.model.*;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.document.SippTransferIn;
import com.gbst.digital.documents.resource.model.document.types.SippTransferTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import org.apache.commons.lang.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DocumentTestDataHolder {

    public static final String test_file_title = "testfile";
    public static final String test_file_type = "txt";

    public static DocumentConfiguration getNullDocConf() {
        return null;
    }

    public static DocumentConfiguration getCorrectWindWardDocConf() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig document = new DocumentForConfig();
        document.setDocumentName(GenerationStrategyEnum.WINDWARD.getValue());
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document.setTemplateFileName("SomeTemplate");

        docConf.setDocuments(Arrays.asList(document));
        return docConf;
    }

    public static DocumentConfiguration getIllustrationDocConf() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id121");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        docConf.setDocuments(Arrays.asList(getIllustrationDocument()));
        return docConf;
    }

    public static DocumentConfiguration getStaticDocConfWithoutUrl() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig document = new DocumentForConfig();
        document.setDocumentName("Static");
        document.setGenerationStrategy(GenerationStrategyEnum.STATIC.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());

        docConf.setDocuments(Arrays.asList(document));
        return docConf;
    }

    public static DocumentConfiguration getNoDocInDocConf() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithDocWithoutStorageSystem() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        DocumentForConfig document1 = new DocumentForConfig();
        document1.setDocumentName("Windward");
        document1.setGenerationStrategy(null);
        document1.setOutputType(OutputTypeEnum.PDF);
        document1.setStorageSystem(null);
        document1.setTemplateFileName("SomeTemplate");
        docConf.setDocuments(Arrays.asList(document1));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithDocWithoutGenerationStrategy() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig document1 = new DocumentForConfig();
        document1.setDocumentName("Windward");
        document1.setGenerationStrategy(null);
        document1.setOutputType(OutputTypeEnum.PDF);
        document1.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document1.setTemplateFileName("SomeTemplate");
        docConf.setDocuments(Arrays.asList(document1));
        return docConf;
    }


    public static DocumentConfiguration getDocuConfWithDocWithoutDocumentDisplayName() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig document1 = new DocumentForConfig();
        document1.setDocumentName("Windward");
        document1.setGenerationStrategy(null);
        document1.setOutputType(OutputTypeEnum.PDF);
        document1.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document1.setTemplateFileName("SomeTemplate");
        docConf.setDocuments(Arrays.asList(document1));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithDocWithoutTemplate() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig doc = new DocumentForConfig();
        doc.setDocumentName("Windward");
        doc.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        doc.setOutputType(OutputTypeEnum.PDF);
        doc.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        docConf.setDocuments(Arrays.asList(doc));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithInvalidProcessTypeOnlyWinwardGeneration() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig doc = new DocumentForConfig();
        doc.setDocumentName("Windward");
        doc.setDocumentDisplayName("Windward");
        doc.setTemplateFileName("winwardTemplate");
        doc.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        doc.setOutputType(OutputTypeEnum.PDF);
        doc.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        docConf.setDocuments(Arrays.asList(doc));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithInvalidProcessTypeForIllustrationGeneration() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");

        DocumentForConfig doc = new DocumentForConfig();
        doc.setDocumentName("WindwardDoc");
        doc.setDocumentDisplayName("Windward");
        doc.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        doc.setOutputType(OutputTypeEnum.PDF);
        doc.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());

        DocumentForConfig doc2 = new DocumentForConfig();
        doc2.setDocumentName("IllustrationDoc");
        doc.setDocumentDisplayName("Windward");
        doc2.setGenerationStrategy(GenerationStrategyEnum.ILLUSTRATION.getValue());
        doc2.setOutputType(OutputTypeEnum.PDF);
        doc2.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        docConf.setDocuments(Arrays.asList(doc,doc2));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithDocWithNoOutputType() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        DocumentForConfig document1 = new DocumentForConfig();
        document1.setDocumentName("Windward");
        document1.setDocumentDisplayName("Windward");
        document1.setGenerationStrategy(null);
        document1.setOutputType(null);
        document1.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document1.setTemplateFileName("SomeTemplate");
        docConf.setDocuments(Arrays.asList(document1));
        return docConf;
    }

    public static DocumentConfiguration getDocuConfWithNoTemplateForWINWARD() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        DocumentForConfig document1 = new DocumentForConfig();
        document1.setDocumentName("Windward");
        document1.setDocumentDisplayName("Windward");
        document1.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document1.setOutputType(null);
        document1.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document1.setTemplateFileName(null);
        docConf.setDocuments(Arrays.asList(document1));
        return docConf;
    }

    public static DocumentGeneration getDocumentGenerationRequest(String role, String stage, String processtype, String processTypeId, String processId) {
        DocumentGeneration req = new DocumentGeneration();
        if (!StringUtils.isEmpty(role)) {
            req.setRole(role);
        }
        if (!StringUtils.isEmpty(stage)) {
            req.setProcessStage(stage);
        }
        if (!StringUtils.isEmpty(processtype)) {
            req.setProcessType(processtype);
        }
        if (!StringUtils.isEmpty(processTypeId)) {
            req.setProcessTypeId(processTypeId);
        }
        if (!StringUtils.isEmpty(processId)) {
            req.setProcessId(processId);
        }
        return req;
    }

    public static String getPayloadStringWithSIPPTransferIns_WithTransferAuthorityFlag() throws IOException {
        return "{" +
                "\"sippTransferIns\": [" +
                "{" +
                "\"transferAuthorityFlag\": \"true\"" +
                "}" +
                "]" +
                "}";
    }

    public static String getPayloadStringWithISATransferIns_WithTransferAuthorityFlag() throws IOException {
        return "{" +
                "\"isaTransferIns\": [" +
                "{" +
                "\"transferAuthorityFlag\": \"true\"" +
                "}" +
                "]" +
                "}";
    }

    public static String getPayloadStringWithTransferIns_WithNoTransferAuthorityFlag() throws IOException {
        return "{" +
                "\"sippTransferIns\": [" +
                "{" +
                "\"transferAuthorityFlag\": \"false\"" +
                "}," +
                "{" +
                "\"transferAuthorityFlag\": \"false\"" +
                "}" +
                "]" +
                "}";
    }

    public static String getPayloadStringWithNoData() throws IOException {
        return "{}";
    }

    public static String getPayloadStringWith_RegularContributions_Investor() {
        return "{" +
                    "\"regularContributions\": [" +
                    "{" +
                    "\"amount\": \"1234\"," +
                    "\"contributorType\": \"Investor\"" +
                    "}," +
                    "{" +
                    "\"amount\": \"1234\"," +
                    "\"contributorType\": null" +
                    "}" +
                    "]" +
                    "}";
    }

    public static String getPayloadStringWith_RegularContributions_Employer() {
        return "{" +
                "\"regularContributions\": [" +
                "{" +
                "\"amount\": \"1234\"," +
                "\"contributorType\": \"Employer\"" +
                "}," +
                "{" +
                "\"amount\": \"1234\"," +
                "\"contributorType\": \"Employer\"" +
                "}" +
                "]" +
                "}";
    }

    public static DocumentForGeneration getDocument() {
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("Illustration");
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setTemplateFileName("DocumentAttributes_JSON.docx");
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        return document;
    }

    public static DocumentForConfig getDirectDebitDocument() {
        DocumentForConfig document = new DocumentForConfig();
        document.setDocumentName("DIRECT_DEBIT_INSTRUCTION");
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setTemplateFileName("DocumentAttributes_JSON.docx");
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        return document;
    }

    public static DocumentForConfig getIllustrationDocument() {
        DocumentForConfig document = new DocumentForConfig();
        document.setDocumentName(GenerationStrategyEnum.ILLUSTRATION.getValue());
        document.setGenerationStrategy(GenerationStrategyEnum.ILLUSTRATION.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());

        return document;
    }

    public static DocumentForGeneration getDocumentWithGeneratedStatus() {
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("Illustration");
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setTemplateFileName("DocumentAttributes_JSON.docx");
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document.setGenerationStatus(GenerationStatusEnum.GENERATED);
        document.setUrl("someurl");
        return document;
    }

    public static DocumentForGeneration getDocumentInvalidStorage() {
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("Illustration");
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setTemplateFileName("DocumentAttributes_JSON.docx");
        document.setStorageSystem("VICHITRA_SYSTEM");
        document.setGenerationStatus(GenerationStatusEnum.GENERATED);
        return document;
    }

    public static DocumentGeneration getDocGeneration() {
        DocumentGeneration documentGeneration = getDocumentGenerationRequest("advisor", "pre-submit", "New-Business", "17", "2342");
        DocumentAttributes documentAttributes = new DocumentAttributes();
        documentAttributes.setInvestorFirstName("Rekha");
        documentAttributes.setInvestorLastName("Krishnan Ramachandran");
        documentAttributes.setQuoteId("1123-45468");
        documentAttributes.setInvestorEmailAddress("abc.dc@test.com");
        SippTransferIn transfer = new SippTransferIn();
        transfer.setAmount(new BigDecimal(12.00));
        transfer.setTransferType(SippTransferTypeEnum.StandardTransfer);
        transfer.setInitialChargeAmount(new BigDecimal(1.00));
        transfer.setSchemeAddress("Standard");
        SippTransferIn transfer1 = new SippTransferIn();
        transfer1.setAmount(new BigDecimal(15.00));
        transfer1.setTransferType(SippTransferTypeEnum.BlockTransfer);
        transfer1.setInitialChargeAmount(new BigDecimal(10.00));
        transfer1.setSchemeAddress("Standard");
        List<SippTransferIn> transferList = new ArrayList<>();
        transferList.add(transfer);
        transferList.add(transfer1);

        documentAttributes.setSippTransferIns(transferList);
        documentGeneration.setDocumentAttributes(documentAttributes.toString());
        return documentGeneration;

    }

    public static String getDocumentAttributesPayload() {
        String documentAttributes = "      \"documentAttributes\":" +
                "      {" +
                "      \"quoteId\": \"123-4568-125\"," +
                "      \"partyType\": \"adviser\"," +
                "      \"investorFirstName\": \"Rekha\"," +
                "      \"investorLastName\": \"Krishnan\"," +
                "      \"investorDateOfBirth\": \"2001-01-01\"," +
                "      \"investorGender\": \"Male\"," +
                "      \"investorExpectedRetirementAge\": 60," +
                "      \"investorEmailAddress\": \"a.a@test.com\"," +
                "      \"productTypeId\": 1," +
                "      \"policyNumber\": \"string\"," +
                "      \"annuityFrequency\": \"Monthly\"," +
                "      \"annuityTiming\": \"InAdvance\"," +
                "      \"annuityGuarantee\": \"0\"," +
                "      \"annuityEscalation\": \"0\"," +
                "      \"dependantPensionPercent\": \"23\"," +
                "      \"dependantDateOfBirth\": \"2001-01-01\"," +
                "      \"dependantGender\": \"Female\"," +
                "      \"dependantPersonalisePensionFlag\": \"N\"," +
                "      \"status\": \"Open\"," +
                "      \"ongoingAdviserChargeAmount\": \"1\"," +
                "      \"ongoingAdviserChargeFrequency\": \"Monthly\"," +
                "      \"singleContributions\": [" +
                "        {" +
                "          \"amount\": \"566\"," +
                "          \"contributorType\": \"Investor\"," +
                "          \"initialChargeAmount\": \"123.45\"" +
                "        }," +
                "        {" +
                "          \"amount\": \"566\"," +
                "          \"contributorType\": \"Investor\"," +
                "          \"initialChargeAmount\": \"123.45\"" +
                "        }" +
                "      ]," +
                "      \"regularContributions\": [" +
                "        {" +
                "          \"amount\": \"456.12\"," +
                "          \"contributorType\": \"Investor\"," +
                "          \"initialChargePercent\": \"100\"," +
                "          \"frequency\": \"Half-Yearly\"," +
                "          \"indexByRPIFlag\": true," +
                "          \"initialChargeTerm\": 1" +
                "        }" +
                "      ]," +
                "      \"transferIns\": [" +
                "        {" +
                "          \"transferType\": \"StandardTransfer\"," +
                "          \"amount\": \"12\"," +
                "          \"scheme\": \"1\"," +
                "          \"schemeAddress\": \"Standrad\"," +
                "          \"schemePolicyNumber\": \"12345\"," +
                "          \"schemeTelephone\": \"+61 1234567889\"," +
                "          \"transferAuthorityFlag\": true," +
                "          \"fullPartialFlag\": \"Full\"," +
                "          \"occupationalSchemeFlag\": true," +
                "          \"definedBenefitsSchemeFlag\": true," +
                "          \"disqualifiedPensionCreditFlag\": true," +
                "          \"protectedPCLS\": \"123.45\"," +
                "          \"protectedAge\": 52," +
                "          \"updateRetirementAgeFlag\": true," +
                "          \"initialChargeAmount\": \"100\"" +
                "        }," +
                "        {" +
                "          \"transferType\": \"BlockTransfer\"," +
                "          \"amount\": \"456.12\"," +
                "          \"scheme\": \"123\"," +
                "          \"schemeAddress\": \"Standrad\"," +
                "          \"schemePolicyNumber\": \"12345\"," +
                "          \"schemeTelephone\": \"+61 1234567889\"," +
                "          \"transferAuthorityFlag\": true," +
                "          \"fullPartialFlag\": \"Full\"," +
                "          \"occupationalSchemeFlag\": true," +
                "          \"definedBenefitsSchemeFlag\": true," +
                "          \"disqualifiedPensionCreditFlag\": true," +
                "          \"protectedPCLS\": \"123.45\"," +
                "          \"protectedAge\": 52," +
                "          \"updateRetirementAgeFlag\": true," +
                "          \"initialChargeAmount\": \"100\"" +
                "        }" +
                "      ]," +
                "      \"owner\": \"nehas\"" +
                "      }";

        return documentAttributes;

    }

    public static String getPayloadStringWith_NoRegularContributions_ApplyBoostFlagTrue() throws IOException {
        return "{\"applyBoostFlag\":\"true\"}";
    }

    public static String getPayloadStringWith_NoRegularContributions_ApplyBoostFlagFalse() throws IOException {
        return "{\"applyBoostFlag\":\"false\"}";
    }

    public static String getPayloadStringWith_ApplyBoostFlagTrue_UnknownField() throws IOException {
        return "{\"applyBoostFlag\":\"true\", " +
                "\"unknownField123\":\"someVal\"}";
    }


    public static DocumentForGeneration getDocumentWithInvalidName() {
        DocumentForGeneration doc = new DocumentForGeneration();
        doc.setUrl(null);
        doc.setOutputType(OutputTypeEnum.PDF);
        doc.setDocumentName("InvalidName");
        doc.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        return doc;
    }


    public static DocumentForConfig getStaticDocument() {
        DocumentForConfig document = new DocumentForConfig();
        document.setDocumentName("Static");
        document.setGenerationStrategy(GenerationStrategyEnum.STATIC.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        document.setUrl("SomeUrl.Url");
        return document;
    }

    public static DocumentConfiguration getStaticDocConfWithStorageSystem() {
        DocumentConfiguration docConf = new DocumentConfiguration();
        docConf.setProcessTypeId("id123");
        docConf.setProcessType("NB");
        docConf.setProcessStage("pre-submit");
        docConf.setRole("paraplanner");
        docConf.setDocuments(Arrays.asList(getStaticDocument()));
        return docConf;
    }

    public static DocumentAttributes documentAttributes() {
        DocumentAttributes attr = new DocumentAttributes();
        attr.setQuoteId("123456");
        attr.setAdviserId("123");
        attr.setOwnerTypeId("3");
        attr.setOwnerId("123456");
        attr.setInvestorFirstName("Rekha");
        attr.setInvestorLastName("Ram");
        attr.setDateTimeLastModified(Instant.now());
        return attr;
    }

    public static DocumentWithParameter documentWithParameter() {
        DocumentWithParameter documentWithParameter = new DocumentWithParameter();
        documentWithParameter.setProcessId("12345");
        documentWithParameter.setProcessType("NEW_BUSINESS");
        documentWithParameter.setProcessStage("post-submission");
        documentWithParameter.setProcessTypeId("19");
        documentWithParameter.setRole("advisor");
        documentWithParameter.setGeneratedDocumentStream(dummyOutputStream());
        documentWithParameter.setPayload("{ \"quoteId\": \"1234568125\",\"partyId\":\"123456\", \"partyType\": \"3\", \"adviserId\": \"123\", \"investorFirstName\": \"Rekha\", \"investorLastName\": \"Krishnan\", \"dateLastModified\": \"2001-01-01\", \"owner\": \"rekhar\" }");
        return documentWithParameter;
    }

    public static ByteArrayOutputStream dummyOutputStream() {
        File file = null;
        ByteArrayOutputStream outputStream = null;
        try {
            file = File.createTempFile(test_file_title, test_file_type);
            outputStream = new ByteArrayOutputStream((int) file.length());
        } catch (IOException e) {
        }
        return outputStream;
    }
}
