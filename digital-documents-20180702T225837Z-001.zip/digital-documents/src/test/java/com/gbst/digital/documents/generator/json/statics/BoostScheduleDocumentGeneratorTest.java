package com.gbst.digital.documents.generator.json.statics;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.BaseDocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.PayloadFormatEnum;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.uk.response.Product;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 4/04/2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BoostScheduleDocumentGeneratorTest {

    ObjectMapper mapper = new ObjectMapper();
    DocumentPayloadFactory documentPayloadFactory = new DocumentPayloadFactory(mapper);

    @Mock
    ProductService productService;

    @InjectMocks
    BoostScheduleDocumentGenerator boostScheduleDocumentGenerator;

    @Before
    public void setup() {
        reset(productService);
        when(productService.isISA(anyString())).thenReturn(true);

        ProductTypes.ProductType productType = new ProductTypes.ProductType(new Product());
        productType.getDetails().setProductFlag("A");
        when(productService.getProductType(19)).thenReturn(productType);
    }

    @Test
    public void supports_ISA() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"BOOST_ALLOWED\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());
        
        assertTrue(boostScheduleDocumentGenerator.supports(doc, payload));
    }

    @Test
    public void supports_ISA_no_BoostAllowed() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"NO\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
    }

    @Test
    public void supports_new_business_and_accumulation() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"BOOST_ALLOWED\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.NEW_BUSINESS.name());
        
        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertTrue(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService).getProductType(19);
    }

    @Test
    public void supports_new_business_and_accumulation_no_BoostAllowed() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"NO\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.NEW_BUSINESS.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
    }

    @Test
    public void supports_drawdown() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"BOOST_ALLOWED\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertTrue(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);

    }

    @Test
    public void supports_drawdown_no_BoostAllowed() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);

    }


    @Test
    public void supports_not_vitality_asset() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);
    }

    @Test
    public void supports_full_crystallise_amount() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"BOOST_ALLOWED\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"crystalliseFullAmountFlag\":\"true\",\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);
    }

    @Test
    public void supports_BuyInvestment_Vitality_Asset() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"crystalliseFullAmountFlag\":\"false\",\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\",\"trade\":{\"tradeType\":\"Buy\",\"cashReservePurpose\":\"Savings\",\"buyInvestments\":[{\"assetAttribute\":\"BOOST_ALLOWED\"}]}}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertTrue(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);
    }

    @Test
    public void supports_BuyInvestment_Vitality_Asset_no_BoostAllowed() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"crystalliseFullAmountFlag\":\"false\",\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\",\"trade\":{\"tradeType\":\"Buy\",\"cashReservePurpose\":\"Savings\",\"buyInvestments\":[{\"assetAttribute\":\"YES\"}]}}";

        DocumentGeneration doc = new DocumentGeneration();
        doc.setProcessType(ProcessType.DRAWDOWN.name());

        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.STATIC.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.STATIC_BOOST_SCHEDULE.name());

        assertFalse(boostScheduleDocumentGenerator.supports(doc, payload));
        verify(productService, times(0)).getProductType(19);
    }

}