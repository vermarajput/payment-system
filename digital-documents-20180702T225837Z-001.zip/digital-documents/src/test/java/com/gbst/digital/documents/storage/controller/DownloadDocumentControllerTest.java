package com.gbst.digital.documents.storage.controller;


import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.ResourceNotFoundException;
import com.gbst.digital.documents.exception.ServletRunTimeException;
import com.gbst.digital.documents.repository.DocumentGenerationJsonApiRepository;
import com.gbst.digital.documents.repository.DownloadAndCleanupDelegator;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import com.gbst.digital.documents.storage.util.FileSystemStorageUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.owasp.esapi.HTTPUtilities;
import org.springframework.data.mongodb.core.MongoTemplate;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.getDocumentWithGeneratedStatus;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DownloadDocumentControllerTest {

    private static final String DOCUMENT_KEY = "123" ;
    private static final String DOCUMENT_GENERATION_ID = "52356947fdf36" ;

    @Mock
    private DownloadAndCleanupDelegator downloadAndCleanupDelegator;

    @Mock
    private HttpServletRequest mockRequest;

    @Mock
    private HttpServletResponse mockResponse;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private ServletContext mockServletContext;

    @Mock
    private ServletOutputStream mockOutputStream;

    @InjectMocks
    private DownloadDocumentController downloadDocumentController;

    @Mock
    private DocumentGenerationJsonApiRepository documentGenerationJsonApiRepository;

    @Mock
    Permissions<DocumentGeneration, OperationEnum> documentGenerationPermissions;

    @Mock
    private FileSystemStorageUtil fileSystemStorageUtil;

    @Mock
    private DocumentGeneration documentGeneration;

    @Mock
    private HTTPUtilities httpUtilities;

    @Test(expected = ServletRunTimeException.class)
    public void testDocumentKeyNotProvided() throws Exception {
        downloadDocumentController.download(mockRequest,mockResponse,null);
    }

    @Test(expected = ServletRunTimeException.class)
    public void testBlankDocumentGeneration() throws Exception {
        when(mongoTemplate.findOne(any(),any())).thenReturn(null);
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test(expected = ServletRunTimeException.class)
    public void testDocumentDownloadNoDocument() throws Exception {
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObjNoDocResponse());
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test(expected = ServletRunTimeException.class)
    public void testDocumentDownloadStaticDocument() throws Exception {
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObjSTATIC());
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test(expected = ServletRunTimeException.class)
    public void testDocumentDownloadGenerationFailedDocument() throws Exception {
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObjGenFailed());
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test(expected = ServletRunTimeException.class)
    public void testDocumentFetchFileNotPresentInStorage() throws Exception {
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObj());
        when(mockRequest.getServletContext()).thenReturn(mockServletContext);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);
        when(mockServletContext.getMimeType(any())).thenReturn("application/pdf");
        when(downloadAndCleanupDelegator.downloadDocumentsFromStorageSystems(any(),any())).thenReturn(null);
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test
    public void testDocumentFetchFilePresentInStorage() throws Exception {
        File file = File.createTempFile( "some-name", "pdf");
        file.deleteOnExit();
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObj());
        when(mockRequest.getServletContext()).thenReturn(mockServletContext);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);
        when(mockServletContext.getMimeType(any())).thenReturn("application/pdf");
        when(downloadAndCleanupDelegator.downloadDocumentsFromStorageSystems(any(),any())).thenReturn(file);
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);

        verify(httpUtilities).setCurrentHTTP(mockRequest, mockResponse);
        verify(httpUtilities).addHeader("Content-Type", "application/pdf");
        verify(httpUtilities).addHeader("Content-Length", "0");
        verify(httpUtilities).addHeader(eq("Content-Disposition"), startsWith("attachment; filename="));
    }

    @Test
    public void testDocumentFetchFilePresentInDMSStorage() throws Exception {
        File file = File.createTempFile( "some-name", "pdf");
        file.deleteOnExit();
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObjDMS());
        when(mockRequest.getServletContext()).thenReturn(mockServletContext);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);
        when(mockServletContext.getMimeType(any())).thenReturn("application/pdf");
        when(downloadAndCleanupDelegator.downloadDocumentsFromStorageSystems(any(),any())).thenReturn(file);
        downloadDocumentController.download(mockRequest,mockResponse,DOCUMENT_KEY);
    }

    @Test(expected = ServletRunTimeException.class)
    public void test_DocumentGenerationId_NotProvided() throws Exception {
        downloadDocumentController.downloadZip(mockRequest,mockResponse,null);
    }

    @Test(expected = ResourceNotFoundException.class)
    public void test_Blank_DocumentGeneration_Id() throws Exception {
        when(documentGenerationJsonApiRepository.findOne("52356947fdf36",null)).thenThrow(ResourceNotFoundException.class);
        downloadDocumentController.downloadZip(mockRequest,mockResponse,DOCUMENT_GENERATION_ID);
    }

    @Test
    public void testDocumentFetchZipPresentInStorage() throws Exception {
        File file = File.createTempFile( "some-name", "zip");
        file.deleteOnExit();
        when(mongoTemplate.findOne(any(),any())).thenReturn(testDocGenObj());
        when(mockRequest.getServletContext()).thenReturn(mockServletContext);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);
        when(mockServletContext.getMimeType(any())).thenReturn("application/zip");
        when(documentGenerationJsonApiRepository.findOne(any(),any())).thenReturn(documentGeneration);
        doNothing().when(documentGenerationPermissions).check(OperationEnum.FindOne, documentGeneration);
        when(documentGeneration.getProcessId()).thenReturn("process1234");
        when(documentGeneration.getDocuments()).thenReturn(Arrays.asList(getDocumentWithGeneratedStatus()));
        when(fileSystemStorageUtil.performDocumentDownloadOperation(any())).thenReturn(File.createTempFile("someFile", "pdf"));
        downloadDocumentController.downloadZip(mockRequest,mockResponse,DOCUMENT_GENERATION_ID);

        verify(httpUtilities).setCurrentHTTP(mockRequest, mockResponse);
        verify(httpUtilities).addHeader("Content-Type", "application/zip");
        verify(httpUtilities).addHeader("Content-Length", "148");
        verify(httpUtilities).addHeader(eq("Content-Disposition"), startsWith("attachment; filename="));
    }

    private Object testDocGenObjGenFailed() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("111T4");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        DocumentForGeneration response = new DocumentForGeneration();
        response.setTemplateFileName("templatexxx.doc");
        response.setDocumentName("one");
        response.setStorageSystem("FILESYSTEM");
        response.setGenerationStatus(GenerationStatusEnum.GENERATION_FAILED);
        response.setDocumentKey(DOCUMENT_KEY);
        List<DocumentForGeneration> responseList = new ArrayList<>();
        responseList.add(response);
        obj.setDocuments(responseList);
        return obj;
    }

    private DocumentGeneration testDocGenObj() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("111T4");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        DocumentForGeneration response = new DocumentForGeneration();
        response.setTemplateFileName("templatexxx.doc");
        response.setOutputType(OutputTypeEnum.PDF);
        response.setUrl("http://fsfsf.com");
        response.setDocumentName("one");
        response.setGeneratedDate(Instant.now());
        response.setStorageSystem("FILESYSTEM");
        response.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        response.setGenerationStatus(GenerationStatusEnum.GENERATED);
        response.setDocumentKey(DOCUMENT_KEY);
        List<DocumentForGeneration> responseList = new ArrayList<>();
        responseList.add(response);
        obj.setDocuments(responseList);
        return obj;
    }

    private DocumentGeneration testDocGenObjNoDocResponse() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("111T4");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        return obj;
    }

    private DocumentGeneration testDocGenObjDMS() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("111T4");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        DocumentForGeneration response = new DocumentForGeneration();
        response.setTemplateFileName("templatexxx.doc");
        response.setOutputType(OutputTypeEnum.PDF);
        response.setUrl("http://fsfsf.com");
        response.setDocumentName("one");
        response.setGeneratedDate(Instant.now());
        response.setStorageSystem("CMISDMS");
        response.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        response.setGenerationStatus(GenerationStatusEnum.GENERATED);
        response.setDocumentKey(DOCUMENT_KEY);
        List<DocumentForGeneration> responseList = new ArrayList<>();
        responseList.add(response);
        obj.setDocuments(responseList);
        return obj;
    }

    private DocumentGeneration testDocGenObjSTATIC() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("111T4");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        DocumentForGeneration response = new DocumentForGeneration();
        response.setOutputType(OutputTypeEnum.PDF);
        response.setUrl("http://fsfsf.com");
        response.setGenerationStrategy(GenerationStrategyEnum.STATIC.getValue());
        response.setGenerationStatus(GenerationStatusEnum.GENERATED);
        response.setDocumentKey(DOCUMENT_KEY);
        List<DocumentForGeneration> responseList = new ArrayList<>();
        responseList.add(response);
        obj.setDocuments(responseList);
        return obj;
    }
}
