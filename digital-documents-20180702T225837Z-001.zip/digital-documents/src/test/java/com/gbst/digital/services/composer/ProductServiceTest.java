package com.gbst.digital.services.composer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.common.rest.JsonRequestBuilder;
import com.gbst.digital.Services;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.uk.request.GetProductDetailsType;
import com.infocomp.cbis.uk.response.ObjectFactory;
import com.infocomp.cbis.uk.response.Fund;
import com.infocomp.cbis.uk.response.Product;
import com.infocomp.cbis.uk.response.ProductDetailsType;
import com.infocomp.cbis.uk.response.SubFund;
import org.jsondoc.core.annotation.ApiObjectField;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;

import javax.xml.bind.JAXBElement;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 2/11/2017
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductServiceTest {

    private static final ObjectFactory objectFactory = new ObjectFactory();
    private static String template = "{\"data\" : [{\"id\" : 12, \"attributes\" : $ROW_ONE }, {\"id\" : 14, \"attributes\" : $ROW_TWO }]}";
    
    @Spy
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Mock
    private WebServiceTemplate webServiceTemplate;

    @InjectMocks
    ProductService productService;

    @Captor
    ArgumentCaptor<JAXBElement> requestCaptor;

    @Mock
    OAuth2RestTemplate restOperations;

    @Spy
    ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setup() {
        multiUrlConnectionSettings.setConnections(new HashMap<>());
        multiUrlConnectionSettings.getConnections().put(Services.CBIS, new MultiUrlConnectionSettings.Conn());
        multiUrlConnectionSettings.getConnections().get(Services.CBIS).setUrl("some url");

        multiUrlConnectionSettings.getConnections().put(Services.COMPOSER, new MultiUrlConnectionSettings.Conn());
        multiUrlConnectionSettings.getConnections().get(Services.COMPOSER).setUrl("http://url/api");

        ProductDetailsType type = new ProductDetailsType();
        type.setFunds(new ProductDetailsType.Funds());
        Fund fund = new Fund();
        fund.setSubfunds(new Fund.Subfunds());
        SubFund subfund = new SubFund();
        subfund.setSubFundId(1);
        subfund.setSubFundName("subfund name");
        subfund.setSubFundShortCode("SN");
        subfund.setProducts(new SubFund.Products());
        // Accumulation
        Product p100 = new Product();
        p100.setProductTypeId(100);
        p100.setProductFlag("A");
        subfund.getProducts().getProduct().add(p100);
        //Pension
        Product p101 = new Product();
        p101.setProductTypeId(101);
        p101.setProductFlag("P");
        subfund.getProducts().getProduct().add(p101);
        //Some other product
        Product p200 = new Product();
        p200.setProductTypeId(200);
        p200.setProductFlag("X");
        subfund.getProducts().getProduct().add(p200);

        fund.getSubfunds().getSubfund().add(subfund);
        type.getFunds().getFund().add(fund);
        JAXBElement<ProductDetailsType> response = objectFactory.createProductDetails(type);
        
        Mockito.when(webServiceTemplate.marshalSendAndReceive(anyString(), any(JAXBElement.class))).thenReturn(response);
    }

    @Test
    public void getProductTypes() throws Exception {
        ProductTypes result = productService.getProductTypes(1, 2, 3, true, true);
        Mockito.verify(webServiceTemplate).marshalSendAndReceive(anyString(), requestCaptor.capture());

        JAXBElement<GetProductDetailsType> request = requestCaptor.getValue();
        assertEquals(Integer.valueOf(1), request.getValue().getSubFundId());
        assertEquals(Integer.valueOf(2), request.getValue().getProductTypeId());
        assertEquals(Integer.valueOf(3), request.getValue().getInvestmentId());
        assertEquals("Y", request.getValue().getActiveFlag());
        assertEquals("Y", request.getValue().getIncludeInvestments());

        assertFalse(result.getProductTypes().isEmpty());
        for(ProductTypes.ProductType p : result.getProductTypes()) {
            assertEquals(1, p.getSubFundId());
            if(p.getDetails().getProductTypeId() == 100) {
                assertEquals("A", p.getDetails().getProductFlag());
            } else if(p.getDetails().getProductTypeId() == 101) {
                assertEquals("P", p.getDetails().getProductFlag());
            } else if(p.getDetails().getProductTypeId() == 200) {
                assertEquals("X", p.getDetails().getProductFlag());
            } 
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void getAssociatedIDDProductType_nonAccumulationProduct() throws Exception {
        productService.getAssociatedIDDProductType(101);
    }

    @Test
    public void getAssociatedIDDProductType() throws Exception {
        ProductTypes.ProductType iddProduct = productService.getAssociatedIDDProductType(100);

        assertEquals(101, iddProduct.getDetails().getProductTypeId());
        assertEquals("P", iddProduct.getDetails().getProductFlag());
    }

    @Test
    public void isISA_product_flag_is_i_and_has_tax_wrapper() throws Exception {
        String template = "{\"data\" : [{\"id\" : 12, \"attributes\" : $ROW_ONE }, {\"id\" : 14, \"attributes\" : $ROW_TWO }]}";

        ProductWebEnabled pwe1 = new ProductWebEnabled();
        pwe1.setProductFlag("A");

        ProductWebEnabled pwe2 = new ProductWebEnabled();
        pwe2.setProductFlag("I");
        pwe2.setTaxWrapperTypeCode(new ArrayList<>());
        TaxWrapperTypeCode tw = new TaxWrapperTypeCode();
        tw.setCode("blah blah");
        pwe2.getTaxWrapperTypeCode().add(tw);

        String body = template.replace("$ROW_ONE", mapper.writeValueAsString(pwe1))
                .replace("$ROW_TWO", mapper.writeValueAsString(pwe2));
        ResponseEntity<?> response = new ResponseEntity<String>(body, HttpStatus.OK);

        Mockito.when(restOperations.getForEntity(any(URI.class), any())).thenReturn((ResponseEntity<Object>) response);

        boolean isISA = productService.isISA("12");

        assertFalse("Should not be ISA", isISA);

        isISA = productService.isISA("14");

        assertTrue("Should be ISA", isISA);
    }

    @Test
    public void isISA_product_flag_is_i_but_not_isa() throws Exception {


        ProductWebEnabled pwe1 = new ProductWebEnabled();
        pwe1.setProductFlag("A");

        ProductWebEnabled pwe2 = new ProductWebEnabled();
        pwe2.setProductFlag("I");

        String body = template.replace("$ROW_ONE", mapper.writeValueAsString(pwe1))
                .replace("$ROW_TWO", mapper.writeValueAsString(pwe2));
        ResponseEntity<?> response = new ResponseEntity<String>(body, HttpStatus.OK);

        Mockito.when(restOperations.getForEntity(any(URI.class), any())).thenReturn((ResponseEntity<Object>) response);

        boolean isISA = productService.isISA("12");

        assertFalse("Should not be ISA", isISA);

        isISA = productService.isISA("14");

        assertFalse("Should not be ISA", isISA);
    }

    @Test
    public void isISA_product_flag_isNot_i() throws Exception {


        ProductWebEnabled pwe1 = new ProductWebEnabled();
        pwe1.setProductFlag("A");

        ProductWebEnabled pwe2 = new ProductWebEnabled();
        pwe2.setProductFlag("P");
        pwe2.setTaxWrapperTypeCode(new ArrayList<>());
        TaxWrapperTypeCode tw = new TaxWrapperTypeCode();
        tw.setCode("blah blah");
        pwe2.getTaxWrapperTypeCode().add(tw);

        String body = template.replace("$ROW_ONE", mapper.writeValueAsString(pwe1))
                .replace("$ROW_TWO", mapper.writeValueAsString(pwe2));
        ResponseEntity<?> response = new ResponseEntity<String>(body, HttpStatus.OK);

        Mockito.when(restOperations.getForEntity(any(URI.class), any())).thenReturn((ResponseEntity<Object>) response);

        boolean isISA = productService.isISA("12");

        assertFalse("Should not be ISA", isISA);

        isISA = productService.isISA("14");

        assertFalse("Should not be ISA", isISA);
    }

    public static class ProductWebEnabled {
        private Integer productTypeId;
        private String name;
        private String shortCode;
        private String productFlag;
        private List<TaxWrapperTypeCode> taxWrapperTypeCode;

        public Integer getProductTypeId() {
            return productTypeId;
        }

        public void setProductTypeId(Integer productTypeId) {
            this.productTypeId = productTypeId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getShortCode() {
            return shortCode;
        }

        public void setShortCode(String shortCode) {
            this.shortCode = shortCode;
        }

        public String getProductFlag() {
            return productFlag;
        }

        public void setProductFlag(String productFlag) {
            this.productFlag = productFlag;
        }

        public List<TaxWrapperTypeCode> getTaxWrapperTypeCode() {
            return taxWrapperTypeCode;
        }

        public void setTaxWrapperTypeCode(List<TaxWrapperTypeCode> taxWrapperTypeCode) {
            this.taxWrapperTypeCode = taxWrapperTypeCode;
        }
    }


    private static class TaxWrapperTypeCode {
        private String code;
        private boolean juniorISAFlag;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public boolean isJuniorISAFlag() {
            return juniorISAFlag;
        }

        public void setJuniorISAFlag(boolean juniorISAFlag) {
            this.juniorISAFlag = juniorISAFlag;
        }
    }
}