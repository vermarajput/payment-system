package com.gbst.digital.documents.scheduler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.Metadata;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.util.MetadataHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.documentAttributes;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * @author rekhar on 12/03/2018
 */
@RunWith(MockitoJUnitRunner.class)
public class ScheduledTasksTest {

    @InjectMocks
    private ScheduledTasks scheduledTasks;

    @Mock
    private DocumentStorageTaskService documentStorageTaskService;

    @Mock
    private MongoTemplate mongoTemplate;

    @Spy
    private MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private MetadataHelper metadataHelper;

    @Before
    public void setup(){
        multiUrlConnectionSettings.setConnections(new HashMap<>());
        multiUrlConnectionSettings.getConnections().put(Services.STORAGE, new MultiUrlConnectionSettings.Conn());
        multiUrlConnectionSettings.getConnections().get(Services.STORAGE).setUrl("url");
    }

    @Test
    public void testStoreDMSDocuments_No_Documents_ToProcess(){
        List<DocumentGeneration> documentGenerationList = new ArrayList<>();
        when(mongoTemplate.find(any(), eq(DocumentGeneration.class))).thenReturn(documentGenerationList);
        scheduledTasks.storeDMSDocuments();
        assertEquals(documentGenerationList.size(), 0);
    }

    @Test
    public void testStoreDMSDocuments_Documents_ToProcess() throws IOException {
        List<DocumentGeneration> documentGenerationList = new ArrayList<>();
        documentGenerationList.add(prepareDocumentListInput());
        when(mongoTemplate.find(any(), eq(DocumentGeneration.class))).thenReturn(documentGenerationList);
        when(mapper.readValue(prepareDocumentListInput().getDocumentAttributes(), DocumentAttributes.class)).thenReturn(documentAttributes());
        Metadata metadata = getMetadata();
        when(metadataHelper.metadataForDocument(any(), any())).thenReturn(metadata);
        when(mapper.writeValueAsString(any())).thenReturn("{\"  \"partyId\": 1,  \"partyTypeId\": 3,  \"firstName\": \"Rekha\",  \"surName\": \"Krishnan\",  \"payloadId\": \"21404\",  \"adviserId\": 123\" }");
        scheduledTasks.storeDMSDocuments();
        assertEquals(documentGenerationList.size(), 1);
    }

    private DocumentGeneration prepareDocumentListInput() {
        DocumentGeneration req = new DocumentGeneration();
        req.setId("123423543543656");
        req.setProcessTypeId("17");
        req.setProcessType("NEW_BUSINESS");
        req.setProcessStage("pre-submission");
        req.setRole("Advisor");
        req.setProcessId("21034");
        req.setDocumentAttributes(getDocumentAttributes());
        DocumentForGeneration document = this.getDocument();
        List<DocumentForGeneration> documentList = new ArrayList<>();
        documentList.add(document);
        req.setDocuments(documentList);
        return req;
    }

    public DocumentForGeneration getDocument() {
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName("Illustration");
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setOutputType(OutputTypeEnum.PDF);
        document.setTemplateFileName("DocumentAttributes_JSON.docx");
        document.setStorageSystem(StorageSystemEnum.CMISDMS.getValue());
        document.setGenerationStatus(GenerationStatusEnum.GENERATED);
        return document;
    }

    public String getDocumentAttributes() {
        return "{ \"quoteId\": \"21404\",\"ownerId\":\"1\", \"ownerType\": \"Investor\", \"adviserId\": \"123\", \"investorFirstName\": \"Rekha\", \"investorLastName\": \"Krishnan\", \"investorDateOfBirth\": \"2001-01-01\", \"investorGender\": \"Male\", \"investorExpectedRetirementAge\": 60, \"investorEmailAddress\": \"a.a@test.com\", \"productTypeId\": 19, \"policyNumber\": \"string\", \"annuityFrequency\": \"Monthly\", \"annuityTiming\": \"InAdvance\", \"annuityGuarantee\": \"0\", \"annuityEscalation\": \"0\", \"dependantPensionPercent\": \"23\", \"dependantDateOfBirth\": \"2001-01-01\", \"dependantGender\": \"Female\", \"dependantPersonalisePensionFlag\": true, \"status\": \"Open\", \"ongoingAdviserChargeAmount\": \"1\", \"ongoingAdviserChargeFrequency\": \"Monthly\", \"singleContributions\": [ { \"amount\": \"566\", \"contributorType\": \"Investor\", \"initialChargeAmount\": \"123.45\" }, { \"amount\": \"566\", \"contributorType\": \"Investor\", \"initialChargeAmount\": \"123.45\" } ], \"regularContributions\": [ { \"amount\": \"456.12\", \"contributorType\": \"Investor\", \"initialChargePercent\": \"100\", \"frequency\": \"Half-Yearly\", \"indexByRPIFlag\": true, \"initialChargeTerm\": 1 } ], \"sippTransferIns\": [ { \"transferType\": \"BlockTransfer\", \"amount\": \"456.12\", \"scheme\": \"123\", \"schemeAddress\": \"Standrad\", \"schemePolicyNumber\": \"12345\", \"schemeTelephone\": \"+61 1234567889\", \"transferAuthorityFlag\": true, \"fullPartialFlag\": \"Full\", \"occupationalSchemeFlag\": true, \"definedBenefitsSchemeFlag\": true, \"disqualifiedPensionCreditFlag\": true, \"protectedPCLS\": \"123.45\", \"protectedAge\": 52, \"updateRetirementAgeFlag\": true, \"initialChargeAmount\": \"100\" } ]}";
    }

    private Metadata getMetadata() {
        Metadata metadata = new Metadata();
        metadata.setPartyId(1);
        metadata.setPartyTypeId(3);
        metadata.setSurname("Krishnan");
        metadata.setFirstName("Rekha");
        metadata.setPayloadId("21404");
        metadata.setAdviserId(123);
        return metadata;
    }

}
