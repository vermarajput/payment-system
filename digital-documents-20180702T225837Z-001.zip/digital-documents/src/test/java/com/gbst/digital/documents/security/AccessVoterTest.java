package com.gbst.digital.documents.security;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.web.FilterInvocation;

import static com.gbst.digital.documents.security.utils.AuthenticationUtil.getAuthenticationFullAccess;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by Aman Verma on 31/08/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class AccessVoterTest {

    @After
    public void setup() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void testAccessGrantedFullAccess() throws Exception {
        OAuth2Authentication auth = getAuthenticationFullAccess();
        FilterInvocation fi = new FilterInvocation("api/quotes", "GET");

        AccessVoter voter = new AccessVoter();
        int result = voter.vote(auth, fi, null);

        assertEquals(result, AccessDecisionVoter.ACCESS_GRANTED);
    }

    @Test
    public void testAccessGrantedGetAllFullAccess() throws Exception {
        FilterInvocation fi = new FilterInvocation("api/quotes", "GET");

        AccessVoter voter = new AccessVoter();
        int result = voter.vote(getAuthenticationFullAccess(), fi, null);

        assertEquals(result, AccessDecisionVoter.ACCESS_GRANTED);
    }


    @Test
    public void testAnonymousAccess() throws Exception {
        AccessVoter voter = new AccessVoter();
        Authentication auth = mock(AnonymousAuthenticationToken.class);
        when(auth.getPrincipal()).thenReturn("anonymous");
        FilterInvocation fi = new FilterInvocation("api/quotes", "GET");
        int result = voter.vote(auth, fi, null);
        assertEquals(result, AccessDecisionVoter.ACCESS_DENIED);
    }

}