package com.gbst.digital.documents.service;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.GbstJsonApiUtils;
import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.repository.DocumentCleanupUtility;
import com.gbst.digital.documents.repository.DocumentCleanupUtilityTest;
import com.mongodb.WriteResult;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.access.AccessDeniedException;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * @author nehas
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentCleanupServiceTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private DocumentCleanupUtility documentCleanupUtility;

    @Mock
    private AuthenticationFacade authenticationFacade;

    @Mock
    Permissions<List<String>, OperationEnum> permissions;

    @InjectMocks
    private DocumentCleanupService documentCleanupService;

    DocumentCleanupUtilityTest documentCleanupUtilityTest = new DocumentCleanupUtilityTest();

    @Test
    public void testDocumentCleanup() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setClientOnly(true);
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
        mockMongoTemplateFindRemoveAndCleanupUtility();
        String[] expiredProcessIds = new String[]{"1234","56546"};
        documentCleanupService.cleanup(expiredProcessIds);
    }

    @Test(expected = AccessDeniedException.class)
    public void testDocumentCleanup_NotClientOnlyAuthentication() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setClientOnly(false);
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
        mockMongoTemplateFindRemoveAndCleanupUtility();
        String[] expiredProcessIds = new String[]{"1234","56546"};
        documentCleanupService.cleanup(expiredProcessIds);
    }

    private void mockMongoTemplateFindRemoveAndCleanupUtility() throws DocumentStorageException {
        doNothing().when(documentCleanupUtility).clearPreviousGenerationRecords(any());
        when(mongoTemplate.find(any(), any())).thenReturn(GbstJsonApiUtils.createIterableResult(new ArrayList<>()));
        WriteResult writeResult = Mockito.mock(WriteResult.class);
        when(mongoTemplate.remove(any())).thenReturn(writeResult);
    }

}
