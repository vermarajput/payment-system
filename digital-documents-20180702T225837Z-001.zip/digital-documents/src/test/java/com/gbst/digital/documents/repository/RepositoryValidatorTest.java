package com.gbst.digital.documents.repository;

import com.gbst.common.jsonapi.GbstJsonApiUtils;
import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import io.katharsis.queryParams.QueryParams;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by Aman Verma on 17/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class RepositoryValidatorTest {

    @InjectMocks
    private RepositoryValidator repositoryValidator;

    @Mock
    private DocumentConfigurationsJsonApiRepository documentConfigurationsJsonApiRepository;

    @Mock
    private RepositoryUtil repositoryUtil;

    @Before
    public void setup(){
        when(documentConfigurationsJsonApiRepository.findAll(any())).thenReturn(GbstJsonApiUtils.createIterableResult(new ArrayList()));
        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestEmptyRole() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_CONFIGURATION, "", "pre-submit", "NB", "id123",null);

    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestNullRole() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_CONFIGURATION, null, "pre-submit", "NB", "id123",null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestEmptyStage() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_LISTING, "paraplanner", "", "NB", "id123",null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestNullStage() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_CONFIGURATION, "paraplanner", null, "NB", "id123",null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestEmptyProcessType() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_CONFIGURATION, "paraplanner", "pre-submit", "", "id123",null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestNullProcessType() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_LISTING, "paraplanner", "pre-submit", null, "id123",null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestEmptyProcessId() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_GENERATION, "paraplanner", "pre-submit", "NB", "id123","");
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateMandatoryParamsInvalidRequestNullProcessId() {
        repositoryValidator.validateMandatoryParams(RepositoryValidator.SOURCE_DOCUMENT_GENERATION, "paraplanner", "pre-submit", "NB", "id123", null);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigEmptyDocConfigReceived() {
        repositoryValidator.validateDocumentConfiguration(new ArrayList<DocumentConfiguration>());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWithNoDocuments() {
        DocumentConfiguration documentConfiguration = DocumentTestDataHolder.getCorrectWindWardDocConf();
        documentConfiguration.setDocuments(new ArrayList<>());
        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWithNoRole() {
        DocumentConfiguration documentConfiguration = DocumentTestDataHolder.getCorrectWindWardDocConf();
        documentConfiguration.setRole("");
        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWithNoStage() {
        DocumentConfiguration documentConfiguration = DocumentTestDataHolder.getCorrectWindWardDocConf();
        documentConfiguration.setProcessStage("");
        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWithNoProcessId() {
        DocumentConfiguration documentConfiguration = DocumentTestDataHolder.getCorrectWindWardDocConf();
        documentConfiguration.setProcessTypeId("");
        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWithNoProcessType() {
        DocumentConfiguration documentConfiguration = DocumentTestDataHolder.getCorrectWindWardDocConf();
        documentConfiguration.setProcessType("");
        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testValidateDocConfigDocConfigWith2Configurations() {
        DocumentConfiguration documentConfiguration1 = DocumentTestDataHolder.getCorrectWindWardDocConf();
        DocumentConfiguration documentConfiguration2 = DocumentTestDataHolder.getCorrectWindWardDocConf();

        repositoryValidator.validateDocumentConfiguration(Arrays.asList(documentConfiguration1, documentConfiguration2));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testDocConf_JsonApiException_NullSent() {
        repositoryValidator.validateDocConfig(getNullDocConf());
    }

    //Post Validation tests
    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_Without_Docs() {
        repositoryValidator.validateDocConfig(getNoDocInDocConf());
    }
    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_Without_URL_ForStatic_MandatoryURL() {
        repositoryValidator.validateDocConfig(getStaticDocConfWithoutUrl());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_Duplicate_Doc_Conf() {
        when(documentConfigurationsJsonApiRepository.findAll(any())).thenReturn(GbstJsonApiUtils.createIterableResult(Arrays.asList(getCorrectWindWardDocConf())).stream().collect(Collectors.toList()));
        repositoryValidator.validateDocConfig(getCorrectWindWardDocConf());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WithStorageSystem_ForStatic() {
        repositoryValidator.validateDocConfig(getStaticDocConfWithStorageSystem());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WithNoStorageSystem() {
        repositoryValidator.validateDocConfig(getDocuConfWithDocWithoutStorageSystem());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WithNoGenerationStrategy() {
        repositoryValidator.validateDocConfig(getDocuConfWithDocWithoutGenerationStrategy());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WithNoTemplateForWINWARDGenerationStrategy() {
        repositoryValidator.validateDocConfig(getDocuConfWithNoTemplateForWINWARD());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WithNoOutputType() {
        repositoryValidator.validateDocConfig(getDocuConfWithDocWithNoOutputType());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_WindwardWithNoTemplate() {
        repositoryValidator.validateDocConfig(getDocuConfWithDocWithoutTemplate());
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPostDocConf_JsonApiException_InvalidProcessType_Illustration() {
        repositoryValidator.validateDocConfig(DocumentTestDataHolder.getDocuConfWithInvalidProcessTypeForIllustrationGeneration());
    }

    @Test
    public void testPostDocConf_JsonApiException_InvalidProcessType_WinwardDocOnly() {
        repositoryValidator.validateDocConfig(DocumentTestDataHolder.getDocuConfWithInvalidProcessTypeOnlyWinwardGeneration());
    }



    //Patch Validation tests
    @Test(expected = JsonApiValidationException.class)
    public void testPatchDocConf_JsonApiException_Duplicate_Doc_Conf() {
        //ProcessId, Role, Stage are same in both Illustration and Windward
        //ProcessTypeId is different to keep Configuration unique or non-duplicate
        DocumentConfiguration docConfWindWard = getCorrectWindWardDocConf();
        DocumentConfiguration docConfIllu = getIllustrationDocConf();
        when(documentConfigurationsJsonApiRepository.findAll(any())).thenReturn(GbstJsonApiUtils.createIterableResult(Arrays.asList(docConfWindWard, docConfIllu)).stream().collect(Collectors.toList()));

        // Trying to patch configuration with same ProcessTypeId as already saved different configuration.
        docConfWindWard.setId("SomeId");
        docConfWindWard.setProcessTypeId("id121");
        repositoryValidator.validateDocConfig(docConfWindWard);
    }

    @Test(expected = JsonApiValidationException.class)
    public void testPatchDocConf_JsonApiException_EmptyDocList() {
        DocumentConfiguration docConfWindWard = getCorrectWindWardDocConf();
        when(documentConfigurationsJsonApiRepository.findAll(any())).thenReturn(GbstJsonApiUtils.createIterableResult(Arrays.asList(docConfWindWard)).stream().collect(Collectors.toList()));

        // Trying to patch configuration with same ProcessTypeId as already saved different configuration.
        docConfWindWard.setId("SomeId");
        docConfWindWard.setDocuments(new ArrayList<>());
        repositoryValidator.validateDocConfig(docConfWindWard);
    }
}
