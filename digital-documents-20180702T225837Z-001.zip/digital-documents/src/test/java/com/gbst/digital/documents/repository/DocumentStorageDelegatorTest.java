package com.gbst.digital.documents.repository;

import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import com.gbst.digital.documents.storage.DocumentStorage;
import com.gbst.digital.documents.storage.FileSystemStorage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.getDocumentAttributesPayload;
import static com.gbst.digital.documents.repository.DocumentTestDataHolder.getDocumentInvalidStorage;
import static com.gbst.digital.documents.repository.DocumentTestDataHolder.getDocumentWithGeneratedStatus;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by Aman Verma on 31/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentStorageDelegatorTest {

    @InjectMocks
    private DocumentStorageDelegator documentStorageDelegator;

    @Spy
    private List<DocumentStorage> documentStorages = new ArrayList<>();

    @Mock
    private FileSystemStorage fileSystemStorage;

    @Before
    public void setup() throws Exception {
        documentStorages.add(fileSystemStorage);
    }

    @Test
    public void testStoreDocumentsInRespectiveStorageSystems() throws Exception {
        DocumentForGeneration document = getDocumentWithGeneratedStatus();
        document.setUrl("SomeUrl");
        List<DocumentWithParameter> listOfDocumentWithParameters = Arrays.asList(
                new DocumentWithParameter().setDocument(document));

        when(fileSystemStorage.supportsStorageType(StorageSystemEnum.FILESYSTEM.getValue())).thenReturn(true);
        when(fileSystemStorage.storeMultipleDocuments(any())).thenReturn(listOfDocumentWithParameters);

        List<DocumentWithParameter> listOfDocumentWithParameterRequest = Arrays.asList(new DocumentWithParameter().setDocument(getDocumentWithGeneratedStatus()).setPayload(getDocumentAttributesPayload()));
        List<DocumentWithParameter> listOfDocWithParams = documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(listOfDocumentWithParameterRequest);
        assertTrue("DocumentResponse object is null or empty", !listOfDocWithParams.isEmpty());
        assertTrue("Doc should be Generated", listOfDocWithParams.get(0).getDocument().getGenerationStatus().equals(GenerationStatusEnum.GENERATED));
        assertTrue("Doc should have a URL", listOfDocWithParams.get(0).getDocument().getUrl().equals("SomeUrl"));
    }

    @Test
    public void testStoreDocumentsInRespectiveStorageSystemsStorageSystemNotDefined() throws Exception {

        List<DocumentWithParameter> listOfDocumentWithParameterRequest = Arrays.asList(new DocumentWithParameter().setDocument(getDocumentInvalidStorage()).setPayload(getDocumentAttributesPayload()));
        List<DocumentWithParameter> listOfDocWithParams = documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(listOfDocumentWithParameterRequest);
        assertTrue("DocumentResponse object is null or empty", !listOfDocWithParams.isEmpty());
        assertTrue("DocumentResponse object is null or empty", listOfDocWithParams.size() == 1);
        assertTrue("No document stored", listOfDocWithParams.get(0).getDocument().getGenerationStatus().equals(GenerationStatusEnum.GENERATION_FAILED));
    }

    @Test
    public void testStoreDocumentsInRespectiveStorageSystemsNullGeneratedDocPassed() throws Exception {
        List<DocumentWithParameter> listOfDocWithParams = documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(null);
        assertTrue("DocumentResponse should be null", CollectionUtils.isEmpty(listOfDocWithParams));
    }

    @Test
    public void testStoreDocumentsInRespectiveStorageSystemsZeroGeneratedDocPassed() throws Exception {
        List<DocumentWithParameter> listOfDocWithParams = documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(new ArrayList<>());
        assertTrue("DocumentResponse should be empty", CollectionUtils.isEmpty(listOfDocWithParams));
    }
}