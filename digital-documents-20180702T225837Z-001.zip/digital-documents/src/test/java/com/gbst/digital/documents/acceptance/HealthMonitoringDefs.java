package com.gbst.digital.documents.acceptance;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;

public class HealthMonitoringDefs extends DocumentBaseDefs {
    @When("^the client calls /manage/health$")
    public void the_client_calls_manage_health() throws Throwable {
        context.setAccessToken(null);
        executeGet(apiUrlHealth + "/manage/health", "");
    }

    @And("^the client receives status up$")
    public void theClientReceivesStatusUp() throws Throwable {
        assertThat(context.getLatestResponse().getBody(), containsString("\"status\":\"UP\"")) ;
    }

}
