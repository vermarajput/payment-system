package com.gbst.digital.documents.security.composer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.common.party.PartyTypeEnum;
import com.gbst.common.party.PartyTypeSettings;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.services.composer.PartyTypeService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;

import static com.gbst.common.party.PartyTypeEnum.Adviser;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 6/02/2018
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentAttributesPermissionsTest {

    @Mock
    AuthenticationFacade authenticationFacade;

    @Mock
    DocumentPayload documentPayload;

    @Mock
    PartyTypeService partyTypeService;

    ObjectMapper mapper = new ObjectMapper();

    @Spy
    PartyTypeSettings partyTypeSettings = new PartyTypeSettings();

    @InjectMocks
    DocumentAttributesPermissions permissions;
    
    @Before
    public void setUp() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("cocob");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
        when(documentPayload.isJson()).thenReturn(true);
        partyTypeSettings.setPartyTypes(new HashMap<>());
        partyTypeSettings.getPartyTypes().put("composer", new HashMap<>());
        partyTypeSettings.getPartyTypes().get("composer").put(Adviser, "3");
        partyTypeSettings.getPartyTypes().get("composer").put(PartyTypeEnum.Investor, "20");
        partyTypeSettings.getPartyTypes().get("composer").put(PartyTypeEnum.Agent, "11");
        partyTypeSettings.getPartyTypes().get("composer").put(PartyTypeEnum.Dealer, "12");
    }

    @Test
    public void checkHierarchicalOwnership_investor_id_with_access() throws Exception {
        DocumentAttributesPermissionsTest.DocAttr doc = new DocumentAttributesPermissionsTest.DocAttr();
        doc.setOwner("14T3");
        doc.setInvestorId("555");

        when(partyTypeService.isPartyAssociated(14, 3, 20, "555")).thenReturn(true);
        when(documentPayload.getPayloadAsJsonNode()).thenReturn(mapper.readTree(mapper.writeValueAsString(doc)));
        try {
            permissions.check(null, documentPayload);
        } catch (GbstJsonApiAccessDeniedException x) {
            fail("Should not fail");
        }
    }

    @Test(expected = GbstJsonApiAccessDeniedException.class)
    public void checkHierarchicalOwnership_investor_id_with_no_access() throws Exception {

        DocumentAttributesPermissionsTest.DocAttr doc = new DocumentAttributesPermissionsTest.DocAttr();
        doc.setOwner("14T3");
        doc.setInvestorId("555");

        when(partyTypeService.isPartyAssociated(14, 3, 20, "555")).thenReturn(false);
        when(documentPayload.getPayloadAsJsonNode()).thenReturn(mapper.readTree(mapper.writeValueAsString(doc)));

        permissions.check(null, documentPayload);
    }

    public static class DocAttr {
        String owner;
        String investorAccountId;
        String investorId;

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getInvestorAccountId() {
            return investorAccountId;
        }

        public void setInvestorAccountId(String investorAccountId) {
            this.investorAccountId = investorAccountId;
        }

        public String getInvestorId() {
            return investorId;
        }

        public void setInvestorId(String investorId) {
            this.investorId = investorId;
        }
    }

}