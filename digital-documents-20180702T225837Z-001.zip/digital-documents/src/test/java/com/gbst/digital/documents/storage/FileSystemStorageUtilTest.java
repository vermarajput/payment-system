package com.gbst.digital.documents.storage;

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import com.gbst.digital.documents.storage.util.FileSystemStorageUtil;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.time.Instant;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author nehas
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(FileUtils.class)
public class FileSystemStorageUtilTest {

    private static final Logger LOG = LoggerFactory.getLogger(FileSystemStorageUtilTest.class);

    private FileSystemStorageUtil fileSystemStorageUtil = new FileSystemStorageUtil();

    private static final String test_file_title = "DIRECT_DEBIT_INSTRUCTION";
    private static final String test_file_type = "DOC";
    private static final String test_file_data = "dummydata";

    private static final String process_type = "NEW_BUSINESS";
    private static final String process_type_id = "17";
    private static final String process_stage = "pre-submission";
    private static final String role_adviser = "adviser";
    private static final String process_id = "quote342";
    private static final String owner = "Aman";
    private static final String payload = "";

    private byte[] bytes = new byte[100];

    @Before
    public void beforeTest() throws DocumentStorageException, IOException {
        fileSystemStorageUtil.setDocumentFolderRootPath("/");
        PowerMockito.mockStatic(FileUtils.class, new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                if (invocation.getMethod().getName().equals("openInputStream")) {
                    return new ByteArrayInputStream(bytes);
                }
                return null;
            }
        });

        // check the root directory exists
        if (!checkFileOrDirectoryExists(fileSystemStorageUtil.getDocumentFolderRootPath())) {
            LOG.error(fileSystemStorageUtil.getDocumentFolderRootPath() + " - directory does not exists");
            throw new DocumentStorageException(fileSystemStorageUtil.getDocumentFolderRootPath() + " - directory does not exists");
        }
    }

    @Test
    public void test_upload_document() throws DocumentStorageException {
        DocumentWithParameter documentWithParameter = createRequestForUpload(test_file_title, test_file_type, dummyOutputStream(), process_type, process_type_id, process_id, process_stage, role_adviser, owner, payload);
        assertTrue("checking operation successful", GenerationStatusEnum.GENERATED.equals(fileSystemStorageUtil.performDocumentUploadOperation(documentWithParameter).getDocument().getGenerationStatus()));
    }


    @Test(expected = DocumentStorageException.class)
    public void test_upload_document_missingPayload() throws DocumentStorageException {
        DocumentWithParameter documentWithParameter = createRequestForUpload(test_file_title, test_file_type, dummyOutputStream(), null, null, null, null, null,null, null);
        fileSystemStorageUtil.performDocumentUploadOperation(documentWithParameter);
    }

    @Test(expected = DocumentStorageException.class)
    public void test_upload_document_missingFile() throws DocumentStorageException {
        DocumentWithParameter documentWithParameter = createRequestForUpload(test_file_title, test_file_type, null, process_type, process_type_id, process_id, process_stage, role_adviser, owner, payload);
        fileSystemStorageUtil.performDocumentUploadOperation(documentWithParameter);
    }

    @Test(expected = DocumentStorageException.class)
    public void test_upload_document_missingFileDetails() throws DocumentStorageException {
        DocumentWithParameter documentWithParameter = createRequestForUpload("", test_file_type, dummyOutputStream(), process_type, process_type_id, process_id, process_stage, role_adviser, owner, payload);
        fileSystemStorageUtil.performDocumentUploadOperation(documentWithParameter);
    }

    private DocumentWithParameter createRequestForUpload(String title, String type, ByteArrayOutputStream file, String process_type, String process_type_id, String process_id, String process_stage, String role, String owner, String payload) {
        DocumentForGeneration document = new DocumentForGeneration();
        document.setDocumentName(title);
        document.setOutputType(OutputTypeEnum.valueOf(type));
        document.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        document.setGenerationStatus(GenerationStatusEnum.GENERATED);
        document.setGeneratedDate(Instant.now());

        return new DocumentWithParameter(process_type,
                process_type_id,
                role,
                process_stage,
                payload,
                process_id,
                document,
                owner,
                file);
    }

    private boolean checkFileOrDirectoryExists(String path) {
        File file = new File(path);
        return file.exists();
    }

    private ByteArrayOutputStream dummyOutputStream() {
        File file = null;
        ByteArrayOutputStream outputStream = null;
        try {
            file = File.createTempFile(test_file_title, test_file_type);
            outputStream = new ByteArrayOutputStream((int) file.length());
        } catch (IOException e) {
            LOG.error("error in creating dummy file.");
        }
        return outputStream;
    }
}
