package com.gbst.digital.documents.generator.json.windward;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.DocumentForConfig;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.PayloadFormatEnum;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 17/04/2018
 */
@RunWith(MockitoJUnitRunner.class)
public class DirectDebitJsonWindwardGeneratorTest {
    ObjectMapper mapper = new ObjectMapper();
    DocumentPayloadFactory documentPayloadFactory = new DocumentPayloadFactory(mapper);

    @InjectMocks
    DirectDebitJsonWindwardGenerator generator;

    @Test
    public void supports() throws Exception {
        String json = "{\"ownerId\":\"1\",\"ownerTypeId\":\"3\",\"status\":\"Quoted\",\"lastStep\":\"quoteDisplay\",\"processType\":\"DRAWDOWN\",\"adviserId\":\"1\",\"productTypeId\":\"19\",\"productName\":\"Vitality SIPP Uncrystallised\",\"investorFirstName\":\"sdfgsdf\",\"investorLastName\":\"sdfgdf\",\"investorDateOfBirth\":\"1958-03-02\",\"investorGender\":\"Male\",\"investorExpectedRetirementAge\":65,\"existingPolicyFlag\":true,\"applyBoostFlag\":true,\"dateOfRetirement\":\"2023-03-02\",\"habitualResident\":true,\"dependantPensionPercent\":\"50\",\"annuityFrequency\":\"Monthly\",\"annuityTiming\":\"InAdvance\",\"annuityGuarantee\":\"0\",\"annuityEscalation\":\"0\",\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"quotedDateTime\":\"2018-03-22T04:56:46Z\",\"regularInitialChargeAmount\":\"0\",\"singleInitialChargeAmount\":\"0\",\"applySameInvestmentStrategy\":true,\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"74\",\"customFields\":[{\"key\":\"protector_fund\",\"value\":\"2\"}],\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"applicationDetails\":{},\"previousBCE\":{\"pensionBenefits\":{\"pensionBenefitsEvents\":[]},\"pensionPayments\":{\"pensionPaymentsEvents\":[]},\"overseasTransfers\":{\"overseasTransfersEvents\":[]}},\"crystallisationDetails\":{\"amountToCrystallise\":\"100\",\"pclsAmount\":\"10\",\"crystallisedValue\":\"90\",\"uncrystallisedValue\":\"1150\"},\"protection\":{\"primaryProtection\":{},\"enhancedProtection\":{},\"individualProtection\":{},\"fixedProtection\":{},\"otherProtection\":{}},\"drawdownIncome\":{\"amount\":\"1\",\"frequency\":\"Monthly\",\"paymentDay\":1,\"bankAccount\":{\"bankAddress\":{}}},\"policyPaymentPlan\":{\"bankAccount\":{\"bankAddress\":{}}},\"secondaryAccount\":{\"ongoingAdviserChargeAmount\":\"0\",\"ongoingAdviserChargeFrequency\":\"Monthly\",\"investmentStrategy\":{\"investments\":[{\"investmentId\":\"44\",\"assetAttribute\":\"YES\",\"investmentPercent\":\"100\"}]},\"productTypeId\":\"20\"},\"investorActualAddress\":{},\"singleContributions\":[{\"amount\":\"1000\",\"contributorType\":\"Investor\"}],\"regularContributions\":[{\"amount\":\"500\",\"contributorType\":\"Investor\",\"frequency\":\"Monthly\",\"bankAccount\":{\"bankAddress\":{}}}],\"sippTransferIns\":[],\"investorBankAccounts\":[],\"isaTransferIns\":[],\"customFields\":[{\"key\":\"accumulationBoostVersionId\",\"value\":\"2\"}],\"dateTimeLastModified\":\"2018-03-22T04:56:46Z\",\"quoteId\":\"5ab336c807b76900010743ea\"}";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Investor
     * ** ClientPresentFlag and ClientDebitAuthorisationFlag not supplied
     *
     * @throws Exception
     */
    @Test
    public void testSupports_RegularContributionWithInvestor() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Investor\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Investor
     * ** ClientPresentFlag and ClientDebitAuthorisationFlag set to false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_RegularContributionWithInvestor_ClientPresentFlagAndClientDebitAuthorisationFlagSetToFalse() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Investor\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions Not for Investor
     * ** ClientPresentFlag and ClientDebitAuthorisationFlag not present
     *
     * @throws Exception
     */
    @Test
    public void testSupports_DoesNotSupport_RegularContributionWithEmployer() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertFalse(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Employer
     * ** ClientPresentFlag and ClientDebitAuthorisationFlag set to true
     *
     * @throws Exception
     */
    @Test
    public void testSupports_DoesNotSupport_RegularContributionWithEmployer_ClientFieldsSetToTrue() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"clientPresentFlag\": true,"
                + " 			\"clientDebitAuthorisationFlag\": true,"
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertFalse(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Employer
     * ** ClientPresentFlag and ClientDebitAuthorisationFlag set to false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_DoesNotSupport_RegularContributionWithEmployer_ClientFieldsSetToFalse() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertFalse(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Investor
     * ** ClientPresentFlag set to false and ClientDebitAuthorisationFlag not supplied
     *
     * @throws Exception
     */
    @Test
    public void testSupports_RegularContributionWithInvestor_ClientPresentSetToFalseOtherNotPresent() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Investor\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions for Investor
     * ** ClientPresentFlag set to true and ClientDebitAuthorisationFlag set to false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_RegularContributionWithInvestor_ClientPresentSetToTrueOtherToFalse() throws Exception {
        String json = "{"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Investor\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"clientPresentFlag\": true,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions Not for Investor
     * ApplyBoost is false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_DoesNotSupport_ApplyBoostFlagFalse() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": false,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	]"
                + " }";

        assertFalse(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions Not for Investor
     * ApplyBoost is true
     * PolicyPaymentPlan
     * ** client_present and client_debit_authorisation_flag present and set to true
     *
     * @throws Exception
     */
    @Test
    public void testSupports_DoesNotSupport_ApplyBoostFlagTrueAndPolicyPaymentPlanHasClientFieldsSetToTrue() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": true,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	],"
                + " 	\"policyPaymentPlan\": {"
                + " 		\"clientPresentFlag\": true,"
                + " 		\"clientDebitAuthorisationFlag\": true"
                + " 	}"
                + " }";

        assertFalse(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions Not for Investor
     * ApplyBoost is true
     * PolicyPaymentPlan
     * ** client_present and client_debit_authorisation_flag present and set to true
     *
     * @throws Exception
     */
    @Test
    public void testSupports_ApplyBoostFlagTrueAndPolicyPaymentPlanHasClientFieldsSetToFalse() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": true,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	],"
                + " 	\"policyPaymentPlan\": {"
                + " 		\"clientPresentFlag\": false,"
                + " 		\"clientDebitAuthorisationFlag\": false"
                + " 	}"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }


    /**
     * RegularContributions Not for Investor
     * ApplyBoost is true
     * PolicyPaymentPlan: ClientPresentFlag and ClientDebitAuthorisationFlag field not present
     *
     * @throws Exception
     */
    @Test
    public void testSupports_ApplyBoostFlagTrueAndPolicyPaymentPlanNotHavingClientFields() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": true,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	],"
                + " 	\"policyPaymentPlan\": {"
                + " 	}"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    /**
     * RegularContributions Not for Investor
     * ApplyBoost is true
     * PolicyPaymentPlan: ClientPresentFlag set to false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_ApplyBoostFlagTrueAndPolicyPaymentPlanHavingClientPresentFieldSetToFalse() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": true,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	],"
                + " 	\"policyPaymentPlan\": {"
                + " 		\"clientPresentFlag\": false"
                + " 	}"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }


    /**
     * RegularContributions Not for Investor
     * ApplyBoost is true
     * PolicyPaymentPlan: ClientPresentFlag field set to true but ClientAuthorityDebitFlag field set to false
     *
     * @throws Exception
     */
    @Test
    public void testSupports_ApplyBoostFlagTrueAndPolicyPaymentPlanClientDebitAuthorisationFlagSetToFalse() throws Exception {
        String json = "{"
                + " 	\"applyBoostFlag\": true,"
                + " 	\"regularContributions\": ["
                + " 		{"
                + " 			\"amount\": \"1500\","
                + " 			\"contributorType\": \"Employer\","
                + " 			\"clientPresentFlag\": false,"
                + " 			\"clientDebitAuthorisationFlag\": false,"
                + " 			\"frequency\": \"Monthly\","
                + " 			\"bankAccount\": {"
                + " 				\"bankAddress\": {}"
                + " 			}"
                + " 		}"
                + " 	],"
                + " 	\"policyPaymentPlan\": {"
                + " 		\"clientPresentFlag\": true,"
                + " 		\"clientDebitAuthorisationFlag\": false"
                + " 	}"
                + " }";

        assertTrue(generator.supports(new DocumentGeneration(), getDocumentPayload(json)));
    }

    private DocumentPayload getDocumentPayload(String json) {
        DocumentPayload payload = documentPayloadFactory.createPayload(PayloadFormatEnum.JSON, json);
        payload.setDocumentForConfig(new DocumentForConfig());
        payload.getDocumentForConfig().setGenerationStrategy(GenerationStrategyEnum.WINDWARD.name());
        payload.getDocumentForConfig().setDocumentName(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name());
        return payload;
    }
}