package com.gbst.digital.documents.repository;

import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.common.jsonapi.GbstJsonApiUtils;
import com.gbst.common.jsonapi.ResourceNotFoundException;
import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.mongodb.WriteResult;
import io.katharsis.queryParams.QueryParams;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.getCorrectWindWardDocConf;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * @author sanjayank    17/08/2017 8:45 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentConfigurationsJsonApiRepositoryTest {

    @Mock
    private RepositoryValidator repositoryValidator;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private RepositoryUtil repositoryUtil;

    @Mock
    Permissions<DocumentConfiguration, OperationEnum> documentConfigurationPermissions;

    @InjectMocks
    private DocumentConfigurationsJsonApiRepository documentConfigurationsJsonApiRepository;

    @Before
    public void setup() {
    }

    @Test
    public void testSaveDocConfigurations_PositiveCase() {
        mockMongoRepository();
        mockMongoRepositoryWithValidData();
        DocumentConfiguration result = documentConfigurationsJsonApiRepository.save(getCorrectWindWardDocConf());
        assertTrue("Configuration processType", result.getProcessType().equalsIgnoreCase("NB"));
    }

    @Test(expected = JsonApiValidationException.class)
    public void testSaveUpdateDocConf_ValidationException() {
        mockMongoRepository();
        mockInvalidData();
        documentConfigurationsJsonApiRepository.save(DocumentTestDataHolder.getDocuConfWithDocWithoutGenerationStrategy());
    }

    @Test
    public void testPatchDocConfigurations_PositiveCase1() {
        mockMongoRepository();
        mockMongoRepositoryWithValidData();
        DocumentConfiguration docConf = getCorrectWindWardDocConf();
        DocumentConfiguration result = documentConfigurationsJsonApiRepository.save(docConf);
        assertTrue("Configuration processType", result.getProcessType().equalsIgnoreCase("NB"));
        assertTrue(result.getDocuments().get(0).getDocumentName().equals("WINDWARD"));

        docConf.setId("SomeMongoDBId");
        docConf.setProcessTypeId("id123"); //Same ProcessTypeId in patch request
        docConf.setDocuments(Arrays.asList(DocumentTestDataHolder.getIllustrationDocument()));
        DocumentConfiguration patchResult = documentConfigurationsJsonApiRepository.save(docConf);

        assertTrue("Configuration processType", result.getProcessType().equalsIgnoreCase("NB"));
        assertFalse(CollectionUtils.isEmpty(patchResult.getDocuments()));
        assertTrue(patchResult.getDocuments().size() == 1);
        assertTrue(patchResult.getDocuments().get(0).getDocumentName().equals("ILLUSTRATION"));
    }

    @Test
    public void testPostDocConfigurations_PositiveCase2() {
        mockMongoRepository();
        mockMongoRepositoryWithValidData();
        DocumentConfiguration docConf = DocumentTestDataHolder.getDocuConfWithInvalidProcessTypeOnlyWinwardGeneration();
        DocumentConfiguration result = documentConfigurationsJsonApiRepository.save(docConf);
        assertTrue("Configuration processType", result.getProcessType().equalsIgnoreCase("NB"));
        assertTrue(result.getDocuments().get(0).getDocumentName().equals("Windward"));
    }

    @Test
    public void testPatchDocConfigurations_PositiveCase_NoDocumentsSentInPatch() {
        mockMongoRepository();
        mockMongoRepositoryWithValidData();
        DocumentConfiguration docConf = getCorrectWindWardDocConf();
        DocumentConfiguration result = documentConfigurationsJsonApiRepository.save(docConf);
        assertTrue(result.getDocuments().get(0).getDocumentName().equals("WINDWARD"));
        assertTrue("Configuration processType id", result.getProcessTypeId().equalsIgnoreCase("id123"));
        assertTrue("Configuration role", result.getRole().equalsIgnoreCase("paraplanner"));

        docConf.setId("SomeMongoDBId");
        docConf.setProcessTypeId("id122");  //Different ProcessTypeId to initial post
        docConf.setRole("adviser");         //Different Role to initial post
        DocumentConfiguration patchResult = documentConfigurationsJsonApiRepository.save(docConf);

        assertTrue("Configuration processType id", result.getProcessTypeId().equalsIgnoreCase("id122"));
        assertTrue("Configuration role", result.getRole().equalsIgnoreCase("adviser"));
        assertFalse(CollectionUtils.isEmpty(patchResult.getDocuments()));
        assertTrue(patchResult.getDocuments().size() == 1);
        assertTrue(patchResult.getDocuments().get(0).getDocumentName().equals("WINDWARD"));
    }

    @Test
    public void testFindOneWithValidInfo() {
        DocumentConfiguration docConf = getCorrectWindWardDocConf();
        when(mongoTemplate.findById("AnyId", DocumentConfiguration.class)).thenReturn(docConf);
        assertEquals(docConf, documentConfigurationsJsonApiRepository.findOne("AnyId", null));
    }

    @Test(expected = ResourceNotFoundException.class)
    public void testFindOneWithNoRecordForIdSent() {
        when(mongoTemplate.findById("AnyId", DocumentConfiguration.class)).thenReturn(null);
        documentConfigurationsJsonApiRepository.findOne("AnyId", null);
    }

    @Test
    public void testDeleteSuccess() {
        DocumentConfiguration docConf = getCorrectWindWardDocConf();
        when(mongoTemplate.findById("AnyId", DocumentConfiguration.class)).thenReturn(docConf);
        when(mongoTemplate.remove(docConf)).thenReturn(WriteResult.unacknowledged());
        documentConfigurationsJsonApiRepository.delete("AnyId");
    }

    @Test(expected = GbstJsonApiAccessDeniedException.class)
    public void testDelete_no_access() {
        doThrow(new GbstJsonApiAccessDeniedException("")).when(documentConfigurationPermissions).check(any(OperationEnum.class), any(DocumentConfiguration.class));
        DocumentConfiguration docConf = getCorrectWindWardDocConf();
        when(mongoTemplate.findById("AnyId", DocumentConfiguration.class)).thenReturn(docConf);
        when(mongoTemplate.remove(docConf)).thenReturn(WriteResult.unacknowledged());
        documentConfigurationsJsonApiRepository.delete("AnyId");
    }

    @Test(expected = ResourceNotFoundException.class)
    public void testDeleteResourceNotFound() {
        documentConfigurationsJsonApiRepository.delete("AnyId");
    }

    private void mockMongoRepositoryWithValidData() {
        doNothing().when(repositoryValidator).validateDocConfig(any());
    }

    private void mockInvalidData() {
        doThrow(new JsonApiValidationException("Request validation failed", "")).when(repositoryValidator).validateDocConfig(any());
    }

    private void mockMongoRepository() {
        when(mongoTemplate.find(any(), any())).thenReturn(GbstJsonApiUtils.createIterableResult(new ArrayList<>()));
        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
        doNothing().when(mongoTemplate).save(any());
    }
}