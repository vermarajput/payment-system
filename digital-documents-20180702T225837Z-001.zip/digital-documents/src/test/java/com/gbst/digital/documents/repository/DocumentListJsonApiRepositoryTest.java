package com.gbst.digital.documents.repository;

import com.gbst.digital.documents.generator.DocumentGenerator;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.*;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.StorageSystemEnum;
import io.katharsis.queryParams.QueryParams;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * @author nehas
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentListJsonApiRepositoryTest {

    @InjectMocks
    private DocumentListJsonApiRepository documentListJsonApiRepository;

    @Mock
    private DocumentConfigurationsJsonApiRepository documentConfigurationRepository;

    @Spy
    private List<DocumentGenerator> documentGenerationHandlers = new ArrayList<>();

    @Mock
    private RepositoryValidator repositoryValidator;

    @Mock
    private RepositoryUtil repositoryUtil;

    @Mock
    DocumentPayloadFactory documentPayloadFactory;

    @Mock
    DocumentPayload payload;

    @Mock
    DocumentGenerator documentGenerator1;

    @Before
    public void setup() throws Exception {
        List<DocumentConfiguration> documentConfigurations = new LinkedList<>();
        DocumentConfiguration config = new DocumentConfiguration();
        List<DocumentForConfig> docs = new LinkedList<>();
        DocumentForConfig doc1 = new DocumentForConfig();
        doc1.setDocumentName(DocumentTypeEnum.SIPP_TRANSFER_AUTHORITY.name());
        doc1.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        doc1.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        docs.add(doc1);

        DocumentForConfig doc2 = new DocumentForConfig();
        doc2.setDocumentName(DocumentTypeEnum.SIPP_APPLICATION_SUMMARY.name());
        doc2.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        doc2.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        docs.add(doc2);

        DocumentForConfig doc3 = new DocumentForConfig();
        doc3.setDocumentName(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name());
        doc3.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        doc3.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        docs.add(doc3);

        DocumentForConfig doc4 = new DocumentForConfig();
        doc4.setDocumentName(DocumentTypeEnum.EMPLOYER_PAYMENT_SCHEDULE.name());
        doc4.setStorageSystem(StorageSystemEnum.FILESYSTEM.getValue());
        doc4.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        docs.add(doc4);

        config.setDocuments(docs);
        documentConfigurations.add(config);
        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
        when(documentConfigurationRepository.findAll(any(QueryParams.class))).thenReturn(documentConfigurations);
        doNothing().when(repositoryValidator).validateDocumentConfiguration(documentConfigurations);

        when(documentPayloadFactory.createPayload(any(), any())).thenReturn(payload);
        

    }

    @Test
    public void testFetchDocumentList_NoTransferIns_NoRegularContributions_Case() {
        DocumentList documentListInput = prepareDocumentListInput();
        documentListInput.setDocumentAttributes("");
        documentGenerationHandlers.clear();
        documentGenerationHandlers.add(documentGenerator1);
        when(documentGenerator1.supports(any(), any())).thenReturn(true);

        documentListInput = documentListJsonApiRepository.save(documentListInput);
        List<Document> listDocs = documentListInput.getDocuments();
        assertTrue(!listDocs.isEmpty());
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_TRANSFER_AUTHORITY.name())).count() == 1);
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_APPLICATION_SUMMARY.name())).count() == 1);
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name())).count() == 1);
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.EMPLOYER_PAYMENT_SCHEDULE.name())).count() == 1);
    }

    @Test
    public void testFetchDocumentList_CurrentHandlerDoesNotSupport() {
        DocumentList documentListInput = prepareDocumentListInput();
        documentListInput.setDocumentAttributes("");
        documentGenerationHandlers.clear();
        documentGenerationHandlers.add(documentGenerator1);
        when(documentGenerator1.supports(any(), any())).thenReturn(false);

        documentListInput = documentListJsonApiRepository.save(documentListInput);
        List<Document> listDocs = documentListInput.getDocuments();
        assertTrue(listDocs.isEmpty());
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_TRANSFER_AUTHORITY.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_APPLICATION_SUMMARY.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.EMPLOYER_PAYMENT_SCHEDULE.name())).count() == 1);
    }

    @Test
    public void testFetchDocumentList_StaticDocumentAlwaysSupported() {
        DocumentForConfig doc = new DocumentForConfig();
        doc.setDocumentName("STATIC Document");
        doc.setGenerationStrategy(GenerationStrategyEnum.STATIC.getValue());
        DocumentConfiguration config = new DocumentConfiguration();
        config.setDocuments(Arrays.asList(doc));
        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
        when(documentConfigurationRepository.findAll(any(QueryParams.class))).thenReturn(Arrays.asList(config));
        DocumentList documentListInput = prepareDocumentListInput();
        documentListInput.setDocumentAttributes("");
        documentGenerationHandlers.clear();
        documentGenerationHandlers.add(documentGenerator1);
        when(documentGenerator1.supports(any(), any())).thenReturn(true);

        documentListInput = documentListJsonApiRepository.save(documentListInput);
        List<Document> listDocs = documentListInput.getDocuments();
        assertTrue(!listDocs.isEmpty());
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase("STATIC Document")).count() == 1);

        documentListInput = documentListJsonApiRepository.save(documentListInput);
        listDocs = documentListInput.getDocuments();
        assertTrue(!listDocs.isEmpty());
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase("STATIC Document")).count() == 1);

        documentListInput = documentListJsonApiRepository.save(documentListInput);
        listDocs = documentListInput.getDocuments();
        assertTrue(!listDocs.isEmpty());
        assertTrue(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase("STATIC Document")).count() == 1);
    }

    @Test
    public void testFetchDocumentList_NoHandlerSupported() {
        DocumentList documentListInput = prepareDocumentListInput();
        documentListInput.setDocumentAttributes("");
        documentListInput = documentListJsonApiRepository.save(documentListInput);
        List<Document> listDocs = documentListInput.getDocuments();
        assertTrue(listDocs.isEmpty());
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_TRANSFER_AUTHORITY.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.SIPP_APPLICATION_SUMMARY.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.DIRECT_DEBIT_INSTRUCTION.name())).count() == 1);
        assertFalse(listDocs.stream().filter(document -> document.getDocumentName().equalsIgnoreCase(DocumentTypeEnum.EMPLOYER_PAYMENT_SCHEDULE.name())).count() == 1);
    }

    private DocumentList prepareDocumentListInput() {
        DocumentList req = new DocumentList();
        req.setProcessTypeId("17");
        req.setProcessType("NEW_BUSINESS");
        req.setProcessStage("pre-submission");
        req.setRole("Advisor");
        return req;
    }
}