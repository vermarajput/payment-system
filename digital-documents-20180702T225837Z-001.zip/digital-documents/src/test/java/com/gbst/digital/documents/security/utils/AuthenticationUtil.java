package com.gbst.digital.documents.security.utils;

import com.gbst.common.auth.GbstPrincipal;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by Aman Verma on 4/09/2017.
 */
public class AuthenticationUtil {

    public static OAuth2Authentication getAuthenticationFullAccess(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:read:user:*");
        scopes.add("gbst:digital-quotes:write:user:*");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static OAuth2Authentication getAuthenticationFullAccess_WriteScopeUser(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:read:user:*");
        scopes.add("gbst:digital-quotes:write:user:*");
        scopes.add("gbst:digital-quotes:write:user:nehas");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static OAuth2Authentication getAuthenticationOnlyRead(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:read:user");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static OAuth2Authentication getAuthenticationOnlyWrite(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:write:user");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static OAuth2Authentication getAuthenticationOnlyReadSingleUser(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:read:user:nehas");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static OAuth2Authentication getAuthenticationOnlyWriteSingleUser(){
        Set<String> scopes = new HashSet<>();
        scopes.add("gbst:digital-quotes:write:user:nehas");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password", Collections.singletonList(new SimpleGrantedAuthority("all")));
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    private OAuth2Authentication getNotAuthenticatedAuthentication(){
        Set<String> scopes = new HashSet<>();
        scopes.add("all_perms");
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("johnh");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(principal, "password");
        OAuth2Request authReq = new OAuth2Request(null, "comp_boui", null, true, scopes, null, "", null, null);
        return new OAuth2Authentication(authReq, auth);
    }

    public static void setSecurityContext(Authentication authentication) {
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
    }

    public static SecurityContextHolder getSecurityContextHolder(OAuth2Authentication auth2Authentication){
        SecurityContextHolder sch =  new SecurityContextHolder();
        SecurityContext securityContext = new SecurityContextImpl();
        securityContext.setAuthentication(auth2Authentication);
        sch.setContext(securityContext);
        return sch;
    }
}
