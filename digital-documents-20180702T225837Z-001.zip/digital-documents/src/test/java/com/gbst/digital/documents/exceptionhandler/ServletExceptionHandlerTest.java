package com.gbst.digital.documents.exceptionhandler;

import com.gbst.digital.documents.exception.ServletRunTimeException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;

import static junit.framework.TestCase.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ServletExceptionHandlerTest {

    @InjectMocks
    private ServletExceptionHandler servletExceptionHandler;

    @Test
    public void testHandleException() {

        ServletRunTimeException exception = new ServletRunTimeException(HttpStatus.INTERNAL_SERVER_ERROR, "Error");
        ResponseEntity responseEntity = servletExceptionHandler.handleException(exception, new MockHttpServletResponse());
        assertTrue(responseEntity != null);
        assertTrue(responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR));
        assertTrue(responseEntity.getBody().equals("Error"));
    }
}
