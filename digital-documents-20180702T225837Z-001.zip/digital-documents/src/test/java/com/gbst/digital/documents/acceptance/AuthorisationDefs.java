package com.gbst.digital.documents.acceptance;

import com.gbst.common.acceptance.security.CucumberAuthServerHelper;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import org.junit.Assert;

/**
 * @author rachely on 7/04/2018
 */
public class AuthorisationDefs extends DocumentBaseDefs {
    protected CucumberAuthServerHelper cucumberAuthServerHelper = CucumberAuthServerHelper.getInstance();
    static final String EXTERNAL_ID_DOCUMENT = "";

    @Given("^I have a valid token for system administrator (\"[^\"]*\"|[^\"]+)$")
    public void setValidTokenForSysAdmin(String partyId) {
        String partyTypeId = "SysAdmin";
        setToken(cucumberAuthServerHelper.createAccessToken(EXTERNAL_ID_DOCUMENT, partyId, partyTypeId).getValue());
    }

    @Given("^I have a valid token for adviser (\"[^\"]*\"|[^\"]+)$")
    public void setValidTokenForAdviser(String partyId) {
        String partyTypeId = "Adviser";
        setToken(cucumberAuthServerHelper.createAccessToken(EXTERNAL_ID_DOCUMENT, partyId, partyTypeId).getValue());
    }

    @Given("^I have a valid token for investor (\"[^\"]*\"|[^\"]+)$")
    public void setValidTokenForInvestor(String partyId) {
        String partyTypeId = "Investor";
        setToken(cucumberAuthServerHelper.createAccessToken(EXTERNAL_ID_DOCUMENT, partyId, partyTypeId).getValue());
    }

    @Given("^I have a valid token for role (\"[^\"]*\"|[^\"]+) id (\"[^\"]*\"|[^\"]+)$")
    public void setValidTokenForRole(String partyTypeId, String partyId) {
        if (partyTypeId.equalsIgnoreCase("ParaPlanner")) {
            setValidTokenForParaplanner(partyId, "1");
        } else {
            setToken(cucumberAuthServerHelper.createAccessToken(EXTERNAL_ID_DOCUMENT, partyId, partyTypeId).getValue());
        }
    }

    @And("^in response data, the attribute is (\"[^\"]*\"|[^\"]+) and its value is (\"[^\"]*\"|[^\"]+)$")
    public void inResponseDataOwnerIdIsAndOwnerTypeIs(String attributePath, String valueExpected) throws Throwable {
        Assert.assertTrue(valueExpected.equalsIgnoreCase(context.getLatestResponseJson().at(attributePath).textValue()));
    }

    @Given("^I have a valid token for paraplanner external id (\"[^\"]*\"|[^\"]+) impersonating adviser id (\"[^\"]*\"|[^\"]+)$")
    public void setValidTokenForParaplannerImpersonateAdviser(String paraplannerExternalId, String adviserId) {
        setToken(cucumberAuthServerHelper.createAdviserAccessTokenUsingParaPlanner(paraplannerExternalId, "", adviserId, "123").getValue());
    }

    @Given("^I have a valid token for paraplanner external id (\"[^\"]*\"|[^\"]+) under dealer id (\\w+)$")
    public void setValidTokenForParaplanner(String paraplannerExternalId, String dealerId) {
        this.setToken(this.cucumberAuthServerHelper.createParaPlannerAccessToken(paraplannerExternalId, dealerId).getValue());
    }

    private void setToken(String token) {
        this.context.setAccessToken("bearer " + token);
    }
}
