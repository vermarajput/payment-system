package com.gbst.digital.documents.utils;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.party.PartyTypeSettings;
import com.gbst.common.utils.GbstDateUtils;
import com.gbst.digital.documents.exception.CannotGenerateException;
import com.gbst.digital.documents.generator.json.cie.IllustrationDocumentGeneratorSettings;
import com.gbst.digital.documents.resource.model.document.CrystallisationDetails;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.document.DrawdownIncome;
import com.gbst.digital.documents.resource.model.document.FixedProtection;
import com.gbst.digital.documents.resource.model.document.IndividualProtection;
import com.gbst.digital.documents.resource.model.document.Investment;
import com.gbst.digital.documents.resource.model.document.InvestmentStrategy;
import com.gbst.digital.documents.resource.model.document.Protection;
import com.gbst.digital.documents.resource.model.document.RegularContribution;
import com.gbst.digital.documents.resource.model.document.SecondaryAccount;
import com.gbst.digital.documents.resource.model.document.SingleContribution;
import com.gbst.digital.documents.resource.model.document.SippTransferIn;
import com.gbst.digital.documents.resource.model.document.types.AnnuityFreqEnum;
import com.gbst.digital.documents.resource.model.document.types.AnnuityTimingEnum;
import com.gbst.digital.documents.resource.model.document.types.ContributorTypeEnum;
import com.gbst.digital.documents.resource.model.document.types.GenderEnum;
import com.gbst.digital.documents.resource.model.document.types.SippTransferTypeEnum;
import com.gbst.digital.documents.utils.builder.ClientSpecificRequestBuilder;
import com.gbst.digital.services.composer.ProductService;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.common.GenderCharType;
import com.infocomp.cbis.common.YesNoFlag;
import com.infocomp.cbis.uk.domain.common.ClientRequestIllustrationType;
import com.infocomp.cbis.uk.domain.common.IllustrationType;
import com.infocomp.cbis.uk.request.IllustrationChargesType;
import com.infocomp.cbis.uk.request.IllustrationContributionType;
import com.infocomp.cbis.uk.request.IllustrationFundType;
import com.infocomp.cbis.uk.request.IllustrationPayloadType;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import com.infocomp.cbis.uk.response.Product;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.AccumulationIllustration;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.Default;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.DrawdownIllustration;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 12/10/2017
 */
@RunWith(MockitoJUnitRunner.class)
public class IllustrationRequestBuilderTest {
    @Mock
    private ProductService productService;

    @Mock
    private AuthenticationFacade authenticationFacade;

    @Mock
    PartyTypeSettings partyTypeSettings;

    @Spy
    private IllustrationDocumentGeneratorSettings settings;

    @InjectMocks
    @Spy
    private IllustrationRequestBuilder illustrationRequestBuilder;

    @Mock
    private ClientSpecificRequestBuilder clientSpecificRequestBuilder;

    @Before
    public void setup() {
        settings.setDfmChargeDesc("");
        settings.setRegularCommissionDesc("");
        settings.setSingleCommissionDesc("");
        settings.setTrailCommissionDesc("");
        settings.setTransferCommissionDesc("");

        Set scopes = new HashSet<>();
        scopes.add("all_perms");
        OAuth2Authentication mockAuth = mock(OAuth2Authentication.class);
        when(mockAuth.getName()).thenReturn("testuser");
        OAuth2Request oAuth2Request = new OAuth2Request(null, null, null, false, scopes, null, null, null, null);
        when(mockAuth.getOAuth2Request()).thenReturn(oAuth2Request);
        when(authenticationFacade.getAuthentication()).thenReturn(mockAuth);

        GbstPrincipal gbstPrincipal = new GbstPrincipal();
        gbstPrincipal.setUsername("testuser");
        when(authenticationFacade.getPrincipal()).thenReturn(gbstPrincipal);

        SecurityContextHolder.clearContext();
        SecurityContextHolder.getContext().setAuthentication(mockAuth);

        ProductTypes productTypes = new ProductTypes();
        Product p100 = new Product();
        p100.setProductFlag("A");
        p100.setProductTypeId(100);
        p100.setProductGrouping("SIPP");
        productTypes.addProductType(new ProductTypes.ProductType(p100));

        Product p105 = new Product();
        p105.setProductFlag("P");
        p105.setProductTypeId(105);
        productTypes.addProductType(new ProductTypes.ProductType(p105));

        Product p103 = new Product();
        p103.setProductFlag("X");
        p103.setProductTypeId(103);
        productTypes.addProductType(new ProductTypes.ProductType(p103));

        Mockito.when(productService.getProductTypes(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyBoolean(), Mockito.anyBoolean())).thenReturn(productTypes);

        Product pIdd = new Product();
        pIdd.setProductFlag("P");
        pIdd.setProductTypeId(50000);
        ProductTypes.ProductType associatedIdd = new ProductTypes.ProductType(pIdd);
        Mockito.when(productService.getAssociatedIDDProductType(103)).thenReturn(associatedIdd);

        Product pIdd2 = new Product();  //This is to avoid NPE
        pIdd2.setProductFlag("P");
        pIdd2.setProductTypeId(90000);
        Mockito.when(productService.getAssociatedIDDProductType(AdditionalMatchers.not(eq(103)))).thenReturn(new ProductTypes.ProductType(pIdd2));

        Mockito.when(productService.isISA(any())).thenReturn(false);

        Mockito.when(partyTypeSettings.getValueAsInteger("composer", "Adviser")).thenReturn(1);

        doNothing().when(clientSpecificRequestBuilder).enrichRequest(any(), any(), any(), any(), any(), anyBoolean());
    }

    @Test
    public void buildRequestIllustrationType_setTopLevelFields() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertEquals(IllustrationType.N, req.getIllustrationType());
        assertEquals("B", req.getOutputTypeRequired());
        assertEquals(Integer.valueOf(100), req.getProductTypeId());
    }

    @Test
    public void buildRequestIllustrationType_FullDrawdownNoRegContri_setTopLevelFields() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(true);
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1500));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        assertEquals(IllustrationType.N, req.getIllustrationType());
        assertEquals("B", req.getOutputTypeRequired());
        assertEquals(Integer.valueOf(12), req.getProductTypeId());
    }

    @Test
    public void buildRequestIllustrationType_FullDrawdownWithRegContri_setTopLevelFields() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc2 = new RegularContribution();
        rc2.setAmount(new BigDecimal(10));
        rc2.setInitialChargeAmount(new BigDecimal(10));
        rc2.setFrequency("Monthly");
        doc.getRegularContributions().add(rc2);


        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(true);
        doc.getCrystallisationDetails().setUncrystallisedValue(new BigDecimal(1000));
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, AccumulationIllustration);

        assertEquals(IllustrationType.N, req.getIllustrationType());
        assertEquals("B", req.getOutputTypeRequired());
        assertEquals(Integer.valueOf(100), req.getProductTypeId());
    }

    @Test
    public void buildRequestIllustrationType_PartialDrawdown_setTopLevelFields() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(false);
        doc.getCrystallisationDetails().setUncrystallisedValue(new BigDecimal(1000));
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, AccumulationIllustration);

        assertEquals(IllustrationType.N, req.getIllustrationType());
        assertEquals("B", req.getOutputTypeRequired());
        assertEquals(Integer.valueOf(100), req.getProductTypeId());
    }


    @Test
    public void buildRequestIllustrationType_setOtherFields() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(0), payload.getDependantsIllustration());
        checkDateEqualsToNow(payload.getPlanStartDate(), LocalDate.now());
    }

    @Test
    public void buildRequestIllustrationType_setClientRequest() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        assertEquals(true, payload.isClientRequestRequired());
        assertEquals(ClientRequestIllustrationType.DEFAULT, payload.getClientRequest().getIllustrationType());
    }

    @Test
    public void buildRequestIllustrationType_setInvestmentModel() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertEquals(null, req.getInvestmentModelSelected());

        //With inv model id
        doc = getIllustrationDocument(100, 1);
        doc.setInvestmentStrategy(new InvestmentStrategy());
        doc.getInvestmentStrategy().setInvestmentModelId("12");
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        assertEquals(YesNoFlag.Y, req.getInvestmentModelSelected());

        //Without inv model id
        doc = getIllustrationDocument(100, 1);
        doc.setInvestmentStrategy(new InvestmentStrategy());
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        assertEquals(YesNoFlag.N, req.getInvestmentModelSelected());

    }

    @Test
    public void buildRequestIllustrationType_setProductType() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertEquals(Integer.valueOf(100), req.getProductTypeId());

        //other prod types - CRYSTALLISE
        doc = getIllustrationDocument(103, 1);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.CRYSTALLISE, Default);

        assertEquals(Integer.valueOf(50000), req.getProductTypeId());

        //DRAWDOWN - no crystallisation details
        doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setUncrystallisedValue(new BigDecimal(1000));
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, AccumulationIllustration);

        assertEquals(Integer.valueOf(100), req.getProductTypeId());

        //other prod types - DRAWDOWN
        doc = getIllustrationDocument(103, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        assertEquals(Integer.valueOf(12), req.getProductTypeId());


    }

    @Test
    public void buildRequestIllustrationType_setQuoteType() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(4), payload.getQuoteType());

        //Pension - New Business
        doc = getIllustrationDocument(105, 1);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(8), payload.getQuoteType());

        //Accumulation - DRAWDOWN
        doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1000));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");
        
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(8), payload.getQuoteType());
        assertEquals(Integer.valueOf(12), req.getProductTypeId());
        
        //other prod types - DRAWDOWN
        doc = getIllustrationDocument(103, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(8), payload.getQuoteType());

        //other prod types - CRYSTALLISE
        doc = getIllustrationDocument(103, 1);
        Product pIdd = new Product();
        pIdd.setProductFlag("P");
        pIdd.setProductTypeId(50000);
        ProductTypes.ProductType associatedIdd = new ProductTypes.ProductType(pIdd);
        Mockito.when(productService.getAssociatedIDDProductType(103)).thenReturn(associatedIdd);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.CRYSTALLISE, Default);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(6), payload.getQuoteType());

        //other prod types - Other process types
        doc = getIllustrationDocument(103, 1);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.TRANSFER_IN, Default);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(0), payload.getQuoteType());

    }

    @Test
    public void buildRequestIllustrationType_setAnnuities_setFinalAnnuityDate() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setInvestorDateOfBirth(LocalDate.of(1988, 5, 5));
        doc.setInvestorFirstName("Jean");
        doc.setInvestorLastName("Reno");
        doc.setInvestorGender(GenderEnum.Male);
        doc.setInvestorExpectedRetirementAge(30);

        LocalDate Today17Oct2017 = LocalDate.of(2017, 10, 17);
        Mockito.when(illustrationRequestBuilder.getToday()).thenReturn(Today17Oct2017);

        // When retirement age is after today: 17 Oct 2017
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        checkDateEqualsToNow(payload.getFinalAnnuityDate(), doc.getInvestorDateOfBirth().plusYears(30));

        // When retirement age is before today: 17 Oct 2017
        doc.setInvestorDateOfBirth(LocalDate.of(1980, 5, 5));
        doc.setInvestorExpectedRetirementAge(30);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        payload = req.getIllustrationPayload();

        checkDateEqualsToNow(payload.getFinalAnnuityDate(), doc.getInvestorDateOfBirth().plusYears(30 + 10));

    }

    @Test
    public void buildRequestIllustrationType_setAnnuities() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setInvestorDateOfBirth(LocalDate.of(1889, 5, 5));
        doc.setInvestorFirstName("Jean");
        doc.setInvestorLastName("Reno");
        doc.setInvestorGender(GenderEnum.Male);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();
        //testing default values

        assertEquals(Integer.valueOf(1), payload.getAnnuityFrequency()); // no annu frequency
        assertEquals(Integer.valueOf(0), payload.getAnnuityEscalationType());
        assertEquals(Double.valueOf(0), payload.getAnnuityEscalation()); // no annu escalation
        assertEquals(Integer.valueOf(5), payload.getAnnuityGuaranteePeriod());
        assertEquals(Double.valueOf(0.5), payload.getAnnuitySpousePension());
        assertEquals(Integer.valueOf(0), payload.getAnnuityTiming());

        //Scenario 2 - Testing with values
        doc.setAnnuityFrequency(AnnuityFreqEnum.Annual);
        doc.setAnnuityEscalation(new BigDecimal(40));
        doc.setAnnuityGuarantee(new BigDecimal(55));
        doc.setDependantPensionPercent(new BigDecimal(20));
        doc.setAnnuityTiming(AnnuityTimingEnum.InAdvance);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(12), payload.getAnnuityFrequency());
        assertEquals(Double.valueOf(40), payload.getAnnuityEscalation());
        assertEquals(Integer.valueOf(4), payload.getAnnuityEscalationType());
        assertEquals(Integer.valueOf(55), payload.getAnnuityGuaranteePeriod());
        assertEquals(Double.valueOf(20), payload.getAnnuitySpousePension());
        assertEquals(Integer.valueOf(0), payload.getAnnuityTiming()); //in advance

        //Scenario 3, Annuity timing is InArrears - Arrears
        doc.setAnnuityTiming(AnnuityTimingEnum.InArrears);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(1), payload.getAnnuityTiming());

    }

    @Test
    public void buildRequestIllustrationType_setPersonalDetails_ProtectedAge() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setInvestorDateOfBirth(LocalDate.of(1889, 5, 5));
        doc.setInvestorFirstName("Jean");
        doc.setInvestorLastName("Reno");
        doc.setInvestorGender(GenderEnum.Male);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        //no transfer-in = no protected age
        assertEquals(null, payload.getMemberDetails().getPersonalDetails().getProtectedAge());

        //Scenario 2
        //With transfer-in and protected age present we will have protected age in the request
        doc.setSippTransferIns(new LinkedList<>());
        SippTransferIn rc1 = new SippTransferIn();
        rc1.setAmount(new BigDecimal(10));
        rc1.setProtectedAge(55);
        doc.getSippTransferIns().add(rc1);

        SippTransferIn rc2 = new SippTransferIn();
        rc2.setAmount(new BigDecimal(20));
        doc.getSippTransferIns().add(rc2);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(55), payload.getMemberDetails().getPersonalDetails().getProtectedAge());

        //Scenario 3
        //With transfer-in and NO protected age present we won't have protected age
        doc.setSippTransferIns(new LinkedList<>());
        rc1.setProtectedAge(null);
        doc.getSippTransferIns().add(rc1);
        doc.getSippTransferIns().add(rc2);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        assertEquals(null, payload.getMemberDetails().getPersonalDetails().getProtectedAge());

    }
        @Test
    public void buildRequestIllustrationType_setPersonalDetails_Dependent() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setDependantDateOfBirth(LocalDate.of(1889, 5, 5));
        doc.setDependantGender(GenderEnum.Female);
        doc.setDependantPensionPercent(new BigDecimal(15));
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(1), payload.getMemberDetails().getAdviserAccountId());

        checkDateEqualsToNow(payload.getMemberDetails().getSpouseDetails().getDateOfBirth(), LocalDate.of(1889, 5, 5));
        assertEquals(null, payload.getMemberDetails().getSpouseDetails().getFirstName());
        assertEquals(null, payload.getMemberDetails().getSpouseDetails().getSurname());
        assertEquals(null, payload.getMemberDetails().getSpouseDetails().getTitle());
        assertEquals(GenderCharType.F, payload.getMemberDetails().getSpouseDetails().getGender());

        //test when dob and gender are null
        doc.setDependantDateOfBirth(null);
        doc.setDependantGender(null);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        assertEquals(null, payload.getMemberDetails().getSpouseDetails());

        //test when dependent pension percent is null
        doc.setDependantPensionPercent(null);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        payload = req.getIllustrationPayload();

        assertTrue(payload.getMemberDetails().getSpouseDetails() == null);

    }

    @Test
    public void buildRequestIllustrationType_setPersonalDetails_Investor() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setInvestorDateOfBirth(LocalDate.of(1889, 5, 5));
        doc.setInvestorFirstName("Jean");
        doc.setInvestorLastName("Reno");
        doc.setInvestorTitle("Duke");
        doc.setInvestorGender(GenderEnum.Male);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(1), payload.getMemberDetails().getAdviserAccountId());

        checkDateEqualsToNow(payload.getMemberDetails().getPersonalDetails().getDateOfBirth(), LocalDate.of(1889, 5, 5));
        assertEquals("Jean", payload.getMemberDetails().getPersonalDetails().getFirstName());
        assertEquals("Reno", payload.getMemberDetails().getPersonalDetails().getSurname());
        assertEquals("Duke", payload.getMemberDetails().getPersonalDetails().getTitle());
        assertEquals(GenderCharType.M, payload.getMemberDetails().getPersonalDetails().getGender());

        //test when dob and gender are null
        doc.setInvestorDateOfBirth(null);
        doc.setInvestorGender(null);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        payload = req.getIllustrationPayload();

        checkDateEqualsToNow(payload.getMemberDetails().getPersonalDetails().getDateOfBirth(), LocalDate.of(1900, 1, 1));
        assertEquals(GenderCharType.N, payload.getMemberDetails().getPersonalDetails().getGender());
    }

        @Test
    public void buildRequestIllustrationType_setProtectionOptions() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertEquals(Integer.valueOf(0), req.getIllustrationPayload().getProtection().getType());
        assertEquals(Double.valueOf(0), req.getIllustrationPayload().getProtection().getSsls());

        assertEquals(Boolean.FALSE, req.getIllustrationPayload().getProtection().isEnhancedProtection());
        assertEquals(Integer.valueOf(0), req.getIllustrationPayload().getProtection().getPrimaryProtection());
        assertEquals(Double.valueOf(0), req.getIllustrationPayload().getProtection().getEnhancedTfc());
        assertEquals(Double.valueOf(0), req.getIllustrationPayload().getProtection().getLtaEnhancement());
        assertEquals(Double.valueOf(0), req.getIllustrationPayload().getProtection().getProtectedTfc());

        //Fixed Protection
        doc.setProtection(new Protection());
        doc.getProtection().setFixedProtection(new FixedProtection());
        doc.getProtection().getFixedProtection().setYear("2012");

        //2012
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertEquals(Integer.valueOf(3), req.getIllustrationPayload().getProtection().getType());

        //2014
        doc.getProtection().getFixedProtection().setYear("2014");
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertEquals(Integer.valueOf(4), req.getIllustrationPayload().getProtection().getType());

        //2016
        doc.getProtection().getFixedProtection().setYear("2016");
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertEquals(Integer.valueOf(6), req.getIllustrationPayload().getProtection().getType());

        //Individual Protection
        doc.setProtection(new Protection());
        doc.getProtection().setFixedProtection(null);
        doc.getProtection().setIndividualProtection(new IndividualProtection());
        doc.getProtection().getIndividualProtection().setYear("2014");

        //2015
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertEquals(Integer.valueOf(5), req.getIllustrationPayload().getProtection().getType());

        //2016
        doc.getProtection().getIndividualProtection().setYear("2016");
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertEquals(Integer.valueOf(7), req.getIllustrationPayload().getProtection().getType());

    }

    @Test
    public void buildRequestIllustrationType_setMixedContribution() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setSingleContributions(new LinkedList<>());
        SingleContribution rc1 = new SingleContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setInitialChargePercent(new BigDecimal(10));
        doc.getSingleContributions().add(rc1);

        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc2 = new RegularContribution();
        rc2.setAmount(new BigDecimal(10));
        rc2.setInitialChargeAmount(new BigDecimal(10));
        rc2.setFrequency("Monthly");
        doc.getRegularContributions().add(rc2);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().isMixedContribution());
    }

        @Test
    public void buildRequestIllustrationType_setProductCharges_AdviserChargeTransferIn() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setSippTransferIns(new LinkedList<>());
        SippTransferIn rc1 = new SippTransferIn();
        rc1.setAmount(new BigDecimal(10));
        rc1.setInitialChargePercent(new BigDecimal(10));
        doc.getSippTransferIns().add(rc1);

        SippTransferIn rc2 = new SippTransferIn();
        rc2.setAmount(new BigDecimal(30));
        rc2.setInitialChargePercent(new BigDecimal(30));
        doc.getSippTransferIns().add(rc2);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getProductCharges() != null && !req.getIllustrationPayload().getProductCharges().getCharge().isEmpty());

        boolean hasTransferCharge = false;
        for(IllustrationChargesType c : req.getIllustrationPayload().getProductCharges().getCharge()) {
            if(IllustrationRequestBuilder.TRANSFER_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(40), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
                assertEquals(BigInteger.ZERO, c.getCalculationType());
                hasTransferCharge = true;
            }
        }

        if(!hasTransferCharge) {
            fail("No transfer in commission charge returned");
        }

        //Mixed percentage and amount
        SippTransferIn rc3 = new SippTransferIn();
        rc3.setAmount(new BigDecimal(20));
        rc3.setInitialChargeAmount(new BigDecimal(30));
        doc.getSippTransferIns().add(rc3);

        try {
            illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        }catch (IllegalStateException x) {
            //ok
            return;
        }
        fail("We shouldn't get to this point");
    }

    @Test
    public void buildRequestIllustrationType_setProductCharges_AdviserChargeSingleContb() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setSingleContributions(new LinkedList<>());
        SingleContribution rc1 = new SingleContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setInitialChargePercent(new BigDecimal(10));
        doc.getSingleContributions().add(rc1);

        SingleContribution rc2 = new SingleContribution();
        rc2.setAmount(new BigDecimal(20));
        rc2.setInitialChargePercent(new BigDecimal(30));
        doc.getSingleContributions().add(rc2);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getProductCharges() != null && !req.getIllustrationPayload().getProductCharges().getCharge().isEmpty());
        boolean hasSingleCharge = false;
        for(IllustrationChargesType c : req.getIllustrationPayload().getProductCharges().getCharge()) {
            if(IllustrationRequestBuilder.SINGLE_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(40), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
                assertEquals(BigInteger.ZERO, c.getCalculationType());
                hasSingleCharge = true;
            }
        }

        if(!hasSingleCharge) {
            fail("No single commission charge returned");
        }

        //Mixed percentage and amount
        SingleContribution rc3 = new SingleContribution();
        rc3.setAmount(new BigDecimal(20));
        rc3.setInitialChargeAmount(new BigDecimal(30));
        doc.getSingleContributions().add(rc3);

        try {
            illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        }catch (IllegalStateException x) {
            //ok
            return;
        }
        fail("We shouldn't get to this point");
    }

    @Test
    public void buildRequestIllustrationType_setProductCharges_AdviserChargeRegularContb() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc1 = new RegularContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setInitialChargeAmount(new BigDecimal(10));
        rc1.setFrequency("Monthly");
        doc.getRegularContributions().add(rc1);

        RegularContribution rc2 = new RegularContribution();
        rc2.setAmount(new BigDecimal(20));
        rc2.setFrequency("Monthly");
        rc2.setInitialChargeAmount(new BigDecimal(30));
        doc.getRegularContributions().add(rc2);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getProductCharges() != null && !req.getIllustrationPayload().getProductCharges().getCharge().isEmpty());
        boolean hasRegularCharge = false;
        for(IllustrationChargesType c : req.getIllustrationPayload().getProductCharges().getCharge()) {
            if(IllustrationRequestBuilder.TRAIL_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode()) && Double.valueOf(40).equals(c.getChargeValue())) {
                assertEquals("", c.getDescription());
                assertEquals(BigInteger.ONE, c.getCalculationType());
                hasRegularCharge = true;
            }
        }

        if(!hasRegularCharge) {
            fail("No trail commission charge returned");
        }

        //Mixed percentage and amount
        RegularContribution rc3 = new RegularContribution();
        rc3.setAmount(new BigDecimal(20));
        rc3.setFrequency("Monthly");
        rc3.setInitialChargePercent(new BigDecimal(30));
        doc.getRegularContributions().add(rc3);

        try {
            illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        }catch (IllegalStateException x) {
            //ok
            return;
        }
        fail("We shouldn't get to this point");
    }


    @Test
    public void buildRequestIllustrationType_setProductCharges_AdviserChargePercentageBased() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setOngoingAdviserChargePercent(new BigDecimal(15));
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getProductCharges() != null && !req.getIllustrationPayload().getProductCharges().getCharge().isEmpty());

        for(IllustrationChargesType c : req.getIllustrationPayload().getProductCharges().getCharge()) {
            if(IllustrationRequestBuilder.TRAIL_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(15), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
            } else if(IllustrationRequestBuilder.DFM_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(0), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
            } else {
                fail("Shouldn't be more charge here");
            }
        }
    }

    @Test
    public void buildRequestIllustrationType_setProductCharges_AdviserChargeAmountBased() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setOngoingAdviserChargeAmount(new BigDecimal(15));
        doc.setOngoingAdviserChargeFrequency("Monthly");
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getProductCharges() != null && !req.getIllustrationPayload().getProductCharges().getCharge().isEmpty());

        for(IllustrationChargesType c : req.getIllustrationPayload().getProductCharges().getCharge()) {
            if(IllustrationRequestBuilder.FIXED_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(15), (Double)c.getChargeValue());
                assertEquals("Monthly", c.getDescription());
            } else if(IllustrationRequestBuilder.TRAIL_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(15), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
            } else if(IllustrationRequestBuilder.DFM_COMM_CHARGE_TYPE_CODE.equals(c.getChargeTypeCode())) {
                assertEquals(Double.valueOf(0), (Double)c.getChargeValue());
                assertEquals("", c.getDescription());
            } else {
                fail("Shouldn't be more charge here");
            }
        }

    }

    @Test
    public void buildRequestIllustrationType_setProductCharges_RegularContribCharge() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

    }

    @Test
    public void buildRequestIllustrationType_setIncomeRequired() throws Exception {

        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        assertEquals(null, req.isIncomeRequired());

        //with income
        doc.setDrawdownIncome(new DrawdownIncome());
        doc.getDrawdownIncome().setAmount(BigDecimal.ONE);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        assertEquals(true, req.isIncomeRequired());

        //without income
        doc.setDrawdownIncome(new DrawdownIncome());
        doc.getDrawdownIncome().setAmount(BigDecimal.ZERO);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        assertEquals(null, req.isIncomeRequired());

        //Crys
        doc.getDrawdownIncome().setAmount(BigDecimal.ONE);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.CRYSTALLISE, Default);
        assertEquals(true, req.isIncomeRequired());
    }

    @Test
    public void buildRequestIllustrationType_setTargetTfc() throws Exception {
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(true);
        doc.getCrystallisationDetails().setCrystallisedValue(BigDecimal.TEN);
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1500));
        doc.setProductTypeId(100);
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("105");
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        IllustrationPayloadType payload = req.getIllustrationPayload();
        //Check default values
        assertEquals(null, payload.getTargetTfcAmount());
        assertEquals(null, payload.getTargetTfcPercentage());

        //crystallise
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setPclsAmount(BigDecimal.TEN);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.CRYSTALLISE, Default);
        payload = req.getIllustrationPayload();

        assertEquals(Double.valueOf(0), payload.getTargetTfcAmount());
        assertEquals(null, payload.getTargetTfcPercentage());

        //drawdown
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setPclsAmount(BigDecimal.TEN);
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        payload = req.getIllustrationPayload();

        assertEquals(Double.valueOf(10), payload.getTargetTfcAmount());
        assertEquals(Double.valueOf(0), payload.getTargetTfcPercentage());

        //drawdown
        doc.setProductTypeId(103); //not P or A
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.getCrystallisationDetails().setPclsAmount(BigDecimal.TEN);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        payload = req.getIllustrationPayload();

        assertEquals(Double.valueOf(10), payload.getTargetTfcAmount());
        assertEquals(Double.valueOf(0), payload.getTargetTfcPercentage());

    }
    @Test
    public void buildRequestIllustrationType_setIncomeOptions() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        IllustrationPayloadType payload = req.getIllustrationPayload();
        //Check default values
        assertEquals(Integer.valueOf(0), payload.getTargetIncomeType());
        assertEquals(null, payload.getTargetIncreaseMethod());
        assertEquals(null, payload.getIncomeFrequency());
        assertEquals(null, payload.getIncomeAmount());
        assertEquals(null, payload.getIncomeEscalation());
        assertEquals(null, payload.isFlexibleIncome());
        checkDateEqualsToNow(payload.getIncomeStartDate(), LocalDate.now());

        doc.setDrawdownIncome(new DrawdownIncome());
        doc.getDrawdownIncome().setFrequency("Monthly");
        doc.getDrawdownIncome().setAmount(new BigDecimal(300));
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        payload = req.getIllustrationPayload();

        assertEquals(Integer.valueOf(1), payload.getIncomeFrequency());
        assertEquals(Double.valueOf(300), payload.getIncomeAmount());
        assertEquals(Integer.valueOf(2), payload.getTargetIncomeType());

    }

    @Test
    public void buildRequestIllustrationType_setContributions_TransferIn() throws Exception {
        //Accumulation - New Business - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() == null || req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        //Accumulation - New Business - Regular contribution
        doc = getIllustrationDocument(100, 1);
        doc.setSippTransferIns(new LinkedList<>());
        SippTransferIn rc1 = new SippTransferIn();
        rc1.setAmount(new BigDecimal(10));
        rc1.setTransferType(SippTransferTypeEnum.PensionCredit);
        doc.getSippTransferIns().add(rc1);

        SippTransferIn rc2 = new SippTransferIn();
        rc2.setAmount(new BigDecimal(20));
        doc.getSippTransferIns().add(rc2);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() != null && !req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        for(IllustrationContributionType c : req.getIllustrationPayload().getContributions().getContribution()) {
            if(c.getAmount() == 10D) {
                //rc1
                assertEquals(Integer.valueOf(6), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());
            } else if (c.getAmount() == 20D) {
                assertEquals(Integer.valueOf(1), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());

            } else {
                fail("Should only be 2 contributions");
            }
        }

        //When product type is not Accumulation nor Pension
        doc.setProductTypeId(103);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() != null && !req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        for(IllustrationContributionType c : req.getIllustrationPayload().getContributions().getContribution()) {
            if(c.getAmount() == 10D) {
                //rc1
                assertEquals(Integer.valueOf(1), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());
            } else if(c.getAmount() == 20D) {
                //rc2
                assertEquals(Integer.valueOf(1), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());
            } else {
                fail("Should only be 2 contributions");
            }
        }

        //When product type is Pension
        doc.setProductTypeId(105);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);
        assertTrue(req.getIllustrationPayload().getContributions() != null && req.getIllustrationPayload().getContributions().getContribution().size() == 2);

    }

    @Test
    public void buildRequestIllustrationType_setContributions_Single() throws Exception {
        //Accumulation - New Business - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() == null || req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        //Accumulation - New Business - Regular contribution
        doc = getIllustrationDocument(100, 1);
        doc.setSingleContributions(new LinkedList<>());
        SingleContribution rc1 = new SingleContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setContributorType(ContributorTypeEnum.Investor);
        doc.getSingleContributions().add(rc1);

        SingleContribution rc2 = new SingleContribution();
        rc2.setAmount(new BigDecimal(20));
        rc2.setContributorType(ContributorTypeEnum.Employer);
        doc.getSingleContributions().add(rc2);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() != null && !req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        for(IllustrationContributionType c : req.getIllustrationPayload().getContributions().getContribution()) {
            if(c.getAmount() == 10D) {
                //rc1
                checkDateEqualsToNow(c.getStartDate(), LocalDate.now());
                assertEquals(Integer.valueOf(3), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());
            } else if(c.getAmount() == 20D) {
                //rc2
                checkDateEqualsToNow(c.getStartDate(), LocalDate.now());
                assertEquals(Integer.valueOf(2), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(null, c.getFrequency());
            } else {
                fail("Should only be 3 contributions");
            }

        }
    }

    @Test
    public void buildRequestIllustrationType_setContributions_Regular() throws Exception {
        //Accumulation - New Business - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() == null || req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        //Accumulation - New Business - Regular contribution
        doc = getIllustrationDocument(100, 1);
        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc1 = new RegularContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setFrequency("Monthly");
        rc1.setContributorType(ContributorTypeEnum.Investor);
        doc.getRegularContributions().add(rc1);

        RegularContribution rc2 = new RegularContribution();
        rc2.setAmount(new BigDecimal(20));
        rc2.setFrequency("Quarterly");
        rc2.setContributorType(ContributorTypeEnum.Employer);
        doc.getRegularContributions().add(rc2);

        RegularContribution rc3 = new RegularContribution();
        rc3.setAmount(new BigDecimal(30));
        rc3.setFrequency(null);//Should be defaulted to 1
        rc3.setIndexByRPIFlag(true); //Escalation type = AEI
        rc3.setContributorType(ContributorTypeEnum.Employer);
        doc.getRegularContributions().add(rc3);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        assertTrue(req.getIllustrationPayload().getContributions() != null && !req.getIllustrationPayload().getContributions().getContribution().isEmpty());

        for(IllustrationContributionType c : req.getIllustrationPayload().getContributions().getContribution()) {
            if(c.getAmount() == 10D) {
                //rc1
                checkDateEqualsToNow(c.getStartDate(), LocalDate.now());
                assertEquals(Integer.valueOf(3), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(Integer.valueOf(1), c.getFrequency());
            } else if(c.getAmount() == 20D) {
                //rc2
                checkDateEqualsToNow(c.getStartDate(), LocalDate.now());
                assertEquals(Integer.valueOf(2), c.getContributionType());
                assertEquals(null, c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(Integer.valueOf(3), c.getFrequency());
            } else if(c.getAmount() == 30D) {
                //rc3
                checkDateEqualsToNow(c.getStartDate(), LocalDate.now());
                assertEquals(Integer.valueOf(2), c.getContributionType());
                assertEquals(Integer.valueOf(2), c.getEscalationType());
                assertEquals(null, c.getEscalationValue());
                assertEquals(Integer.valueOf(1), c.getFrequency());//Should be defaulted
            } else {
                fail("Should only be 3 contributions");
            }

        }
    }

    @Test
    public void buildRequestIllustrationType_setContributions_FullDrawdown() throws Exception {
        //Drawdown - Immediate Drawdown - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystallisedValue(new BigDecimal(1000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1100));
        doc.setSecondaryAccount(new SecondaryAccount());
        doc.getSecondaryAccount().setProductTypeId("12");

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);

        assertTrue(req.getIllustrationPayload().getContributions() != null && req.getIllustrationPayload().getContributions().getContribution().size() == 1);
        assertEquals(new Double(1100), req.getIllustrationPayload().getContributions().getContribution().get(0).getAmount());
        
        //Drawdown - Immediate Drawdown - CrystallisedValue with Regular Contribution
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(true);
        doc.getCrystallisationDetails().setCrystallisedValue(BigDecimal.valueOf(1000));
        doc.getCrystallisationDetails().setUncrystallisedValue(BigDecimal.valueOf(2000));
        doc.getCrystallisationDetails().setAmountToCrystallise(new BigDecimal(1500));

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, DrawdownIllustration);
        assertTrue("Contributions cannot be null.",req.getIllustrationPayload().getContributions() != null);
        assertTrue("Expected one Contribution.", !req.getIllustrationPayload().getContributions().getContribution().isEmpty() && req.getIllustrationPayload().getContributions().getContribution().size() == 1);
        assertTrue("Amount should be 1500.", req.getIllustrationPayload().getContributions().getContribution().get(0).getAmount().equals(1500.0));
    }

  
    @Test
    public void buildRequestIllustrationType_setContributions_FullDrawdown_UseTotalRegularAmount_WithRegularContribution() throws Exception {
        //Drawdown - Immediate Drawdown - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(true);
        doc.getCrystallisationDetails().setCrystallisedValue(BigDecimal.valueOf(1000));

        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc1 = new RegularContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setFrequency("Monthly");
        rc1.setContributorType(ContributorTypeEnum.Investor);
        doc.getRegularContributions().add(rc1);
        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, AccumulationIllustration);
        assertTrue(req.getIllustrationPayload().getContributions() != null);
        assertTrue("Expected one Contribution.", !req.getIllustrationPayload().getContributions().getContribution().isEmpty() && req.getIllustrationPayload().getContributions().getContribution().size() == 1);
        assertEquals(new Double(10), req.getIllustrationPayload().getContributions().getContribution().get(0).getAmount());
    }

    @Test
    public void buildRequestIllustrationType_setContributions_PartialDrawdown_UseUncrystallised_WithRegularContribution() throws Exception {
        //Drawdown - Immediate Drawdown - No contribution
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setCrystallisationDetails(new CrystallisationDetails());
        doc.getCrystallisationDetails().setCrystalliseFullAmountFlag(false);
        doc.getCrystallisationDetails().setUncrystallisedValue(BigDecimal.valueOf(1000));

        doc.setRegularContributions(new LinkedList<>());
        RegularContribution rc1 = new RegularContribution();
        rc1.setAmount(new BigDecimal(10));
        rc1.setFrequency("Monthly");
        rc1.setContributorType(ContributorTypeEnum.Investor);
        doc.getRegularContributions().add(rc1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.DRAWDOWN, AccumulationIllustration);
        assertTrue(req.getIllustrationPayload().getContributions() != null);

        //1 contribution for uncrystallised amount and 1 for the regular contribution in the payload
        assertTrue("Expected one Contribution.", !req.getIllustrationPayload().getContributions().getContribution().isEmpty() && req.getIllustrationPayload().getContributions().getContribution().size() == 2);

        Double[] values = new Double[2];
        values[0] = req.getIllustrationPayload().getContributions().getContribution().get(0).getAmount();
        values[1] = req.getIllustrationPayload().getContributions().getContribution().get(1).getAmount();

        Arrays.sort(values);
        assertArrayEquals(new Double[] {Double.valueOf(10.0), Double.valueOf(1000.0)}, values);

    }

    private void checkDateEqualsToNow(XMLGregorianCalendar date, LocalDate expected) {
        XMLGregorianCalendar expectedCal = GbstDateUtils.asXMLGregorianCalendar(expected);
        assertEquals(expectedCal.getDay(), date.getDay());
        assertEquals(expectedCal.getMonth(), date.getMonth());
        assertEquals(expectedCal.getYear(), date.getYear());
    }

    @Test
    public void buildRequestIllustrationType_setTranches() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        //no transfer in, no tranches
        assertTrue(req.getIllustrationPayload().getTranches() == null || req.getIllustrationPayload().getTranches().getTranche().isEmpty());

        //Accumulation - New Business
        doc = getIllustrationDocument(100, 1);
        doc.setSippTransferIns(new LinkedList<>());
        SippTransferIn t1 = new SippTransferIn();
        t1.setAmount(new BigDecimal(10));
        t1.setInitialChargeAmount(new BigDecimal(5));
        doc.getSippTransferIns().add(t1);

        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        //Accumulation product and transfer in = no tranches
        assertTrue(req.getIllustrationPayload().getTranches() == null || req.getIllustrationPayload().getTranches().getTranche().isEmpty());

        doc.setProductTypeId(105);
        req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        //Accumulation product and transfer in = no tranches
        assertTrue(req.getIllustrationPayload().getTranches() != null && !req.getIllustrationPayload().getTranches().getTranche().isEmpty());
        assertEquals(Double.valueOf(0), (Double)req.getIllustrationPayload().getTranches().getTranche().get(0).getGadMaxValue());
        //TODO when this is complete more fields to be tested
    }

        @Test
    public void buildRequestIllustrationType_setFund() throws Exception {
        //Accumulation - New Business
        DocumentAttributes doc = getIllustrationDocument(100, 1);
        doc.setInvestmentStrategy(new InvestmentStrategy());
        doc.getInvestmentStrategy().setInvestments(new LinkedList<>());

        Investment inv501 = new Investment();
        inv501.setInvestmentId("501");
        inv501.setInvestmentPercent(new BigDecimal(10));
        doc.getInvestmentStrategy().getInvestments().add(inv501);

        Investment inv502 = new Investment();
        inv502.setInvestmentId("502");
        inv502.setInvestmentPercent(new BigDecimal(20));
        doc.getInvestmentStrategy().getInvestments().add(inv502);

        RequestIllustrationType req = illustrationRequestBuilder.buildRequestIllustrationType(doc, ProcessType.NEW_BUSINESS, Default);

        IllustrationPayloadType.Funds funds = req.getIllustrationPayload().getFunds();
        assertTrue(funds != null && funds.getFund() != null && !funds.getFund().isEmpty());

        for(IllustrationFundType f : funds.getFund()) {
            if(f.getPortfolioId() == 501) {
                assertEquals(Double.valueOf(10), f.getFundValue());
            } else if(f.getPortfolioId() == 502) {
                assertEquals(Double.valueOf(20), f.getFundValue());
            } else {
                fail("There shouldn't be extra records here");
            }
        }
    }

    private DocumentAttributes getIllustrationDocument(Integer productTypeId, Integer adviserId) {
        DocumentAttributes doc = new DocumentAttributes();
        doc.setAdviserId(adviserId + "");
        doc.setProductTypeId(productTypeId);
        doc.setOwnerType("Adviser");
        return doc;
    }

}