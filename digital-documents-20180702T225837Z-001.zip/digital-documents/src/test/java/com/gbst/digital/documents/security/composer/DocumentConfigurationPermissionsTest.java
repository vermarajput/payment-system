package com.gbst.digital.documents.security.composer;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.jsonapi.GbstJsonApiAccessDeniedException;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 6/02/2018
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentConfigurationPermissionsTest {

    @Mock
    AuthenticationFacade authenticationFacade;

    @InjectMocks
    DocumentConfigurationPermissions permissions;
    
    @Before
    public void setUp() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("coco");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("SysAdmin");
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
    }

    @Test
    public void check_access_permitted() throws Exception {
        try {
            permissions.check(OperationEnum.Save, new DocumentConfiguration());
        } catch (GbstJsonApiAccessDeniedException x) {
            fail("Should not fail");
        }
    }

    @Test(expected = GbstJsonApiAccessDeniedException.class)
    public void checkOwnership_access_denied() {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("coco");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        when(authenticationFacade.getPrincipal()).thenReturn(principal);

        permissions.check(OperationEnum.Save, new DocumentConfiguration());
    }

    @Test
    public void check() throws Exception {
        try {
            GbstPrincipal principal = new GbstPrincipal();
            principal.setUsername("coco");
            principal.setGbstPartyId("14");
            principal.setGbstPartyType("Adviser");

            permissions.check(OperationEnum.FindOne, new DocumentConfiguration());
        } catch (GbstJsonApiAccessDeniedException x) {
            fail("Should not fail");
        }
    }

}