package com.gbst.digital.documents.acceptance;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.junit.WireMockClassRule;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.runner.RunWith;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources",
        glue={"classpath:com.gbst.digital.documents.acceptance","classpath:com.gbst.common.acceptance"},
        plugin = {"pretty", "json:target/surefire-reports/cucumber.json"},
        strict = true)
public class CucumberTest {
    public static final WireMockServer wireMockServer = new WireMockServer(13579);

    @BeforeClass
    public static void setup() {
        try {
            //This is to fix IllegalStateException that we get at the end of maven execution
            //This makes the static logger in ReportBuilder to be initialised before it's too late at shutdown time
            new ReportBuilder(null, null);
        }catch (Exception x) {
            //it's ok
        }
    }
    /**
     * Generate reports after the test have run.
     */
    @AfterClass
    public static void generateReports() {
        // cannot use @AfterClass directly as the cucumber.json file is empty at that point.
        Runtime.getRuntime().addShutdownHook(new Thread(new ReportGen()));
    }

    public static class ReportGen implements Runnable {
        @Override
        public void run() {

            File reportOutputDirectory = new File("target");
            List<String> jsonFiles = new ArrayList<>();
            jsonFiles.add("target/surefire-reports/cucumber.json");
            String projectName = "Digital Documents";
            Configuration configuration = new Configuration(reportOutputDirectory, projectName);
            ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
            reportBuilder.generateReports();
            wireMockServer.stop();   //this should be the last statement or wrap it with try/catch

        }
    }
}
