package com.gbst.digital.documents.acceptance;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;

public class SwaggerDefs extends DocumentBaseDefs {
    @When("^the client calls /api-docs/swagger.json$")
    public void theClientCallsApidocsSwaggerJson() throws Throwable {
        executeGet(apiUrlSwagger + "/api-docs/swagger.json", "application/json");
    }

    @Then("^the client receives the swagger definition$")
    public void theClientReceivesStatusUp() throws Throwable {
        assertThat(context.getLatestResponse().getBody(), containsString("\"title\": \"Documents service\""));
    }

    @When("^the client calls /docs/index.html$")
    public void theClientCallsDocsIndexHtml() throws Throwable {
        executeHtmlGet(apiUrlSwagger + "/docs/index.html");
    }

    @Then("^the client receives the swagger ui$")
    public void theClientReceivesSwaggerUi() throws Throwable {
        assertThat(context.getLatestResponseHtml(), containsString("<title>Swagger UI</title>"));
    }
}
