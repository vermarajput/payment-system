package com.gbst.digital.documents.acceptance;

import com.fasterxml.jackson.databind.JsonNode;
import com.gbst.common.acceptance.JsonApiRequest;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

import java.io.File;
import java.util.*;

import static org.junit.Assert.assertTrue;

public class CleanupDocumentGenerationDefs extends DocumentBaseDefs {
    private static final String REGEX_SERVICE_NAME = "([\\w\\-]+)";

    @When("^send a POST request to cleanup-document-generation service to delete document-generation records and associated document files$")
    public void sendCleanupDocumentRequest(Map<String, String> mapData) throws Exception {
        String url = apiUrl + "/cleanup-document-generation/";
        List<String> quoteIdList = Arrays.asList(mapData.get("processId").split(","));

        JsonApiRequest.Builder builder = JsonApiRequest.builder();
        JsonNode quoteIds = builder.getNode(quoteIdList);
        String requestBody = quoteIds.toString();
        logger.info("POST [{}]", url, requestBody);
        this.executePostAndStoreRequest(url, requestBody);
    }

    @And("^documents are created in file system$")
    public void verifyDocumentFilesAreCreated(Map<String, String> mapData) throws Exception {
        String processId = mapData.get("processId");
        JsonNode arrNode = context.getLatestResponseJson().at("/data/attributes/documents");
        assertTrue(!arrNode.isNull() && !arrNode.isMissingNode());
        List<String> urls = new ArrayList<String>();
        context.getVerificationDataTable().put("documents" + processId, urls);
        if (arrNode.isArray()) {
            for (JsonNode element : arrNode) {
                JsonNode attrValue = element.get("url");
                assertTrue(!attrValue.isNull() && !attrValue.isMissingNode());
                if (!element.get("generationStrategy").textValue().equalsIgnoreCase("STATIC")) {
                    String filePath = attrValue.textValue();
                    assertTrue(fileExist(filePath));
                    List<String> listOfPath = (List<String>) context.getVerificationDataTable().get("documents" + processId);
                    listOfPath.add(filePath);
                }
            }
        }
    }

    private boolean fileExist(String filePathString) {
        File f = new File(filePathString);
        return (f.exists() && !f.isDirectory());
    }

    @And("^associated document files in file system are deleted$")
    public void verifyDocumentFilesAreDeleted(Map<String, String> mapData) throws Exception {
        String processId = mapData.get("processId");
        List<String> listOfPath = (List<String>) context.getVerificationDataTable().get("documents" + processId);
        for (int i = 0; i < listOfPath.size(); i++) {
            String filePathStr = listOfPath.get(i);
            assertTrue(filePathStr + "are not deleted", !fileExist(filePathStr));
        }
    }

    @And("^associated document files in file system are not deleted$")
    public void verifyDocumentFilesAreNotDeleted(Map<String, String> mapData) throws Exception {
        String processId = mapData.get("processId");
        List<String> listOfPath = (List<String>) context.getVerificationDataTable().get("documents" + processId);
        for (int i = 0; i < listOfPath.size(); i++) {
            String filePathStr = listOfPath.get(i);
            assertTrue(filePathStr + "are deleted", fileExist(filePathStr));
        }
    }
}