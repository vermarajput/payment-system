package com.gbst.digital.documents.utils;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;

/**
 * @author rekhar on 2/11/2017
 */
public class ExtractPDFText {

    private static final Logger LOG = LoggerFactory.getLogger(ExtractPDFText.class);

    public String extractPDFText(File file) {
        try {
            PDDocument doc = PDDocument.load(file);
            String text = new PDFTextStripper().getText(doc);
            return text;
        } catch (IOException e) {
            LOG.error("Error in retrieving PDF as string", e);
        }
        return null;
    }
}
