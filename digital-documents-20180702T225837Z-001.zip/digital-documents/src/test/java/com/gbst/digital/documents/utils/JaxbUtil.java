package com.gbst.digital.documents.utils;

import com.infocomp.cbis.uk.response.Fund;
import com.infocomp.cbis.uk.response.IllustrationResponseType;
import com.infocomp.cbis.uk.response.ObjectFactory;
import com.infocomp.cbis.uk.response.Product;
import com.infocomp.cbis.uk.response.ProductDetailsType;
import com.infocomp.cbis.uk.response.ResponseDetailType;
import com.infocomp.cbis.uk.response.SubFund;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.xml.transform.StringResult;

import javax.xml.bind.JAXBElement;
import java.io.IOException;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 20/10/2017
 */
public class JaxbUtil {
    private static ObjectFactory objectFactory = new ObjectFactory();

    public static void main(String[] args) throws Exception {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPaths("com.infocomp.cbis.common.request","com.infocomp.cbis.common.response",
                "com.infocomp.cbis.uk.request","com.infocomp.cbis.uk.response");
        marshaller.afterPropertiesSet();
        StringResult result = new StringResult();

        //Object obj = createProductDetailsResponse();
        Object obj = createIllustrationRequest();

        marshaller.marshal(obj, result);
        System.out.println(result.toString());


    }

    private static JAXBElement<ProductDetailsType> createProductDetailsResponse() throws Exception {
        ProductDetailsType productDetailsType = objectFactory.createProductDetailsType();
        productDetailsType.setFunds(objectFactory.createProductDetailsTypeFunds());
        Fund fund = objectFactory.createFund();
        fund.setSubfunds(objectFactory.createFundSubfunds());
        SubFund subfund = new SubFund();
        subfund.setSubFundId(1);
        subfund.setSubFundName("SubFundName 1");
        subfund.setSubFundShortCode("SF_ONE");
        subfund.setProducts(objectFactory.createSubFundProducts());
        fund.getSubfunds().getSubfund().add(subfund);
        productDetailsType.getFunds().getFund().add(fund);

        Product p100 = new Product();
        p100.setProductFlag("A");
        p100.setProductTypeId(100);
        subfund.getProducts().getProduct().add(p100);

        Product p105 = new Product();
        p105.setProductFlag("P");
        p105.setProductTypeId(105);
        subfund.getProducts().getProduct().add(p105);

        Product p103 = new Product();
        p103.setProductFlag("X");
        p103.setProductTypeId(103);
        subfund.getProducts().getProduct().add(p103);

        return objectFactory.createProductDetails(productDetailsType);

    }
    private static JAXBElement<IllustrationResponseType> createIllustrationRequest() throws IOException {
        IllustrationResponseType response = objectFactory.createIllustrationResponseType();
        response.setResponseDetails(objectFactory.createIllustrationResponseTypeResponseDetails());
        ResponseDetailType responseDetails = objectFactory.createResponseDetailType();
        responseDetails.setIllustrationId(1);
        responseDetails.setIllustrationPdfStream(objectFactory.createResponseDetailTypeIllustrationPdfStream());

        responseDetails.getIllustrationPdfStream().setFile(null);
        response.getResponseDetails().getResponseDetail().add(responseDetails);

        return objectFactory.createIllustrationResponse(response);
    }
}
