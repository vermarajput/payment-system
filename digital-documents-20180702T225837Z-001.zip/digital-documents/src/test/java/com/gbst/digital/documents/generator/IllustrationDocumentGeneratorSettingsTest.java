package com.gbst.digital.documents.generator;

import com.gbst.digital.documents.generator.json.cie.FieldConfigEnum;
import com.gbst.digital.documents.generator.json.cie.IllustrationDocumentGeneratorSettings;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by Aman Verma on 2/03/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class IllustrationDocumentGeneratorSettingsTest {
    @InjectMocks
    private IllustrationDocumentGeneratorSettings illustrationDocumentGeneratorSettings;

    @Before
    public void setUp() throws Exception {
        Map<String, FieldConfigEnum> fields = new HashMap<String, FieldConfigEnum>() {{
            put("includedField", FieldConfigEnum.On);
            put("excludedField", FieldConfigEnum.Off);
        }};
        illustrationDocumentGeneratorSettings.setFields(fields);
    }

    @Test
    public void test_isFieldIncluded() throws Exception {
        assertTrue(illustrationDocumentGeneratorSettings.isFieldIncluded("includedField"));
        assertFalse(illustrationDocumentGeneratorSettings.isFieldIncluded("excludedField"));
        assertTrue(illustrationDocumentGeneratorSettings.isFieldIncluded("fieldWithNoEntry"));
    }
}