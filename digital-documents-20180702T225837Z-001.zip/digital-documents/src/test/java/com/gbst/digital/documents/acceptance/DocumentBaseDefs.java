package com.gbst.digital.documents.acceptance;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gbst.common.acceptance.BaseDefs;
import com.gbst.digital.documents.DocumentsApplication;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

import javax.annotation.PostConstruct;
import java.net.URL;

@SpringBootTest(classes = DocumentsApplication.class, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT,
        properties = {
                "spring.profiles.active=cucumber-test"
        }
)

@ContextConfiguration()
@TestPropertySource("/application-cucumber-test.properties")
public class DocumentBaseDefs extends BaseDefs {
    static Logger logger = LoggerFactory.getLogger(DocumentBaseDefs.class);
    
    static int serverPort = 8080;
    static String serverHost = "localhost";
    String apiUrl = "http://" + serverHost + ":" + serverPort + "/api";
    String fileUrl = "http://" + serverHost + ":" + serverPort + "/files";
    String apiUrlSwagger = "http://" + serverHost + ":" + serverPort;
    String apiUrlHealth = "http://" + serverHost + ":" + serverPort;
    String cbisUrl = "http://localhost:13579/mockserver";

    static JsonSchema schmemaNode;
    static final String JSON_V4_SCHEMA_IDENTIFIER = "http://json-schema.org/draft-04/schema#";
    static final String JSON_SCHEMA_IDENTIFIER_ELEMENT = "$schema";

    @PostConstruct
    public void setTestServerUrl(){
        setTestServerUrl("http://" + serverHost + ":" + serverPort);
    }

    @PostConstruct
    private void setJsonSchema() throws Throwable {
        schmemaNode = getSchemaNode();
    }

    public void validateResJsonAgainstSchema() throws Throwable {
        ProcessingReport report = schmemaNode.validate(context.getLatestResponseJson());
        Assert.assertTrue("Latest Response does not conform to schema", report.isSuccess());
    }

    private JsonSchema getSchemaNode() throws Throwable {
        JsonNode jsonNode = JsonLoader.fromURL(new URL(apiUrlSwagger + "/api-docs/swagger.json"));

        final JsonNode schemaIdentifier = jsonNode.get(JSON_SCHEMA_IDENTIFIER_ELEMENT);
        if (null == schemaIdentifier) {
            ((ObjectNode) jsonNode).put(JSON_SCHEMA_IDENTIFIER_ELEMENT, JSON_V4_SCHEMA_IDENTIFIER);
        }

        final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
        return factory.getJsonSchema(jsonNode);
    }
}
