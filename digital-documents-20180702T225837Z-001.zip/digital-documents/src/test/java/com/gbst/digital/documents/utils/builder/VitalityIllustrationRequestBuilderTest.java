package com.gbst.digital.documents.utils.builder;

import com.gbst.digital.documents.resource.model.document.CustomField;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.utils.ProcessType;
import com.gbst.digital.services.composer.ProductTypes;
import com.infocomp.cbis.uk.request.AdditionalClientDataType;
import com.infocomp.cbis.uk.request.IllustrationPayloadType;
import com.infocomp.cbis.uk.request.ObjectFactory;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import com.infocomp.cbis.uk.response.Product;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.AccumulationIllustration;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.Default;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.DrawdownIllustration;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by Aman Verma on 13/03/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class VitalityIllustrationRequestBuilderTest {
    @InjectMocks
    private VitalityIllustrationRequestBuilder vitalityIllustrationRequestBuilder;

    @Mock
    private RequestIllustrationType req;
    @Mock
    private IllustrationPayloadType illustrationPayload;
    @Mock
    private AdditionalClientDataType additionalClientData;
    @Mock
    private AdditionalClientDataType.QualifyingOpeningBalances qualifyingOpeningBalances;
    @Mock
    private ObjectFactory requestObjectFactory;

    @Before
    public void setup() {
        when(req.getIllustrationPayload()).thenReturn(illustrationPayload);
        when(illustrationPayload.getAdditionalClientData()).thenReturn(additionalClientData);
        when(requestObjectFactory.createAdditionalClientDataTypeQualifyingOpeningBalances()).thenReturn(qualifyingOpeningBalances);

        doNothing().when(additionalClientData).setAccumulationBoostVersionId(any());
        doNothing().when(additionalClientData).setIncomeBoostVersionId(any());
        doNothing().when(additionalClientData).setHealthStatus(any());
        doNothing().when(additionalClientData).setQualifyingOpeningBalances(any());
    }

    @Test
    public void testEnrichRequest_VerifyHealthStatus_QualifyingOpeningBalances() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        Product pNB_Acc = new Product();
        pNB_Acc.setProductFlag("A");
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(pNB_Acc), ProcessType.NEW_BUSINESS, Default, false);

        verify(additionalClientData, atLeastOnce()).setHealthStatus("Good");
        verify(additionalClientData, atLeastOnce()).setQualifyingOpeningBalances(qualifyingOpeningBalances);
    }

    @Test
    public void testEnrichRequest_VerifyAccumulationBootBersionId_NewBusiness() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        Product pNB_Acc = new Product();
        pNB_Acc.setProductFlag("A");
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(pNB_Acc), ProcessType.NEW_BUSINESS, Default, false);

        verify(additionalClientData, atLeastOnce()).setAccumulationBoostVersionId(BigDecimal.valueOf(110));
    }

    @Test
    public void testEnrichRequest_VerifyAccumulationBootVersionId_PartialDrawdown_Accumulation() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(new Product()), ProcessType.DRAWDOWN, AccumulationIllustration, false);
        verify(additionalClientData, atLeastOnce()).setAccumulationBoostVersionId(BigDecimal.valueOf(110));
    }

    @Test
    public void testEnrichRequest_VerifyAccumulationBootBersionId_Drawdown_Crystallise() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(new Product()), ProcessType.DRAWDOWN, DrawdownIllustration, false);
        verify(additionalClientData, atMost(0)).setAccumulationBoostVersionId(BigDecimal.valueOf(110));
    }

    @Test
    public void testEnrichRequest_VerifyIncomeBoostVersionId_Drawdown_Crystallise() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(new Product()), ProcessType.DRAWDOWN, DrawdownIllustration, false);
        verify(additionalClientData, atLeastOnce()).setIncomeBoostVersionId(BigDecimal.valueOf(111));
    }

    @Test
    public void testEnrichRequest_VerifyIncomeBoostVersionId_NewBusiness_Accumulation() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        Product pNB_Acc = new Product();
        pNB_Acc.setProductFlag("A");
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(pNB_Acc), ProcessType.NEW_BUSINESS, Default, false);

        verify(additionalClientData, atMost(0)).setIncomeBoostVersionId(BigDecimal.valueOf(111));
    }

    @Test
    public void testEnrichRequest_VerifyIncomeBoostVersionId_NewBusiness() throws Exception {
        DocumentAttributes doc = getDocumentAttributesWithCustomFields();
        Product pNB_Acc = new Product();
        pNB_Acc.setProductFlag("P");
        vitalityIllustrationRequestBuilder.enrichRequest(req, doc, new ProductTypes.ProductType(pNB_Acc), ProcessType.NEW_BUSINESS, Default, false);

        verify(additionalClientData, atLeastOnce()).setIncomeBoostVersionId(BigDecimal.valueOf(111));
    }

    private DocumentAttributes getDocumentAttributesWithCustomFields() {
        DocumentAttributes doc = new DocumentAttributes();
         doc.setApplyBoostFlag(true);
        List<CustomField> customFields = new ArrayList<>();
        CustomField accumulationBoostVersionId =  new CustomField();
        accumulationBoostVersionId.setKey("accumulationBoostVersionId");
        accumulationBoostVersionId.setValue("110");

        CustomField incomeBoostVersionId =  new CustomField();
        incomeBoostVersionId.setKey("incomeBoostVersionId");
        incomeBoostVersionId.setValue("111");


        CustomField healthStatus =  new CustomField();
        healthStatus.setKey("HEALTH_STATUS");
        healthStatus.setValue("Good");

        customFields.add(accumulationBoostVersionId);
        customFields.add(incomeBoostVersionId);
        customFields.add(healthStatus);

        doc.setCustomFields(customFields);
        return doc;
    }

}