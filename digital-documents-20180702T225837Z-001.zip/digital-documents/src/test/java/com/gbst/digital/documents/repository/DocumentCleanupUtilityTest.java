package com.gbst.digital.documents.repository;

import com.gbst.common.swagger.JsonApiValidationException;
import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DocumentCleanupUtilityTest {

    @Mock
    private DownloadAndCleanupDelegator downloadAndCleanupDelegator;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private RepositoryUtil repositoryUtil;

    @InjectMocks
    private DocumentCleanupUtility documentCleanupUtility;


    @Test(expected = JsonApiValidationException.class)
    public void testHandleMultiplePreExistingRecords() throws DocumentStorageException {
        when(repositoryUtil.getDocumentGenerationQueryParams(any())).thenReturn(new HashMap<>());
        Query mock_query = Mockito.mock(Query.class);
        when(repositoryUtil.getQuery(any())).thenReturn(mock_query);
        when(mongoTemplate.find(mock_query, DocumentGeneration.class)).thenReturn(getDocGenObjMultipleObjects());
        documentCleanupUtility.handlePreviousGenerationRequestsData(getDocumentGeneration());
    }

    @Test
    public void testHandleSinglePreExistingRecords() throws DocumentStorageException {
        when(repositoryUtil.getDocumentGenerationQueryParams(any())).thenReturn(new HashMap<>());
        Query mock_query = Mockito.mock(Query.class);
        when(repositoryUtil.getQuery(any())).thenReturn(mock_query);
        when(mongoTemplate.find(mock_query, DocumentGeneration.class)).thenReturn(getDocGenObjOneObject());
        documentCleanupUtility.handlePreviousGenerationRequestsData(getDocumentGeneration());
    }


    private List<DocumentGeneration> getDocGenObjOneObject() {
        List<DocumentGeneration> documentGenerationList = new ArrayList<>();
        DocumentGeneration obj = getDocumentGeneration();
        documentGenerationList.add(obj);
        return documentGenerationList;
    }

    public List<DocumentGeneration> getDocGenObjMultipleObjects() {
        List<DocumentGeneration> documentGenerationList = new ArrayList<>();
        DocumentGeneration obj = getDocumentGeneration();
        DocumentGeneration obj2 = getDocumentGeneration();
        documentGenerationList.add(obj);
        documentGenerationList.add(obj2);
        return documentGenerationList;
    }

    private DocumentGeneration getDocumentGeneration() {
        DocumentGeneration obj = new DocumentGeneration();
        obj.setOwner("neha");
        obj.setProcessType("NEW_BUSINESS");
        obj.setProcessTypeId("17");
        obj.setProcessStage("post-submission");
        obj.setRole("Advisor");
        obj.setProcessId("1122");
        DocumentForGeneration response = new DocumentForGeneration();
        response.setTemplateFileName("templatexxx.doc");
        response.setOutputType(OutputTypeEnum.PDF);
        response.setUrl("http://fsfsf.com");
        response.setDocumentName("one");
        response.setGeneratedDate(Instant.now());
        response.setStorageSystem("FILESYSTEM");
        response.setGenerationStrategy(GenerationStrategyEnum.WINDWARD.getValue());
        response.setGenerationStatus(GenerationStatusEnum.GENERATED);
        List<DocumentForGeneration> responseList = new ArrayList<>();
        responseList.add(response);
        obj.setDocuments(responseList);
        return obj;
    }

}
