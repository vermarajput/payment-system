package com.gbst.digital.documents.generator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gbst.common.connconfig.MultiUrlConnectionSettings;
import com.gbst.digital.Services;
import com.gbst.digital.documents.generator.json.cie.IllustrationDocumentGenerator;
import com.gbst.digital.documents.resource.model.DocumentForGeneration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.DocumentWithParameter;
import com.gbst.digital.documents.resource.model.PayloadFormatEnum;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.types.DocumentTypeEnum;
import com.gbst.digital.documents.resource.model.types.GenerationStrategyEnum;
import com.gbst.digital.documents.resource.model.types.OutputTypeEnum;
import com.gbst.digital.documents.utils.IllustrationRequestBuilder;
import com.gbst.digital.documents.utils.IllustrationSelectorEnum;
import com.gbst.digital.documents.utils.ProcessType;
import com.infocomp.cbis.uk.request.RequestIllustrationType;
import com.infocomp.cbis.uk.response.IllustrationCIEResponse;
import com.infocomp.cbis.uk.response.IllustrationResponseType;
import com.infocomp.cbis.uk.response.ResponseDetailType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.ws.client.core.WebServiceTemplate;

import javax.activation.DataHandler;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;

import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.AccumulationIllustration;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.Default;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.DrawdownIllustration;
import static com.gbst.digital.documents.utils.IllustrationSelectorEnum.DrawdownIllustration;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Mohammad Norouzi
 * @since v1.0.x 17/10/2017
 */
@RunWith(MockitoJUnitRunner.class)
public class IllustrationDocumentGeneratorTest {

    @Mock
    WebServiceTemplate webServiceTemplate;

    @Spy
    MultiUrlConnectionSettings multiUrlConnectionSettings;

    @Mock
    IllustrationRequestBuilder illustrationRequestBuilder;

    @Mock
    DataHandler dataHandler;

    @Mock
    ObjectMapper mapper;


    @InjectMocks
    IllustrationDocumentGenerator illustrationDocumentGenerator;

    @Before
    public void setup() {
        multiUrlConnectionSettings.setConnections(new HashMap<>());
        multiUrlConnectionSettings.getConnections().put(Services.CBIS, new MultiUrlConnectionSettings.Conn());
        multiUrlConnectionSettings.getConnections().get(Services.CBIS).setUrl("url");
        when(illustrationRequestBuilder.getDocumentTypesRequired(any(), any())).thenReturn(new IllustrationSelectorEnum[] {Default});
    }

    @Test
    public void generateDocument() throws Exception {
        DocumentForGeneration doc = new DocumentForGeneration();
        doc.setOutputType(OutputTypeEnum.PDF);
        DocumentGeneration req = new DocumentGeneration();
        req.setProcessTypeId("12");
        req.setProcessType("NEW_BUSINESS");
        DocumentAttributes attr = new DocumentAttributes();

        req.setDocumentAttributes("");
        RequestIllustrationType ill = new RequestIllustrationType();
        DocumentGeneration documentWithParameterRequest = new DocumentGeneration();
        documentWithParameterRequest.setProcessType("NEW_BUSINESS");
        when(illustrationRequestBuilder.buildRequestIllustrationType(attr, ProcessType.NEW_BUSINESS, Default)).thenReturn(ill);
        JAXBElement<RequestIllustrationType> jaxbReq = new JAXBElement<RequestIllustrationType>(new QName("something"), RequestIllustrationType.class, ill);
        when(illustrationRequestBuilder.createRequestIllustration(ill)).thenReturn(jaxbReq);

        DocumentPayload payload = new DocumentPayload(PayloadFormatEnum.PlainText, "paylaod", "payload");
        payload.setDocumentForConfig(doc);

        when(mapper.readValue(payload.getSource(), DocumentAttributes.class)).thenReturn(attr);

        IllustrationResponseType res = new IllustrationResponseType();
        res.setIllustrationCIEResponse(new IllustrationCIEResponse());
        res.setResponseDetails(new IllustrationResponseType.ResponseDetails());
        ResponseDetailType details = new ResponseDetailType();
        details.setIllustrationPdfStream(new ResponseDetailType.IllustrationPdfStream());
        details.getIllustrationPdfStream().setFile(dataHandler);
        res.getResponseDetails().getResponseDetail().add(details);
        OutputStream sos = new ByteArrayOutputStream();
        sos.write("something".getBytes());

        Mockito.doAnswer(new Answer<Void>() {
            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                if (invocation.getMethod().getName().contains("writeTo")) {
                    OutputStream sos = (OutputStream) invocation.getArguments()[0];
                    sos.write("something".getBytes());
                }
                return null;
            }
        }).when(dataHandler).writeTo(Mockito.any(OutputStream.class));

        JAXBElement<IllustrationResponseType> jaxbRes = new JAXBElement<IllustrationResponseType>(new QName("something"), IllustrationResponseType.class, res);
        when(webServiceTemplate.marshalSendAndReceive("url", jaxbReq)).thenReturn(jaxbRes);
        List<DocumentWithParameter> result = illustrationDocumentGenerator.generate(documentWithParameterRequest, payload);

        assertTrue("No documents generated.", result.size() > 0);
        assertEquals(OutputTypeEnum.PDF, result.get(0).getDocument().getOutputType());
        assertEquals(sos.toString(), result.get(0).getGeneratedDocumentStream().toString());
    }

    @Test
    //TODO Add test cases for Full Partial Accu DD
    public void generateDocument_PartialDrawdown() throws Exception {
        DocumentForGeneration doc = new DocumentForGeneration();
        doc.setOutputType(OutputTypeEnum.PDF);
        DocumentGeneration req = new DocumentGeneration();
        req.setProcessTypeId("12");
        req.setProcessType("DRAWDOWN");
        DocumentAttributes attr = new DocumentAttributes();
        req.setDocumentAttributes("");
        RequestIllustrationType illDD = new RequestIllustrationType();
        RequestIllustrationType illAccu = new RequestIllustrationType();
        DocumentGeneration documentWithParameterRequest = new DocumentGeneration();
        documentWithParameterRequest.setProcessType("DRAWDOWN");
        when(illustrationRequestBuilder.getDocumentTypesRequired(any(), any())).thenReturn(new IllustrationSelectorEnum[] {DrawdownIllustration, AccumulationIllustration});
        when(illustrationRequestBuilder.buildRequestIllustrationType(attr, ProcessType.DRAWDOWN, DrawdownIllustration)).thenReturn(illDD);
        when(illustrationRequestBuilder.buildRequestIllustrationType(attr, ProcessType.DRAWDOWN, AccumulationIllustration)).thenReturn(illAccu);
        JAXBElement<RequestIllustrationType> jaxbReqDD = new JAXBElement<>(new QName("something"), RequestIllustrationType.class, illDD);
        JAXBElement<RequestIllustrationType> jaxbReqAccu = new JAXBElement<>(new QName("somethingAccu"), RequestIllustrationType.class, illAccu);
        when(illustrationRequestBuilder.createRequestIllustration(illDD)).thenReturn(jaxbReqDD);
        when(illustrationRequestBuilder.createRequestIllustration(illAccu)).thenReturn(jaxbReqAccu);

        IllustrationResponseType res = new IllustrationResponseType();
        res.setIllustrationCIEResponse(new IllustrationCIEResponse());
        res.setResponseDetails(new IllustrationResponseType.ResponseDetails());
        ResponseDetailType details = new ResponseDetailType();
        details.setIllustrationPdfStream(new ResponseDetailType.IllustrationPdfStream());
        details.getIllustrationPdfStream().setFile(dataHandler);
        res.getResponseDetails().getResponseDetail().add(details);
        OutputStream sos = new ByteArrayOutputStream();
        sos.write("something".getBytes());

        DocumentPayload payload = new DocumentPayload(PayloadFormatEnum.PlainText, "paylaod", "payload");
        payload.setDocumentForConfig(doc);

        when(mapper.readValue(payload.getSource(), DocumentAttributes.class)).thenReturn(attr);

        Mockito.doAnswer(new Answer<Void>() {
            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                if (invocation.getMethod().getName().contains("writeTo")) {
                    OutputStream sos = (OutputStream) invocation.getArguments()[0];
                    sos.write("something".getBytes());
                }
                return null;
            }
        }).when(dataHandler).writeTo(Mockito.any(OutputStream.class));

        JAXBElement<IllustrationResponseType> jaxbRes = new JAXBElement<IllustrationResponseType>(new QName("something"), IllustrationResponseType.class, res);
        when(webServiceTemplate.marshalSendAndReceive("url", jaxbReqDD)).thenReturn(jaxbRes);
        List<DocumentWithParameter> result = illustrationDocumentGenerator.generate(documentWithParameterRequest, payload);

        assertTrue("No documents generated.", result.size() > 0);
        assertEquals(OutputTypeEnum.PDF, result.get(0).getDocument().getOutputType());
        assertEquals(sos.toString(), result.get(0).getGeneratedDocumentStream().toString());
    }

    @Test
    public void testSupportsGenerationType() throws Exception {
        DocumentForGeneration doc = new DocumentForGeneration();
        doc.setOutputType(OutputTypeEnum.PDF);
        doc.setGenerationStrategy(GenerationStrategyEnum.ILLUSTRATION.getValue());
        doc.setDocumentName(DocumentTypeEnum.PRE_SALE_ILLUSTRATION.name());

        DocumentPayload payload = new DocumentPayload(PayloadFormatEnum.JSON, "paylaod", "payload");
        payload.setDocumentForConfig(doc);

        DocumentGeneration documentWithParameterRequest = new DocumentGeneration();
        documentWithParameterRequest.setProcessType("DRAWDOWN");

        assertTrue(illustrationDocumentGenerator.supports(documentWithParameterRequest, payload));
    }

}