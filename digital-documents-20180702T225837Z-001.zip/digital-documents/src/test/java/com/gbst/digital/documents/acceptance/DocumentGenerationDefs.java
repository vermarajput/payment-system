package com.gbst.digital.documents.acceptance;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gbst.common.acceptance.DownloadResponseResults;
import com.gbst.common.acceptance.security.CucumberAuthServerHelper;
import com.gbst.common.utils.GbstDateUtils;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.gbst.digital.documents.resource.model.document.DocumentAttributes;
import com.gbst.digital.documents.resource.model.document.SippTransferIn;
import com.gbst.digital.documents.utils.ExtractPDFText;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.json.JSONObject;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpMethod;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.Assert.assertTrue;

public class DocumentGenerationDefs extends DocumentBaseDefs {
    private static final String REGEX_SERVICE_NAME = "([\\w\\-]+)";
    private static final String DOC_CONFIG_SERVICE_NAME = "document-configurations";
    private static String TOKEN_TEMPLATE = "{\"access_token\":\"__XX_TOKEN__\",\"token_type\":\"bearer\",\"expires_in\":7199,\"scope\":\"auth_perms\",\"iss\":\"http://www.gbst.com/oauth2-authorisation\",\"sub\":\"auth\",\"jti\":\"7c5d677a-2be3-408f-b52e-ef877a88dcc2\"}";
    private HashMap<String, String> valueStore = new HashMap<>();

    private ExtractPDFText extractPDFText = new ExtractPDFText();
    protected CucumberAuthServerHelper cucumberAuthServerHelper = CucumberAuthServerHelper.getInstance();

    @Autowired
    ObjectMapper mapper;

    @And("^mock server is available")
    public void mockServerIsAvailable() throws Throwable {
        if(CucumberTest.wireMockServer != null && CucumberTest.wireMockServer.isRunning()) {
            //Avoid running again
            return;
        }
        CucumberTest.wireMockServer.start();

        configureFor("localhost", 13579, "mockserver");

        //GetProductDetails request
        stubFor(post(urlEqualTo("/mockserver"))
                .withHeader("Content-Type", containing("xml"))
                .withRequestBody(containing("GetProductDetails"))
                .willReturn(aResponse().withBodyFile("/mock-responses/GetProductDetails.xml").withStatus(200)));

        //RequestIllustration request
        stubFor(post(urlEqualTo("/mockserver"))
                .withHeader("Content-Type", containing("xml"))
                .withRequestBody(containing("RequestIllustration"))
                .willReturn(aResponse().withBodyFile("/mock-responses/successful-illustration-pdf-response.xml").withStatus(200)));

        //<ns5:partyTypeId>3</ns5:partyTypeId><ns5:partyId>4</ns5:partyId><ns5:searchPartyTypeId>3</ns5:searchPartyTypeId>
        stubFor(post(urlEqualTo("/mockserver"))
                .withHeader("Content-Type", containing("xml"))
                .withRequestBody(containing("GetAssociatedPartyList"))
                .withRequestBody(containing("<ns5:partyTypeId>3</ns5:partyTypeId>"))
                .willReturn(aResponse().withBodyFile("/mock-responses/AssociatedPartyListType.xml").withStatus(200)));

        stubFor(post(urlEqualTo("/mockserver/oauth/token"))
                .willReturn(aResponse().withBody(TOKEN_TEMPLATE.replace("__XX_TOKEN__", cucumberAuthServerHelper.createClientCredentialAccessToken("digital_doc").getValue()))
                        .withStatus(200)
                .withHeader("Content-Type", "application/vnd.api+json;charset=UTF-8")));

        stubFor(get(urlEqualTo("/mockserver/product-web-enabled"))
                .willReturn(aResponse().withBodyFile("/mock-responses/AllWebProductTypes.json")
                        .withHeader("Content-Type", "application/vnd.api+json;charset=UTF-8")
                        .withStatus(200)));

    }

    @Autowired
    MongoTemplate mongoTemplate;

    @Given("^there is no document configuration in the system$")
    public void thereIsNoDocumentConfigurationInTheSystem() {
        mongoTemplate.dropCollection(DocumentConfiguration.class);
    }

    @Given("^there is no document generation data in the system$")
    public void thereIsNoDocumentGenerationDataInTheSystem() {
        mongoTemplate.dropCollection(DocumentGeneration.class);
    }

    @When("^send a GET request to document-download service to retrieve the document just generated$")
    public void retrieveTheDocumentJustGenerated() throws Throwable {
        String documentKey = extractDocumentKeyFromResponse();
        String url = fileUrl + "/document-download/" + documentKey;
        logger.info("GET [{}]", url);
        executeGetDownload(url, "application/vnd.api+json");
    }

    private void theDocumentGeneratedContainsTheDocumentAttributes(File file, String documentAttributesRequest) throws Throwable {
        DocumentAttributes documentAttributes = mapper.readValue(documentAttributesRequest, DocumentAttributes.class);
        String pdfText = extractPDFText.extractPDFText(file).replace("\n", "").replace("\r", "");

        assertTrue(pdfText != null);
        assertTrue(pdfText.contains(documentAttributes.getInvestorFirstName()));
        assertTrue(pdfText.contains(documentAttributes.getInvestorLastName()));
        for (SippTransferIn transferIn : documentAttributes.getSippTransferIns()) {
            assertTrue(pdfText.contains(transferIn.getTransferType().getValue()));
            assertTrue(pdfText.contains(transferIn.getAmount().toString()));
            if (null != transferIn.getInitialChargeAmount()) {
                assertTrue(pdfText.contains(transferIn.getInitialChargeAmount().toString()));
            }
        }
    }

    private String extractDocumentKeyFromResponse() {
        JsonNode docKeyNode = context.getLatestResponseJson().at("/data/attributes/documents/0/documentKey");
        assertTrue(!docKeyNode.isNull() && !docKeyNode.isMissingNode());
        if (docKeyNode.isTextual()) {
            return docKeyNode.textValue();
        } else {
            return docKeyNode.toString();
        }
    }

    @And("^response data contains the last POST response$")
    public void responseDataContainsTheLastPOSTResponse() throws Throwable {
        checkJSONStrHasData(context.getLatestResponse().getBody());
        JSONObject firstItemInArray = new JSONObject(context.getLatestResponse().getBody()).getJSONArray("data").getJSONObject(0);
        JSONObject requestLastPost = new JSONObject(context.getLatestPostPatchRequestBody()).getJSONObject("data");
        compareJSONObject(requestLastPost, firstItemInArray);
    }

    @And("^file downloaded contains related fields in (\"[^\"]*\"|[^\"]+)$")
    public void fileDownloadedContainsRelatedFields(String documentAttributes) throws Throwable {
        if (context.getLatestResponse().getHeaders() != null) {
            assertTrue(context.getLatestResponse().getHeaders().getContentLength() > 0);
            assertTrue(null != ((DownloadResponseResults) context.getLatestResponse()).getFilePath());
            File downloadedFile = new File(((DownloadResponseResults) context.getLatestResponse()).getFilePath());
            theDocumentGeneratedContainsTheDocumentAttributes(downloadedFile, getStringValueRetainNoInputSymbol(documentAttributes));
        }
    }

    @And("^delete all temporary downloaded file$")
    public void deleteAllTemporaryDownloadedFile() throws Throwable {
        File destinationDir = new File(System.getProperty("java.io.tmpdir") + "/digital-doc-test");
        if (destinationDir.exists()) {
            //if directory, go inside and call all files to delete
            for (File f : destinationDir.listFiles()) {
                f.delete();
            }
        } else {
            destinationDir.mkdir();
        }
    }

    @When("^send several POST requests to " + REGEX_SERVICE_NAME + " service and verify in response data (\"[^\"]*\"|[^\"]+) inside (\"[^\"]*\"|[^\"]+) list are unique$")
    public void sendSeveralPOSTRequestsAndVerifyAttributeValueIsUnique(String serviceName, String attributeName, String listAttributeName, List<Map<String, String>> tableData) throws Throwable {
        String url = apiUrl + "/" + serviceName;
        String requestBody;
        for (Map<String, String> item : tableData) {
            requestBody = generateRequestBody(item, serviceName, "");
            logger.info("POST [{}]", url, requestBody);
            executePostAndStoreRequest(url, requestBody);

            verifyAttributeValueIsUnique(listAttributeName, attributeName);
        }
    }

    @When("^send the same POST requests to " + REGEX_SERVICE_NAME + " service for (\\d+) times then verify in response data (\"[^\"]*\"|[^\"]+) inside (\"[^\"]*\"|[^\"]+) list are unique and document can be download$")
    public void sendSamePOSTRequestsNTimesAndVerifyAttributeValueIsUniqueAndDownload(String serviceName, int count, String attributeName, String listAttributeName, Map<String, String> tableData) throws Throwable {
        String url = apiUrl + "/" + serviceName;
        String requestBody = generateRequestBody(tableData, serviceName, "");
        for (int i = 0; i < count; i++) {
            executePostAndStoreRequest(apiUrl + "/" + serviceName, requestBody);
            verifyAttributeValueIsUnique(listAttributeName, attributeName);

            retrieveTheDocumentJustGenerated();
            Assert.assertEquals(httpStatusMap.get("Success"), context.getLatestStatusCode());

        }
    }

    @When("^send a GET request to (\"[^\"]*\"|[^\"]+) service to retrieve all the resources just generated and verify response code is (\"[^\"]*\"|[^\"]+)$")
    public void sendAGETRequestToDocumentDownloadServiceToRetrieveAllTheDocumentJustGenerated(String serviceName, String responseCode) throws Throwable {
        for (String key : valueStore.keySet()) {
            String url = fileUrl + "/" + serviceName + "/" + key;
            logger.info("GET [{}]", url);
            executeGetDownload(url, "application/vnd.api+json");

            String detailedInfo = "Actual response code is " + context.getLatestStatusCode() + "\n"
                    + "resource id is " + key + "\n";
            Assert.assertEquals(detailedInfo, httpStatusMap.get(responseCode), context.getLatestStatusCode());
        }
    }

    @And("^in response data, (\"[^\"]*\"|[^\"]+) in (\"[^\"]*\"|[^\"]+) list is between current time -(\\d+)s and current time$")
    public void verifyDateTimeBetween(String attributeName, String listAttributeName, int minusCount) throws Throwable {
        String detailedInfo = generateDebugInfo();
        JsonNode arrNode = context.getLatestResponseJson().at("/data/attributes/" + listAttributeName);
        assertTrue(detailedInfo, !arrNode.isNull() && !arrNode.isMissingNode());
        if (arrNode.isArray()) {
            for (JsonNode element : arrNode) {
                JsonNode attrValue = element.get(attributeName);
                assertTrue(detailedInfo, !attrValue.isNull() && !attrValue.isMissingNode());
                verifyTimeBetweenNowMinusNSecAndNow(attrValue.textValue(), minusCount);
            }
        }
    }

    @When("^send the same POST requests to " + REGEX_SERVICE_NAME + " service for (\\d+) times as below$")
    public void sendSamePOSTRequestsNTimesAndVerifyAttributeValueIsUnique(String serviceName, int count, Map<String, String> tableData) throws Throwable {
        String url = apiUrl + "/" + serviceName;
        String requestBody = generateRequestBody(tableData, serviceName, "");
        for (int i = 0; i < count; i++) {
            executePostAndStoreRequest(apiUrl + "/" + serviceName, requestBody);
            Assert.assertEquals(httpStatusMap.get("Created"), context.getLatestStatusCode());
        }
    }

    @And("^in response data, value of (\"[^\"]*\"|[^\"]+) in (\"[^\"]*\"|[^\"]+) list is (\"[^\"]*\"|[^\"]+)")
    public void verifyAttributeInsideListValue(String attributeName, String listAttributeName, String expectedValue) throws Throwable {
        String detailedInfo = generateDebugInfo();
        JsonNode attributes = context.getLatestResponseJson().at("/data/attributes");
        verifyAttributeValueInsideList(attributeName, listAttributeName, expectedValue, detailedInfo, attributes);
    }

    @And("^in response data filtered, value of (\"[^\"]*\"|[^\"]+) in (\"[^\"]*\"|[^\"]+) list is (\"[^\"]*\"|[^\"]+)")
    public void verifyFilterAttributeInsideListValue(String attributeName, String listAttributeName, String expectedValue) throws Throwable {
        String detailedInfo = generateDebugInfo();
        JsonNode dataArray = context.getLatestResponseJson().get("data");
        assertTrue(!dataArray.isNull() && !dataArray.isMissingNode());
        if (dataArray.isArray()) {
            for (JsonNode element : dataArray) {
                JsonNode attributes = element.get("attributes");
                verifyAttributeValueInsideList(attributeName, listAttributeName, expectedValue, detailedInfo, attributes);
            }
        }
    }

    private void verifyAttributeValueInsideList(String attributeName, String listAttributeName, String expectedValue, String detailedInfo, JsonNode attributes) {
        String debugInfo = generateDebugInfo();
        assertTrue(debugInfo, !attributes.isNull() && !attributes.isMissingNode());
        JsonNode arrNode = attributes.get(listAttributeName);
        assertTrue(!arrNode.isNull() && !arrNode.isMissingNode());
        if (arrNode.isArray()) {
            for (JsonNode element : arrNode) {
                JsonNode attrNode = element.get(attributeName);
                if (expectedValue.equalsIgnoreCase("not null")) {
                    debugInfo = attributeName + " is null\n" + debugInfo;
                    assertTrue(debugInfo, !attrNode.isNull() && !attrNode.isMissingNode());
                } else {
                    if (expectedValue.equalsIgnoreCase("null")) {
                        debugInfo = attributeName + " is not null\n" + debugInfo;
                        assertTrue(debugInfo, attrNode.isNull() || attrNode.isMissingNode());
                    } else {
                        assertTrue(debugInfo, !attrNode.isNull() && !attrNode.isMissingNode());
                        if (attrNode.isTextual()) {
                            assertTrue(debugInfo, expectedValue.equalsIgnoreCase(attrNode.textValue()));
                        } else {
                            assertTrue(debugInfo, expectedValue.equalsIgnoreCase(attrNode.toString()));
                        }
                    }
                }
            }
        }
    }

    //This's is for response data of GET ALL/FILTER, data Node is a Array
    @Then("^verify (\"[^\"]*\"|[^\"]+) in (\"[^\"]*\"|[^\"]+) list is unique in response data filtered$")
    public void verifyExternalIdInDocumentsListIsUnique(String attributeName, String listAttributeName) throws Throwable {
        JsonNode arrNode = context.getLatestResponseJson().get("data");
        if (arrNode.isArray()) {
            for (JsonNode element : arrNode) {
                JsonNode attributes = element.get("attributes");
                verifyAttributeInlistUnique(listAttributeName, attributeName, attributes);
            }
        }
    }

    @And("^send a PATCH request to (\"[^\"]*\"|[^\"]+) service to update the resource created in previous step$")
    public void sendPatchToLastResource(String serviceName, Map<String, String> modelValues) throws Throwable {
        String id = context.getLatestResponseId();
        executePatchAndStoreRequest(apiUrl + "/" + serviceName + "/" + id, generateRequestBody(modelValues, serviceName, "updated_", id));
    }

    @When("^delete latest created Document Configuration in previous step$")
    public void sendDeleteToDocumentConfigurationJustCreated() throws Throwable {
        context.getVerificationDataTable().put("documents-deletedResourceId", context.getLatestResponseId());
        executeRequest(apiUrl + "/" + DOC_CONFIG_SERVICE_NAME + "/" + context.getLatestResponseId(), null, HttpMethod.DELETE);
    }

    @When("^update already deleted Document Configuration$")
    public void sendPatchToInvalidDocumentConfiguration(Map<String, String> modelValues) throws Throwable {
        String resouceId = context.getVerificationDataTable().get("documents-deletedResourceId").toString();
        executePatchAndStoreRequest(apiUrl + "/" + DOC_CONFIG_SERVICE_NAME + "/" + resouceId, generateRequestBody(modelValues, DOC_CONFIG_SERVICE_NAME, "updated_", resouceId));
    }

    @When("^delete already deleted Document Configuration$")
    public void sendDeleteToInvalidDocumentConfiguration() throws Throwable {
        String resourceId = context.getVerificationDataTable().get("documents-deletedResourceId").toString();
        executeRequest(apiUrl + "/" + DOC_CONFIG_SERVICE_NAME + "/" + resourceId, null, HttpMethod.DELETE);
    }

    @When("^send a GET request to download-zip service to download all the documents just generated$")
    public void retrieveAllDocumentsJustGenerated() throws Throwable {
        String documentId = context.getLatestResponseId();
        String url = fileUrl + "/download-zip/" + documentId;
        logger.info("GET [{}]", url);
        executeGetDownload(url, "application/vnd.api+json");
    }

    @And("^zip file downloaded contains (\"[^\"]*\"|[^\"]+)$")
    public void VerifyZipFileContainsFiles(String documentNames) throws Throwable {
        if (context.getLatestResponse().getHeaders() != null) {
            assertTrue(context.getLatestResponse().getHeaders().getContentLength() > 0);
            assertTrue(null != ((DownloadResponseResults) context.getLatestResponse()).getFilePath());
            List<String> actualFileNames = unZipIt(((DownloadResponseResults) context.getLatestResponse()).getFilePath());
            List<String> expectedFileNames = Arrays.asList(documentNames.split(","));
            assertTrue(actualFileNames.equals(expectedFileNames));
        }
    }

    @When("^send a GET request to ([\\w\\-]+) service to retrieve an invalid resource$")
    public void getResourceJustSaved(String serviceName) throws Throwable {
        String url = apiUrl + "/" + serviceName + "/" + "randomIdxxxx";
        logger.info("GET [{}]", url);
        this.executeGet(url);
    }

    @And("^in response data, (\"[^\"]*\"|[^\"]+) array contains (\\d+) records$")
    public void arrayContainsRecord(String arrayAttributeName, int expectedCount) throws Throwable {
        int actualCount;
        if ("data".equalsIgnoreCase(arrayAttributeName)) {
            actualCount = context.getLatestResponseJson().at("/data").size();
        } else {
            actualCount = context.getLatestResponseJson().at("/data/attributes/" + arrayAttributeName).size();
        }
        Assert.assertTrue("Latest Post/PATCH Request: " + this.context.getLatestPostPatchRequestBody() + "\nLatestResponse: " + this.context.getLatestResponseJson().toString(),
                actualCount == expectedCount);
    }

    @When("^^send a DELETE request to ([\\w\\-]+) service to delete the resource just saved$")
    public void sendDeleteResourceJustCreated(String serviceName) throws Throwable {
        executeRequest(apiUrl + "/" + serviceName + "/" + context.getLatestResponseId(), null, HttpMethod.DELETE);
    }

    @And("^response data conforms to the schema$")
    public void validateResponseJsonAgainstSchema() throws Throwable {
        validateResJsonAgainstSchema();
    }

    @And("^in response data, (\"[^\"]*\"|[^\"]+) array contains the following records by the same order$")
    public void responseDataIsAsBelowSameOrder(String arrayAttributeName, Map<String, String> recordsIndices) throws Throwable {
        JsonNode tempJsonNode = generateJsonNode(recordsIndices, "").get(arrayAttributeName);
        JsonNode actualJsonNode;
        if ("data".equalsIgnoreCase(arrayAttributeName)) {
            actualJsonNode = context.getLatestResponseJson().at("/data");
        } else {
            actualJsonNode = context.getLatestResponseJson().at("/data/attributes/" + arrayAttributeName);
        }
        for (JsonNode item : actualJsonNode) {
            if (item instanceof ObjectNode) {
                ObjectNode obj = (ObjectNode) item;
                obj.remove("id");
                obj.remove("links");
                obj.remove("relationships");
            }
        }
        JSONAssert.assertEquals(tempJsonNode.toString(), actualJsonNode.toString(), JSONCompareMode.STRICT);
    }

    @And("^in response data of document-generations, (\"[^\"]*\"|[^\"]+) array contains the following records by the same order$")
    public void documentGenerationsResponseDataIsAsBelowSameOrder(String arrayAttributeName, Map<String, String> recordsIndices) throws Throwable {
        JsonNode tempJsonNode = generateJsonNode(recordsIndices, "").get(arrayAttributeName);
        JsonNode actualJsonNode;
        if ("data".equalsIgnoreCase(arrayAttributeName)) {
            actualJsonNode = context.getLatestResponseJson().at("/data");
        } else {
            actualJsonNode = context.getLatestResponseJson().at("/data/attributes/" + arrayAttributeName);
        }
        for (JsonNode item : actualJsonNode) {
            if (item instanceof ObjectNode) {
                ObjectNode obj = (ObjectNode) item;
                obj.remove("id");
                obj.remove("links");
                obj.remove("relationships");

                //WA for JSONCompareMode.STRICT, as documentKey is a random id and cannot be expected
                ObjectNode attributesNode = (ObjectNode)item.at("/attributes");
                attributesNode.remove("documents");
            }
        }
        JSONAssert.assertEquals(tempJsonNode.toString(), actualJsonNode.toString(), JSONCompareMode.STRICT);
    }

    @Given("save content in file (\"[^\"]*\"|[^\"]+) to (\"[^\"]*\"|[^\"]+)$")
    public void storeFileContentToVariable(String fileName, String storeName) throws IOException {
        ClassPathResource resource = new ClassPathResource(fileName);
        JsonNode json = this.mapper.readTree(resource.getInputStream());
        String fileContent = json.toString();
        this.context.getVerificationDataTable().put(storeName, fileContent);
    }

    @And("I want to wait for (\\d+) seconds$")
    public void wait(int seconds) throws IOException, InterruptedException {
        TimeUnit.SECONDS.sleep((long)seconds);
    }

    @When("^send a PATCH request to (\"[^\"]*\"|[^\"]+) service to update the resource created in previous step without providing id in request body$")
    public void sendPatchToResourceJustCreatedWithoutId(String serviceName, Map<String, String> modelValues) throws Throwable {
        executePatchAndStoreRequest(apiUrl + "/" + serviceName + "/" + context.getLatestResponseId(), generateRequestBody(modelValues, serviceName, "updated_"));
    }

    @When("^send a PATCH request to (\"[^\"]*\"|[^\"]+) service to update the resource created in previous step with providing different id in request body$")
    public void sendPatchToResourceJustCreatedWithDifferentId(String serviceName, Map<String, String> modelValues) throws Throwable {
        String differentId = "DifferentId5664789";
        executePatchAndStoreRequest(apiUrl + "/" + serviceName + "/" + context.getLatestResponseId(), generateRequestBody(modelValues, serviceName, "updated_", differentId));
    }


    @When("^send a PATCH request to (\"[^\"]*\"|[^\"]+) service to update a resource which does not exist$")
    public void sendPatchToNotFoundResource(String serviceName, Map<String, String> modelValues) throws Throwable {
        String notFundId = "NotFound_12123423";
        executePatchAndStoreRequest(apiUrl + "/" + serviceName + "/" + notFundId, generateRequestBody(modelValues, serviceName, "updated_", notFundId));
    }

    @And("^send (\\d+) POST requests to (\"[^\"]*\"|[^\"]+) service$")
    public void sendSeveralPostRequestsAsBelow(int count, String serviceName, Map<String, String> data) throws Exception {
        String url = apiUrl + "/" + serviceName;
        String requestBody;

        for (int i = 1; i <= count; i++ ) {
            context.getVerificationDataTable().put("processId", "random_id_" + i);
                requestBody = generateRequestBody(data, serviceName, "");
                logger.info("POST [{}]", url, requestBody);
                executePostAndStoreRequest(url, requestBody);
        }
    }


    /**
     * Unzip it
     *
     * @param zipFile input zip file
     * @return List of file names
     */
    public List<String> unZipIt(String zipFile) {
        List<String> fileNames = new ArrayList<>();
        try(ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            //get the zipped file list entry
            ZipEntry ze = zis.getNextEntry();
            while (ze != null) {
                String fileName = ze.getName();
                fileNames.add(fileName.split("\\.")[0]);
                ze = zis.getNextEntry();
            }
            zis.closeEntry();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return fileNames;
    }


    private void verifyTimeBetweenNowMinusNSecAndNow(String dateTimeStr, int minusCount) {
        String detailedInfo = generateDebugInfo();

        if (dateTimeStr == null) {
            assertTrue(detailedInfo, false);
        } else {
            LocalDateTime now = java.time.LocalDateTime.now();
            LocalDateTime date = GbstDateUtils.asLocalDateTime(GbstDateUtils.iso8601Parse(dateTimeStr));

            assertTrue(detailedInfo, date.isAfter(now.minusSeconds(minusCount)));
            assertTrue(detailedInfo, date.isBefore(now));
        }
    }

    private String generateDebugInfo() {
        String detailedInfo = "Actual response code is " + context.getLatestStatusCode() + "\n";
        if ((context.getLatestPostPatchRequestBody() != null) && (context.getLatestResponseJson() != null)) {
            detailedInfo = "Actual response code is " + context.getLatestStatusCode() + "\n" + "Latest Post or Patch Request body: " + context.getLatestPostPatchRequestBody() + "\n" + "LatestResponse: " + context.getLatestResponseJson().toString();
        } else if (context.getLatestResponseJson() != null) {
            detailedInfo = "Actual response code is " + context.getLatestStatusCode() + "\n" + "LatestResponse: " + context.getLatestResponseJson().toString();
        }
        return detailedInfo;
    }

    private void verifyAttributeValueIsUnique(String listAttributeName, String attributeName) {
        JsonNode attributes = context.getLatestResponseJson().at("/data/attributes");
        verifyAttributeInlistUnique(listAttributeName, attributeName, attributes);
    }

    private void verifyAttributeInlistUnique(String listAttributeName, String attributeName, JsonNode attributes) {
        String debugInfo = generateDebugInfo();
        String value;
        assertTrue(debugInfo, !attributes.isNull() && !attributes.isMissingNode());
        JsonNode arrNode = attributes.get(listAttributeName);
        assertTrue(!arrNode.isNull() && !arrNode.isMissingNode());
        if (arrNode.isArray()) {
            for (JsonNode element : arrNode) {
                JsonNode attrNode = element.get(attributeName);
                assertTrue(debugInfo, !attrNode.isNull() && !attrNode.isMissingNode());
                if (attrNode.isTextual()) {
                    value = attrNode.textValue();
                } else {
                    value = attrNode.toString();
                }
                assertTrue("value is not unique\n" + debugInfo, !valueStore.containsKey(value));
                valueStore.put(value, attributeName);
            }
        }
    }
}