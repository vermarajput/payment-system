package com.gbst.digital.documents.repository;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.digital.documents.resource.model.DocumentConfiguration;
import com.gbst.digital.documents.resource.model.DocumentGeneration;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import io.katharsis.queryParams.DefaultQueryParamsParser;
import io.katharsis.queryParams.QueryParams;
import io.katharsis.queryParams.QueryParamsBuilder;
import io.katharsis.queryParams.params.FilterParams;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.query.Query;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.util.StringUtils.isEmpty;

/**
 * Created by Aman Verma on 31/10/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class RepositoryUtilTest {

    @InjectMocks
    private RepositoryUtil repositoryUtil;

    @Mock
    AuthenticationFacade authenticationFacade;

    @Before
    public void setUp() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        principal.setUsername("coco");
        principal.setGbstPartyId("14");
        principal.setGbstPartyType("Adviser");
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestEmptyProcessType() {
        String processType = "";
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestNullProcessType() {
        String processType = null;
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = "id123";

        compareQueryParamResult(processType, processTypeId, processStage, role);
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestEmptyProcessTypeId() {
        String processType = "paraplanner";
        String processTypeId = "";
        String processStage = "NB";
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
    }


    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestNullProcessTypeId() {
        String processType = "paraplanner";
        String processTypeId = null;
        String processStage = "NB";
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestEmptyStage() {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = "";
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig("paraplanner", "pre-submit", "", "id123");
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestNullStage() {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = null;
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig("paraplanner", "pre-submit", "", "id123");
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestEmptyRole() {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = "";
        compareQueryParamResult(processType, processTypeId, processStage, role);
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig("paraplanner", "pre-submit", "", "id123");
    }

    @Test
    public void testPrepareQueryParamsForDocumentConfigInvalidRequestNullRole() {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = null;
        compareQueryParamResult(processType, processTypeId, processStage, role);
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig("paraplanner", "pre-submit", "", "id123");
    }

    @Test
    public void testPrepareQueryParamsForValidInputs() {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = "id123";
        compareQueryParamResult(processType, processTypeId, processStage, role);
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig("paraplanner", "pre-submit", "", "id123");
    }

    @Test
    public void testFindAllBasedOnQueryParams() throws Exception {
        String processType = "paraplanner";
        String processTypeId = "pre-submit";
        String processStage = "NB";
        String role = "id123";
        QueryParams queryParamsDummy = repositoryUtil.prepareQueryParamsForDocumentConfig(processType, null, null, null);
        QueryParams queryParamsDummy2 = repositoryUtil.prepareQueryParamsForDocumentConfig(processType, processTypeId, processStage, role);
        Query query = repositoryUtil.findAllBasedOnQueryParams(null, DocumentGeneration.class);
        String expected = "Query: { \"$and\" : [ { \"owner\" : \"14Adviser\"}]}, Fields: null, Sort: null";
        assertTrue(query.toString().equals(expected));

        Query query1 = repositoryUtil.findAllBasedOnQueryParams(queryParamsDummy, DocumentGeneration.class);
        String expected1 = "Query: { \"$and\" : [ { \"processType\" : { \"$in\" : [ \"paraplanner\"]}} , { \"owner\" : \"14Adviser\"}]}, Fields: null, Sort: null";
        assertTrue(query1.toString().equals(expected1));

        Query query2 = repositoryUtil.findAllBasedOnQueryParams(queryParamsDummy2, DocumentGeneration.class);
        String expected2 = "Query: { \"$and\" : [ { \"processType\" : { \"$in\" : [ \"paraplanner\"]}} , { \"processTypeId\" : { \"$in\" : [ \"pre-submit\"]}} , { \"processStage\" : { \"$in\" : [ \"NB\"]}} , { \"role\" : { \"$in\" : [ \"id123\"]}} , { \"owner\" : \"14Adviser\"}]}, Fields: null, Sort: null";
        assertTrue(query2.toString().equals(expected2));
    }

    @Test
    public void testFindAllBasedOnQueryParams_SortAndPage() throws Exception {
        QueryParamsBuilder builder = new QueryParamsBuilder(new DefaultQueryParamsParser());
        Map<String, Set<String>> filters = new HashMap<>();
        filters.put("page[offset]", new HashSet<>());
        filters.get("page[offset]").add("2");
        filters.put("page[limit]", new HashSet<>());
        filters.get("page[limit]").add("10");
        filters.put("sort[document-configurations][processType]", new HashSet<>());
        filters.get("sort[document-configurations][processType]").add("desc");
        filters.put("sort[document-configurations][processTypeId]", new HashSet<>());
        filters.get("sort[document-configurations][processTypeId]").add("asc");

        QueryParams queryParams = builder.buildQueryParams(filters);
        Query query = repositoryUtil.findAllBasedOnQueryParams(queryParams, DocumentConfiguration.class);
        Assert.assertTrue(query.getLimit()==10);
        Assert.assertTrue(query.getSkip()==20);

        DBObject sort = query.getSortObject();
        Assert.assertTrue(((BasicDBObject) sort).size() == 2);
        Set<Map.Entry<String, Object>> sortSet = ((BasicDBObject) ((BasicDBObject) sort)).entrySet();
        assertNotNull(sortSet);
        for (Map.Entry<String, Object> sortEntry: sortSet ) {
            if(sortEntry.getKey().equalsIgnoreCase("processType")){
                Assert.assertTrue(sortEntry.getValue().equals(Integer.valueOf(-1)));
            }
            if(sortEntry.getKey().equalsIgnoreCase("processTypeId")){
                Assert.assertTrue(sortEntry.getValue().equals(Integer.valueOf(1)));
            }
        }
    }

    private void compareQueryParamResult(String processType, String processTypeId, String processStage, String role) {
        QueryParams queryParams = repositoryUtil.prepareQueryParamsForDocumentConfig(processType, processTypeId, processStage, role);
        Map<String, FilterParams> filterParamsMap = queryParams.getFilters().getParams();

        assertTrue("Filter parameter map can not be null or empty", !filterParamsMap.isEmpty());
        assertTrue("Expected only one filter parameter entry", filterParamsMap.entrySet().size() == 1);

        for (Map.Entry<String, FilterParams> filterParam : filterParamsMap.entrySet()) {
            Map<String, Set<String>> paramsMap = filterParam.getValue().getParams();
            assertTrue("Inner Parameter map can not be null or empty", !paramsMap.isEmpty());
            assertTrue(validateMapEntry("processType", processType, paramsMap));
            assertTrue(validateMapEntry("processTypeId", processTypeId, paramsMap));
            assertTrue(validateMapEntry("processStage", processStage, paramsMap));
            assertTrue(validateMapEntry("role", role, paramsMap));
        }
    }

    private boolean validateMapEntry(String key, String value, Map<String, Set<String>> paramsMap) {
        if (isEmpty(value)) {
            return paramsMap.get(key) == null;
        } else {
            return paramsMap.get(key).contains(value);
        }
    }
}