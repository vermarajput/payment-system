package com.gbst.digital.documents.repository;

import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.storage.DocumentStorage;
import com.gbst.digital.documents.storage.FileSystemStorage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DownloadAndCleanupDelegatorTest {

    @Spy
    private List<DocumentStorage> documentStorages = new ArrayList<>();

    @Mock
    private FileSystemStorage fileSystemStorage;

    @InjectMocks
    private DownloadAndCleanupDelegator downloadAndCleanupDelegator;

    @Before
    public void setup() throws Exception {
        documentStorages.add(fileSystemStorage);
        when(fileSystemStorage.supportsStorageType("FILESYSTEM")).thenReturn(true);
    }

    @Test
    public void testDownloadDocumentsFromFileSystem() throws IOException, DocumentStorageException {
        File file = File.createTempFile( "some-name", ".pdf");
        String filePath = file.getPath();
        when(fileSystemStorage.downloadFile(filePath)).thenReturn(file);
        File downloadedFile =  downloadAndCleanupDelegator.downloadDocumentsFromStorageSystems(filePath,"FILESYSTEM");
        assertNotNull(downloadedFile);
        assertTrue(downloadedFile.getName().startsWith("some-name"));
    }

    @Test
    public void testRemoveDocumentsFromFileSystem() throws IOException, DocumentStorageException {
        File file = File.createTempFile( "some-name", ".pdf");
        String filePath = file.getPath();
        downloadAndCleanupDelegator.removeDocumentsFromStorageSystems(filePath,"FILESYSTEM");
    }

    @Test(expected = DocumentStorageException.class)
    public void testRemoveDocumentsFromDMS() throws IOException, DocumentStorageException {
        File file = File.createTempFile( "some-name", ".pdf");
        String filePath = file.getPath();
        downloadAndCleanupDelegator.removeDocumentsFromStorageSystems(filePath,"DMS");
    }

}
