package com.gbst.digital.documents.repository;

import com.gbst.common.auth.AuthenticationFacade;
import com.gbst.common.auth.GbstPrincipal;
import com.gbst.common.auth.perms.OperationEnum;
import com.gbst.common.auth.perms.Permissions;
import com.gbst.digital.documents.exception.DocumentStorageException;
import com.gbst.digital.documents.generator.DocumentPayload;
import com.gbst.digital.documents.generator.DocumentPayloadFactory;
import com.gbst.digital.documents.resource.model.*;
import com.gbst.digital.documents.resource.model.types.GenerationStatusEnum;
import io.katharsis.queryParams.QueryParams;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.gbst.digital.documents.repository.DocumentTestDataHolder.*;
import static com.gbst.digital.documents.resource.model.types.GenerationStatusEnum.NOT_GENERATED;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * @author Aman Verma, Neha S
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentGenerationJsonApiRepositoryTest {

    @Mock
    private DocumentConfigurationsJsonApiRepository documentConfigurationRepository;

    @Mock
    private RepositoryValidator repositoryValidator;

    @Mock
    private RepositoryUtil repositoryUtil;

    @Mock
    private DocumentGenerationDelegator documentGenerationDelegator;

    @Mock
    private DocumentStorageDelegator documentStorageDelegator;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private DocumentCleanupUtility documentCleanupUtility;

    @Mock
    AuthenticationFacade authenticationFacade;

    @Mock
    DocumentPayloadFactory documentPayloadFactory;

    @Mock
    DocumentPayload payload;

    @Mock
    Permissions<DocumentPayload, OperationEnum> payloadPermissions;

    @InjectMocks
    private DocumentGenerationJsonApiRepository documentGenerationJsonApiRepository;

    @Before
    public void setup() throws Exception {
        GbstPrincipal principal = new GbstPrincipal();
        when(authenticationFacade.getPrincipal()).thenReturn(principal);
        doNothing().when(payloadPermissions).check(any(), any());
        when(documentPayloadFactory.createPayload(any(), any())).thenReturn(payload);

        documentGenerationJsonApiRepository.payloadPermissions = payloadPermissions;
    }

    @Test
    public void testFetchDocumentGen_NonStaticDocumentValid() throws Exception {
        DocumentForConfig docForConfig = getDirectDebitDocument();
        DocumentConfiguration config = new DocumentConfiguration();
        config.setDocuments(Arrays.asList(docForConfig));

        //Mock Configuration
        mockFindAllAndValidator_ReturnConfigurationPassed(config);

        //Mock Generation
        DocumentForGeneration doc = new DocumentForGeneration(docForConfig);
        doc.setGenerationStatus(GenerationStatusEnum.GENERATED);
        doc.setGeneratedDate(Instant.now());
        DocumentWithParameter documentWithParameterGenResp = new DocumentWithParameter().setDocument(doc).setPayload(getDocumentAttributesPayload());
        when(documentGenerationDelegator.generateDocumentForSupportedHandlers(any(), any())).thenReturn(Arrays.asList(documentWithParameterGenResp));

        //Mock Storage
        doc.setUrl("SomeNonStaticUrl/path/string");
        DocumentWithParameter documentWithParameterStorageResp = new DocumentWithParameter().setDocument(doc).setPayload(getDocumentAttributesPayload());
        when(documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(any())).thenReturn(Arrays.asList(documentWithParameterStorageResp));

        //Mock save and cleanup utilities
        mockMongoTemplateSaveAndCleanupUtility();

        DocumentGeneration documentGenerationInput = prepareDocumentListInput();

        documentGenerationInput = documentGenerationJsonApiRepository.save(documentGenerationInput);
        List<DocumentForGeneration> listDocs = documentGenerationInput.getDocuments();
        assertTrue(!listDocs.isEmpty() && listDocs.size() == 1);
        DocumentForGeneration resultDocument = listDocs.get(0);
        assertTrue(resultDocument.getDocumentName().equalsIgnoreCase("DIRECT_DEBIT_INSTRUCTION"));
        assertTrue(resultDocument.getGenerationStatus().equals(GenerationStatusEnum.GENERATED));
    }

    private void mockFindAllAndValidator_ReturnConfigurationPassed(DocumentConfiguration config) {
        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
        when(documentConfigurationRepository.findAll(any(QueryParams.class))).thenReturn(Arrays.asList(config));
        doNothing().when(repositoryValidator).validateDocumentConfiguration(Arrays.asList(config));
    }

    @Test
    public void testFetchDocumentGen_NonStaticDocument_NoHandlerSupported_NoDocumentsGeneratedORStored() throws Exception {
        DocumentForConfig doc = getDirectDebitDocument();
        DocumentConfiguration config = new DocumentConfiguration();
        config.setDocuments(Arrays.asList(doc));

        when(repositoryUtil.prepareQueryParamsForDocumentConfig(anyString(), anyString(), anyString(), anyString())).thenReturn(new QueryParams());
        when(documentConfigurationRepository.findAll(any(QueryParams.class))).thenReturn(Arrays.asList(config));
        when(documentGenerationDelegator.generateDocumentForSupportedHandlers(any(), any())).thenReturn(new ArrayList<>());
        when(documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(any())).thenReturn(new ArrayList<>());
        doNothing().when(repositoryValidator).validateDocumentConfiguration(Arrays.asList(config));
        mockMongoTemplateSaveAndCleanupUtility();

        DocumentGeneration documentGenerationInput = prepareDocumentListInput();
        documentGenerationInput.setDocumentAttributes("");
        documentGenerationInput = documentGenerationJsonApiRepository.save(documentGenerationInput);
        List<DocumentForGeneration> listDocs = documentGenerationInput.getDocuments();
        assertTrue(listDocs.isEmpty());
    }

    @Test
    public void testFetchDocumentGen_StaticDocumentValid() throws Exception {
        DocumentForConfig documentForConfig = getStaticDocument();
        DocumentConfiguration config = new DocumentConfiguration();
        config.setDocuments(Arrays.asList(documentForConfig));

        mockFindAllAndValidator_ReturnConfigurationPassed(config);
        mockMongoTemplateSaveAndCleanupUtility();
        DocumentForGeneration doc = new DocumentForGeneration(documentForConfig);
        doc.setGenerationStatus(NOT_GENERATED);
        DocumentWithParameter documentWithParameterGenResp = new DocumentWithParameter().setDocument(doc).setPayload(getDocumentAttributesPayload());
        when(documentStorageDelegator.storeDocumentsInRespectiveStorageSystems(any())).thenReturn(Arrays.asList(documentWithParameterGenResp));

        DocumentGeneration documentGenerationInput = prepareDocumentListInput();
        documentGenerationInput = documentGenerationJsonApiRepository.save(documentGenerationInput);
        List<DocumentForGeneration> listDocs = documentGenerationInput.getDocuments();
        assertTrue(!listDocs.isEmpty() && listDocs.size() == 1);
        DocumentForGeneration resultDocument = listDocs.get(0);
        assertTrue(resultDocument.getDocumentName().equalsIgnoreCase("Static"));
        assertTrue(resultDocument.getGenerationStatus().equals(NOT_GENERATED));
        assertTrue(resultDocument.getUrl().equalsIgnoreCase("SomeUrl.url"));
    }

    private void mockMongoTemplateSaveAndCleanupUtility() throws DocumentStorageException {
        doNothing().when(mongoTemplate).save(any());
        doNothing().when(documentCleanupUtility).handlePreviousGenerationRequestsData(any());
    }

    private DocumentGeneration prepareDocumentListInput() {
        DocumentGeneration req = new DocumentGeneration();
        req.setProcessTypeId("17");
        req.setProcessType("NEW_BUSINESS");
        req.setProcessStage("pre-submission");
        req.setRole("Advisor");
        return req;
    }
}