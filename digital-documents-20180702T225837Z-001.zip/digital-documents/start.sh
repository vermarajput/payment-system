#!/bin/bash
windwardPropertiesForLogging=$(echo $WINDWARD_LICENSE | cut -c1-5)
echo "windward properties key (first 5 chars only) [$windwardPropertiesForLogging]"
sed -i -e "s@license=@license=$WINDWARD_LICENSE@g" /app/WindwardReports.properties           

java  ${JAVA_HEAP_OPTS} ${JAVA_METASPACE_OPTS} ${JAVA_OTHER_OPTS} -Dlogging.file=digital-documents.log -jar digital-documents-1.0.00-SNAPSHOT.jar